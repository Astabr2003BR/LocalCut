# LocalCut V0 Acceptance Results

Date: 2026-10-19
Branch: `feature/editor-v0`

## Evidence boundary

This report intentionally separates host-executed evidence from Android/Media3 evidence.
The current runtime has no usable Android SDK, Gradle installation, ADB, or dependency-network access, so no APK, `CompositionPlayer`, SAF, or `Transformer` result is claimed here.

## T01 — image to animated video

**Host reference — EXECUTED**

Command: `./tools/render_t01_reference.sh`

Input:
- one generated still image
- 1080x1920
- 30 fps
- 5.0 s
- zoom 100% -> 110%

Expected:
- readable H.264 MP4
- 1080x1920
- 30 fps
- 5.0 s / 150 frames
- visual change between first and last frame

Obtained:
- codec: H.264
- resolution: 1080x1920
- fps: 30/1
- duration: 5.000000 s
- frames: 150
- first frame MD5: `1eb9f68db19245866032ae1f0f3f873c`
- last frame MD5: `3207603ed854882a465208bdb2814ad4`

Status: **PASS as host rendering reference. Android internal-player/export parity remains pending.**

## T02 — two-video edit

**Host reference — EXECUTED**

Command: `./tools/render_t02_reference.sh`

Input/operations:
- two generated MP4 sources
- trim first source
- split/reorder second source segments
- final visual order blue -> red -> green
- preserve audio

Obtained:
- codec: H.264
- audio: AAC
- resolution: 360x640
- fps: 30/1
- duration: 4.000000 s
- frames: 120
- sample 0.5 s: blue `(0, 0, 255)`
- sample 2.5 s: red `(255, 0, 0)`
- sample 3.5 s: green `(1, 128, 1)`

Status: **PASS as host rendering reference. Media3 export remains pending.**

## T03 — image sequence with audio

**Host reference — EXECUTED**

Command: `./tools/render_t03_reference.sh`

Input:
- image A: 1.0 s
- image B: 2.0 s
- image C: 1.5 s
- continuous audio

Obtained:
- codec: H.264
- audio: AAC
- resolution: 360x640
- fps: 30/1
- duration: 4.500000 s
- frames: 135
- sample 0.5 s: red `(253, 0, 0)`
- sample 1.5 s: green `(0, 127, 0)`
- sample 3.75 s: blue `(0, 0, 253)`

Status: **PASS as host rendering reference. Media3 export remains pending.**

## T04 — save/reopen/process-recreation

**Pure/JVM host acceptance — EXECUTED**

Test: `V0HostAcceptanceTestMain`

Scenario:
- persist the complete project through `AtomicProjectStore`
- construct a fresh `ProjectSession`
- restore from disk
- compare full project value, IDs, times, assets, tracks and clips
- call restore again to verify idempotency/no duplication

Obtained:
- exact project equality after recreation
- exact asset IDs and clip IDs preserved
- no duplicated asset or clip IDs
- preview load occurs once even when `restore()` is called twice

Status: **PASS on host. Android Activity/process lifecycle remains pending.**

## T05 — undo/redo editor smoke

**Pure/JVM host acceptance — EXECUTED**

Scenario through `ProjectSession.state`:
- select clip
- move -> undo -> redo
- trim -> undo -> redo
- delete -> undo -> redo

Obtained:
- state reflects every operation and reversal exactly
- selected transform changes are also reversible through undo/redo

Status: **PASS at editor-state level. Compose UI instrumentation remains pending.**

## T06 — player behavior and final-preview planning

**Pure/JVM host acceptance — EXECUTED**

Scenario:
- edit selected clip transform
- verify preview loader receives edited project immediately
- play
- seek
- pause/resume
- enable loop and cross loop boundary
- frame-step at 30 fps
- build 1.0 s -> 3.0 s final-preview range

Obtained:
- transform visible to preview loader without export
- seek position preserved/clamped
- loop wraps from 3.0 s to 2.0 s
- +1 frame from 2.0 s -> 2.033333 s and pauses transport
- final-preview plan duration: 2.0 s
- final-preview plan: 1080x1920, 30 fps
- edited transform preserved in sliced project

Status: **PASS for host transport/planning. Real `CompositionPlayer` output remains pending.**

## Full host regression

Command: `./tools/run-core-tests.sh`

Observed:
- **152 PASS**
- **0 FAIL**

Coverage includes timeline invariants, transform interpolation, duration/frame math, slicing, history, render-plan compilation, project session/autosave, atomic JSON recovery, player transport, safe export transaction, asset import policy, final-preview planning, timeline geometry/hit testing/drag planning, and T04-T06 acceptance.

## P0/P1 host audit

Additional race/data-integrity checks executed after T01-T06:

- **Autosave vs undo:** edit is queued, undo occurs before debounce flush, and the store receives the undone/latest project state. **PASS.**
- **Preview/export snapshot vs later edit:** a final-preview plan remains immutable after a new project value is created by a later transform edit. **PASS.**
- **Duplicate clip/asset identity:** validator rejects duplicate IDs. **PASS in core regression.**
- **Project recovery:** corrupt/incomplete current state recovers only from the last known-good backup; unsupported newer schema fails closed. **PASS in core regression.**
- **Export cancellation:** destination is not committed and temporary output is removed. **PASS in core regression.**
- **Android URI ownership and player/codec resource leaks:** **PENDING Android instrumentation/device tests.**
- **Concurrent autosave writers:** scheduled debounce save and lifecycle `flushNow()` are serialized; the newest pending project wins. **PASS.**
- **Import main-thread I/O:** SAF metadata/media reads are dispatched to `Dispatchers.IO`. **PASS static contract.**
- **Export terminal cleanup:** commit/failure/cancel destination I/O is dispatched off the Android main thread. **PASS static contract.**
- **Fast-preview transform parity:** reduced preview canvas retains the original project-pixel transform coordinate space. **PASS.**

Current full host regression after final-review fixes: **152 PASS / 0 FAIL.**

## Host vertical slice — import to preview

An additional cross-module acceptance scenario was executed:

1. create a blank 1080x1920 / 30 fps project;
2. create an image asset through `AssetImportPolicy`;
3. create a 5-second image clip through `ImportedClipFactory`;
4. add asset + clip atomically through `ProjectSession`;
5. set transform keyframes `scale 1.0 @ 0s -> 1.1 @ 5s`;
6. flush autosave to `AtomicProjectStore`;
7. construct a new session and restore from disk;
8. verify duration/keyframes are identical;
9. build the final-preview plan for the complete 5-second range.

Observed: **PASS**. This proves the host-side V0 data path crosses import, timeline, animation metadata, history/session, persistence/recreation and preview planning without project loss. It still does **not** replace Android `CompositionPlayer`/`Transformer` execution.

## Task 8 host-side export/final-preview evidence

After integrating the Media3 export boundary, the host suite now also verifies:

- export lifecycle `Started -> Progress -> Completed/Failed/Cancelled`;
- duplicate progress coalescing;
- cancellation prevents destination commit and deletes the temporary file;
- failed destination commit discards partial destination output;
- final-preview renderer slices the selected range, zero-shifts it, exports through the same `ExportController`, and returns only a non-empty committed cache MP4;
- invalid range/export failure/cancellation do not leave a playable partial final-preview file.

These are host/JVM lifecycle and data-integrity tests. Real Android `Transformer` codecs and SAF writes remain device gates.

## Single-pass host gate

Use exactly one command for the complete host acceptance pass:

```bash
./tools/run-v0-host-acceptance.sh
```

The script has no retries, recursion, or self-invocation. A failure stops immediately at the failing gate instead of looping.

## Android gates still required

The following are **NOT YET EXECUTED** and must remain blocked from a final V0 release claim:

1. `./gradlew clean testDebugUnitTest`
2. `./gradlew connectedDebugAndroidTest`
3. `./gradlew assembleDebug`
4. SAF import with persisted URI permission on Android
5. real `CompositionPlayer` preview
6. real Media3 `Transformer` MP4 export
7. background/foreground process lifecycle on a phone
8. export cancellation and low-storage behavior on Android
9. missing persisted URI permission behavior on Android
10. repeated project open/close and codec/player resource leak checks

Overall status: **HOST V0 ACCEPTANCE PASS WITH ANDROID GATES PENDING.**
