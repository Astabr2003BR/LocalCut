# V0 Host Reference Results

## Scope

This document records host-side reference evidence only. It does **not** prove the Android/Media3 APK path yet.

## T01 — image to animated MP4 reference

Command:

```bash
./tools/render_t01_reference.sh
```

Input/contract:
- 1080x1920 project
- 30 fps
- 5 seconds
- one generated still image
- zoom from 100% to 110%
- H.264 MP4

Observed on 2026-10-18:

```text
codec=h264
resolution=1080x1920
fps=30/1
duration=5.000000
frames=150
first_frame_md5=1eb9f68db19245866032ae1f0f3f873c
last_frame_md5=3207603ed854882a465208bdb2814ad4
```

The first and last frame hashes differ, which proves the host reference contains visual change rather than a frozen still.

## Android status

Android Gradle/SDK/ADB are not installed in the current execution environment and the container cannot resolve dependency hosts. Therefore the Media3 APK build, CompositionPlayer preview, and Transformer export remain unverified here.
