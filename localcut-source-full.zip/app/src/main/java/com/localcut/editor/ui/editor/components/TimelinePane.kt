package com.localcut.editor.ui.editor.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.localcut.editor.domain.model.Project
import com.localcut.editor.domain.model.Track
import com.localcut.editor.domain.timeline.TimelineMath
import kotlin.math.max

private const val US_PER_SECOND = 1_000_000.0
private const val DEFAULT_DP_PER_SECOND = 84f

@Composable
fun TimelinePane(
    project: Project,
    selectedClipId: String?,
    playheadUs: Long,
    onSelectClip: (String?) -> Unit,
    onMoveClip: (String, Long) -> Unit,
    onSeek: (Long) -> Unit,
    onTrimLeft: (String, Long) -> Unit,
    onTrimRight: (String, Long) -> Unit,
    modifier: Modifier = Modifier,
    dpPerSecond: Float = DEFAULT_DP_PER_SECOND,
) {
    val scroll = rememberScrollState()
    val durationUs = max(TimelineMath.durationUs(project), 1_000_000L)
    val timelineWidth = max(360f, durationUs / US_PER_SECOND.toFloat() * dpPerSecond).dp

    Column(modifier = modifier.fillMaxWidth().horizontalScroll(scroll)) {
        project.tracks.sortedBy { it.order }.forEach { track ->
            TrackLane(
                track = track,
                selectedClipId = selectedClipId,
                playheadUs = playheadUs,
                timelineWidth = timelineWidth,
                dpPerSecond = dpPerSecond,
                onSelectClip = onSelectClip,
                onMoveClip = onMoveClip,
                onSeek = onSeek,
                onTrimLeft = onTrimLeft,
                onTrimRight = onTrimRight,
            )
        }
    }
}

@Composable
private fun TrackLane(
    track: Track,
    selectedClipId: String?,
    playheadUs: Long,
    timelineWidth: androidx.compose.ui.unit.Dp,
    dpPerSecond: Float,
    onSelectClip: (String?) -> Unit,
    onMoveClip: (String, Long) -> Unit,
    onSeek: (Long) -> Unit,
    onTrimLeft: (String, Long) -> Unit,
    onTrimRight: (String, Long) -> Unit,
) {
    val density = LocalDensity.current
    val playheadColor = MaterialTheme.colorScheme.error
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(track.type.name, modifier = Modifier.width(58.dp).padding(horizontal = 4.dp))
        Box(
            modifier = Modifier
                .width(timelineWidth)
                .height(64.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .pointerInput(track.id, dpPerSecond) {
                    detectTapGestures { offset ->
                        val xDp = with(density) { offset.x.toDp().value }
                        val targetUs = (xDp / dpPerSecond * US_PER_SECOND).toLong().coerceAtLeast(0L)
                        onSelectClip(null)
                        onSeek(targetUs)
                    }
                },
        ) {
            track.clips.forEach { clip ->
                val x = (clip.startUs / US_PER_SECOND * dpPerSecond).toFloat().dp
                val width = max(28f, (clip.durationUs / US_PER_SECOND * dpPerSecond).toFloat()).dp
                var bodyDragPx by remember(clip.id, clip.startUs) { mutableFloatStateOf(0f) }
                val selected = clip.id == selectedClipId
                val borderColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline

                Box(
                    modifier = Modifier
                        .offset(x = x, y = 8.dp)
                        .width(width)
                        .height(48.dp)
                        .graphicsLayer { translationX = bodyDragPx }
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .border(if (selected) 2.dp else 1.dp, borderColor)
                        .clickable { onSelectClip(clip.id) }
                        .draggable(
                            orientation = Orientation.Horizontal,
                            state = rememberDraggableState { delta -> bodyDragPx += delta },
                            onDragStarted = { onSelectClip(clip.id) },
                            onDragStopped = {
                                val deltaDp = with(density) { bodyDragPx.toDp().value }
                                val deltaUs = (deltaDp / dpPerSecond * US_PER_SECOND).toLong()
                                bodyDragPx = 0f
                                onMoveClip(clip.id, (clip.startUs + deltaUs).coerceAtLeast(0L))
                            },
                        ),
                ) {
                    Text(clip.id, modifier = Modifier.align(Alignment.Center).padding(horizontal = 12.dp), maxLines = 1)
                    TrimHandle(
                        modifier = Modifier.align(Alignment.CenterStart),
                        onFinished = { deltaPx ->
                            val deltaDp = with(density) { deltaPx.toDp().value }
                            val deltaUs = (deltaDp / dpPerSecond * US_PER_SECOND).toLong()
                            onTrimLeft(clip.id, (clip.startUs + deltaUs).coerceAtLeast(0L))
                        },
                    )
                    TrimHandle(
                        modifier = Modifier.align(Alignment.CenterEnd),
                        onFinished = { deltaPx ->
                            val deltaDp = with(density) { deltaPx.toDp().value }
                            val deltaUs = (deltaDp / dpPerSecond * US_PER_SECOND).toLong()
                            onTrimRight(clip.id, (clip.startUs + clip.durationUs + deltaUs).coerceAtLeast(0L))
                        },
                    )
                }
            }

            val playheadX = (playheadUs.coerceAtLeast(0L) / US_PER_SECOND * dpPerSecond).toFloat().dp
            Box(
                modifier = Modifier
                    .offset(x = playheadX)
                    .width(2.dp)
                    .height(64.dp)
                    .drawBehind { drawRect(playheadColor) },
            )
        }
    }
}

@Composable
private fun TrimHandle(
    modifier: Modifier,
    onFinished: (Float) -> Unit,
) {
    var deltaPx by remember { mutableFloatStateOf(0f) }
    Box(
        modifier = modifier
            .width(10.dp)
            .height(48.dp)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
            .draggable(
                orientation = Orientation.Horizontal,
                state = rememberDraggableState { deltaPx += it },
                onDragStopped = {
                    val result = deltaPx
                    deltaPx = 0f
                    onFinished(result)
                },
            ),
    )
}
