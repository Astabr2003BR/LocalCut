# V0 Android Editor Vertical Slice Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the first durable Android vertical slice of the local video editor: create/import a project, edit a sequential visual timeline plus audio, preview inside the app, save/reopen, undo/redo, and export a playable MP4 without AI, credits, or network dependencies.

**Architecture:** Android-native UI in Kotlin/Jetpack Compose, immutable project/timeline domain model, Media3 `Composition` as the shared bridge for preview/export, `CompositionPlayer` for interactive preview, and `Transformer` for MP4 export. OpenCut remains an architectural/upstream reference; V0 does not depend on unfinished OpenCut mobile code. The domain model is kept independent from Media3 so a future Rust core or alternate renderer can replace the media adapter without rewriting project files.

**Tech Stack:** Kotlin 2.3.21; Android Gradle Plugin 9.3.0; Gradle 9.5.0; JDK 17; compileSdk 37; targetSdk 36; minSdk 26; Jetpack Compose BOM 2026.09.00; AndroidX Media3 1.11.1; kotlinx.serialization 1.11.0; JUnit 4.13.2; AndroidX Test/Compose UI tests for device tests.

**Spec:** `docs/superpowers/specs/2026-10-18-local-video-editor-design.md`

## Global Constraints

- Core editing must work completely offline; no AI, account, server, credits, telemetry, or paid API dependency.
- Original media is immutable: trim/split/delete only mutate project metadata.
- Project time uses integer microseconds (`Long`) only; no floating-point timeline timestamps.
- V0 output is MP4 with H.264 video and AAC audio when audio exists.
- V0 preview/export support one sequential visual sequence (images/videos) plus zero or one audio sequence; simultaneous multi-video overlays are deferred to V2/V3 because Media3 multi-asset preview remains an active-development area.
- Project schema starts at `schemaVersion = 1` and every saved file includes the version.
- Saves are atomic: temp file -> fsync/close -> replace current file; keep a last-known-good backup during replacement.
- Preview has two paths: interactive fast preview and final-preview render of a selected range.
- Export/import work must not block the main thread.
- No feature may delete or rewrite source media.
- App must survive background/foreground transitions without losing the latest autosaved project.

## Review Focus

- Missing/revoked `content://` permission after reopening a project: surface the asset as missing and keep the project editable rather than crashing.
- Zero/negative clip durations and trims beyond source duration: reject the edit before it enters project state.
- Variable-frame-rate video: timeline stays microsecond-based and preview/export use media timestamps; never derive duration from `frameCount / fps`.
- Low storage during final preview/export: cancel cleanly, delete partial output, preserve project/autosave.
- Process death during an unsaved editing session: restore the last atomic autosave without duplicate clips or partial JSON.

---

## File Structure

```text
settings.gradle.kts
build.gradle.kts
gradle.properties
gradle/libs.versions.toml
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/localcut/editor/MainActivity.kt

app/src/main/java/com/localcut/editor/domain/model/Project.kt
app/src/main/java/com/localcut/editor/domain/model/Asset.kt
app/src/main/java/com/localcut/editor/domain/model/Track.kt
app/src/main/java/com/localcut/editor/domain/model/Clip.kt
app/src/main/java/com/localcut/editor/domain/model/TransformKeyframe.kt
app/src/main/java/com/localcut/editor/domain/timeline/TimelineOps.kt
app/src/main/java/com/localcut/editor/domain/timeline/TimelineValidator.kt
app/src/main/java/com/localcut/editor/domain/timeline/TimelineSlicer.kt
app/src/main/java/com/localcut/editor/domain/history/EditorCommand.kt
app/src/main/java/com/localcut/editor/domain/history/HistoryManager.kt

app/src/main/java/com/localcut/editor/data/project/ProjectJson.kt
app/src/main/java/com/localcut/editor/data/project/AtomicProjectStore.kt
app/src/main/java/com/localcut/editor/data/assets/AssetImporter.kt
app/src/main/java/com/localcut/editor/data/assets/AndroidAssetImporter.kt
app/src/main/java/com/localcut/editor/data/assets/AssetUriResolver.kt

app/src/main/java/com/localcut/editor/media/ProjectCompositionCompiler.kt
app/src/main/java/com/localcut/editor/media/TransformEffectFactory.kt
app/src/main/java/com/localcut/editor/media/PreviewController.kt
app/src/main/java/com/localcut/editor/media/Media3PreviewController.kt
app/src/main/java/com/localcut/editor/media/ExportController.kt
app/src/main/java/com/localcut/editor/media/Media3ExportController.kt
app/src/main/java/com/localcut/editor/media/FinalPreviewRenderer.kt

app/src/main/java/com/localcut/editor/session/ProjectSession.kt
app/src/main/java/com/localcut/editor/ui/editor/EditorViewModel.kt
app/src/main/java/com/localcut/editor/ui/editor/EditorScreen.kt
app/src/main/java/com/localcut/editor/ui/editor/components/PreviewPane.kt
app/src/main/java/com/localcut/editor/ui/editor/components/TimelinePane.kt
app/src/main/java/com/localcut/editor/ui/editor/components/InspectorPane.kt

app/src/test/java/com/localcut/editor/domain/timeline/TimelineOpsTest.kt
app/src/test/java/com/localcut/editor/domain/timeline/TimelineValidatorTest.kt
app/src/test/java/com/localcut/editor/domain/timeline/TimelineSlicerTest.kt
app/src/test/java/com/localcut/editor/domain/history/HistoryManagerTest.kt
app/src/test/java/com/localcut/editor/data/project/AtomicProjectStoreTest.kt
app/src/test/java/com/localcut/editor/session/ProjectSessionTest.kt

app/src/androidTest/java/com/localcut/editor/data/assets/AndroidAssetImporterTest.kt
app/src/androidTest/java/com/localcut/editor/media/CompositionCompilerTest.kt
app/src/androidTest/java/com/localcut/editor/media/PreviewExportParityTest.kt
app/src/androidTest/java/com/localcut/editor/ui/EditorSmokeTest.kt
```

### Task 1: Android project scaffold and deterministic build

**Files:**
- Create: root Gradle files listed above
- Create: `app/build.gradle.kts`
- Create: `app/src/main/AndroidManifest.xml`
- Create: `app/src/main/java/com/localcut/editor/MainActivity.kt`
- Test: `app/src/test/java/com/localcut/editor/BuildSanityTest.kt`

**Interfaces:**
- Consumes: none
- Produces: buildable Android app module `:app`; package `com.localcut.editor`; Compose entry point `MainActivity`

- [ ] **Step 1: Write the failing build sanity test**

Create `BuildSanityTest` asserting a constant `BuildContract.PROJECT_SCHEMA_VERSION == 1`; the class does not exist yet.

- [ ] **Step 2: Run the unit test and verify failure**

Run: `./gradlew testDebugUnitTest --tests com.localcut.editor.BuildSanityTest`
Expected: FAIL because `BuildContract` is unresolved.

- [ ] **Step 3: Configure the pinned toolchain and dependencies**

Use the versions from this plan header; enable Compose; set `compileSdk = 37`, `targetSdk = 36`, `minSdk = 26`; add Media3 ExoPlayer/UI/Transformer/Effect modules at `1.11.1`; add serialization JSON `1.11.0`.

- [ ] **Step 4: Implement the minimal app shell and `BuildContract`**

Create `object BuildContract { const val PROJECT_SCHEMA_VERSION = 1 }` and a `MainActivity` that renders a placeholder `EditorScreen` label only.

- [ ] **Step 5: Verify clean build and test**

Run: `./gradlew clean testDebugUnitTest assembleDebug`
Expected: BUILD SUCCESSFUL; sanity test PASS; debug APK produced.

- [ ] **Step 6: Commit**

```bash
git add .
git commit -m "build: scaffold android editor app"
```

### Task 2: Project schema, timeline invariants, trim/split/move/delete

**Files:**
- Create: domain model files
- Create: `domain/timeline/TimelineValidator.kt`
- Create: `domain/timeline/TimelineOps.kt`
- Test: `TimelineValidatorTest.kt`
- Test: `TimelineOpsTest.kt`

**Interfaces:**
- Consumes: `BuildContract.PROJECT_SCHEMA_VERSION`
- Produces:
  - `Project`, `Asset`, `Track`, `Clip`, `TransformKeyframe`
  - `TimelineValidator.validate(project: Project): List<ProjectIssue>`
  - `TimelineOps.insertClip(project, trackId, clip): Project`
  - `TimelineOps.moveClip(project, clipId, newStartUs): Project`
  - `TimelineOps.trimClip(project, clipId, newSourceInUs, newSourceOutUs): Project`
  - `TimelineOps.splitClip(project, clipId, splitAtProjectUs): Project`
  - `TimelineOps.deleteClip(project, clipId): Project`

- [ ] **Step 1: Write failing invariant tests**

Tests must assert: duration must be `> 0`; `startUs >= 0`; `sourceInUs >= 0`; `sourceOutUs > sourceInUs`; unknown `assetId` is invalid; Unicode titles/asset names are valid; VFR assets do not require a fixed FPS field.

- [ ] **Step 2: Run invariant tests and verify failure**

Run: `./gradlew testDebugUnitTest --tests '*TimelineValidatorTest'`
Expected: FAIL because models/validator are absent.

- [ ] **Step 3: Implement immutable serializable schema and validator**

Use `Long` microseconds for all time fields. `Asset` stores type, persisted URI string, optional source duration, size, display name, MIME type, and fingerprint metadata. `Project` initializes one `VISUAL` track and one `AUDIO` track.

- [ ] **Step 4: Run invariant tests**

Run: `./gradlew testDebugUnitTest --tests '*TimelineValidatorTest'`
Expected: PASS.

- [ ] **Step 5: Write failing timeline operation tests**

Cover insert, move, trim, split, delete, minimum 1-microsecond clip, trim past source duration rejection, split at clip boundaries rejection, and proof that source `Asset` values never change.

- [ ] **Step 6: Implement `TimelineOps` with validate-before-return semantics**

Every operation returns a new immutable `Project`; invalid operations throw `TimelineEditException` with a stable error code.

- [ ] **Step 7: Run domain tests**

Run: `./gradlew testDebugUnitTest --tests '*Timeline*Test'`
Expected: PASS.

- [ ] **Step 8: Commit**

```bash
git add app/src/main/java/com/localcut/editor/domain app/src/test/java/com/localcut/editor/domain
git commit -m "feat: add project schema and timeline operations"
```

### Task 3: Atomic project save/load and schema-safe recovery

**Files:**
- Create: `data/project/ProjectJson.kt`
- Create: `data/project/AtomicProjectStore.kt`
- Test: `AtomicProjectStoreTest.kt`

**Interfaces:**
- Consumes: `Project`
- Produces:
  - `ProjectJson.encode(project: Project): String`
  - `ProjectJson.decode(json: String): Project`
  - `AtomicProjectStore.save(projectDir: Path, project: Project): Result<Unit>`
  - `AtomicProjectStore.load(projectDir: Path): Result<Project>`

- [ ] **Step 1: Write failing round-trip and recovery tests**

Assert exact timeline values survive encode/decode; spaces and Unicode survive; partial `project.json.tmp` is ignored; corrupted current file falls back to `project.json.bak`; unsupported newer schema returns `UNSUPPORTED_SCHEMA` instead of guessing.

- [ ] **Step 2: Verify tests fail**

Run: `./gradlew testDebugUnitTest --tests '*AtomicProjectStoreTest'`
Expected: FAIL because persistence layer is absent.

- [ ] **Step 3: Implement JSON configuration**

Use deterministic JSON settings, explicit defaults, unknown-key tolerance only for forward-compatible noncritical fields, and never include media bytes inside `project.json`.

- [ ] **Step 4: Implement atomic save/recovery**

Write to `project.json.tmp`, close/sync, rotate valid current file to `.bak`, then replace current. Never modify source assets.

- [ ] **Step 5: Run persistence tests**

Run: `./gradlew testDebugUnitTest --tests '*AtomicProjectStoreTest'`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add app/src/main/java/com/localcut/editor/data/project app/src/test/java/com/localcut/editor/data/project
git commit -m "feat: add atomic project persistence"
```

### Task 4: Android asset import via SAF and persistent URI ownership

**Files:**
- Create: `data/assets/AssetImporter.kt`
- Create: `data/assets/AndroidAssetImporter.kt`
- Create: `data/assets/AssetUriResolver.kt`
- Test: `androidTest/.../AndroidAssetImporterTest.kt`

**Interfaces:**
- Consumes: Android `Uri`, `ContentResolver`
- Produces:
  - `AssetImporter.import(uri: Uri): Result<Asset>`
  - `AssetUriResolver.resolve(asset: Asset): Result<Uri>`

- [ ] **Step 1: Write failing instrumented import tests**

Use fixture image/video/audio files. Assert persisted URI permission is requested when available; display names with spaces/Unicode survive; MIME/type is detected; zero-byte/unsupported input returns a typed error; revoking access later yields `ASSET_UNAVAILABLE` without corrupting the project.

- [ ] **Step 2: Run instrumented tests**

Run: `./gradlew connectedDebugAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.localcut.editor.data.assets.AndroidAssetImporterTest`
Expected: FAIL before importer exists.

- [ ] **Step 3: Implement SAF importer and metadata extraction**

Use `ACTION_OPEN_DOCUMENT`; keep original URI; capture metadata needed for timeline validation; fingerprint from stable metadata (`uri + size + lastModified` where available) rather than rewriting media.

- [ ] **Step 4: Re-run instrumented import tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add app/src/main/java/com/localcut/editor/data/assets app/src/androidTest/java/com/localcut/editor/data/assets
git commit -m "feat: import media through android saf"
```

### Task 5: Shared Media3 composition compiler and time-aware transform effect

**Files:**
- Create: `media/ProjectCompositionCompiler.kt`
- Create: `media/TransformEffectFactory.kt`
- Test: `androidTest/.../CompositionCompilerTest.kt`

**Interfaces:**
- Consumes: `Project`, `AssetUriResolver`
- Produces:
  - `enum class RenderMode { FAST_PREVIEW, FULL_PREVIEW, EXPORT }`
  - `ProjectCompositionCompiler.compile(project: Project, mode: RenderMode): Result<Composition>`
  - `TransformEffectFactory.create(clip: Clip, projectWidth: Int, projectHeight: Int): List<Effect>`
  - `TransformInterpolator.valueAt(keyframes: List<TransformKeyframe>, offsetUs: Long): TransformValue`

- [ ] **Step 1: Write failing pure interpolation tests**

Assert linear scale `1.0 -> 1.1` reaches `1.05` at half duration; position/rotation interpolate in microseconds; exact keyframe timestamps are stable; duplicate keyframe timestamp is rejected.

- [ ] **Step 2: Implement `TransformInterpolator` only**

Keep interpolation pure and Android-free so it can be unit tested and later moved to Rust unchanged in behavior.

- [ ] **Step 3: Run interpolation tests**

Run: `./gradlew testDebugUnitTest --tests '*TransformInterpolatorTest'`
Expected: PASS.

- [ ] **Step 4: Write failing Composition compiler instrumented tests**

Assert a 5-second image becomes an `EditedMediaItem` with explicit duration and frame rate; source trim is represented; visual sequence ordering matches timeline; audio-only sequence is separate; missing asset URI produces `ASSET_UNAVAILABLE`; fast preview uses reduced presentation resolution while export keeps project resolution.

- [ ] **Step 5: Implement the compiler and effects**

Use Media3 `Composition`/`EditedMediaItemSequence`; images use `setImageDurationMs`; transform uses a timestamp-aware `MatrixTransformation`; static clip opacity uses `AlphaScale`; `Presentation` fixes project aspect/output size. Use one visual sequence plus one audio sequence in V0.

- [ ] **Step 6: Run compiler tests**

Run: `./gradlew connectedDebugAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.localcut.editor.media.CompositionCompilerTest`
Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add app/src/main/java/com/localcut/editor/media app/src/test app/src/androidTest/java/com/localcut/editor/media/CompositionCompilerTest.kt
git commit -m "feat: compile project timeline to media3 composition"
```

### Task 6: Interactive internal player

**Files:**
- Create: `media/PreviewController.kt`
- Create: `media/Media3PreviewController.kt`
- Create: `ui/editor/components/PreviewPane.kt`
- Test: `androidTest/.../PreviewExportParityTest.kt` (preview portion)

**Interfaces:**
- Consumes: `ProjectCompositionCompiler`
- Produces:
  - `PreviewController.load(project: Project): Result<Unit>`
  - `play()`, `pause()`, `seekToUs(positionUs: Long)`
  - `stepFrames(deltaFrames: Int, fps: Int)`
  - `setLoopRange(startUs: Long, endUs: Long?)`
  - `StateFlow<PreviewState>` with position/duration/playing/error
  - `release()`

- [ ] **Step 1: Write failing preview state/instrumentation tests**

Create a 5-second image composition; assert load duration; play advances position; pause stops advancement; seek reaches requested timestamp within tolerance; stepping one frame at 30fps moves about 33,333us; repeated reload after a project edit does not duplicate media items.

- [ ] **Step 2: Run preview test and verify failure**

Expected: FAIL before controller exists.

- [ ] **Step 3: Implement `Media3PreviewController` with `CompositionPlayer`**

Use the shared compiler in `FAST_PREVIEW`; bind the player to `PreviewPane` via Media3 Player UI/Surface; release all player resources on lifecycle teardown.

- [ ] **Step 4: Implement loop and frame-step semantics**

Loop range is enforced by controller position checks; frame step uses `1_000_000 / fps` microseconds with integer rounding and clamps to project duration.

- [ ] **Step 5: Re-run preview tests**

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add app/src/main/java/com/localcut/editor/media/PreviewController.kt app/src/main/java/com/localcut/editor/media/Media3PreviewController.kt app/src/main/java/com/localcut/editor/ui/editor/components/PreviewPane.kt app/src/androidTest/java/com/localcut/editor/media/PreviewExportParityTest.kt
git commit -m "feat: add internal composition preview player"
```

### Task 7: Editor session, undo/redo, autosave, and minimal timeline UI

**Files:**
- Create: `domain/history/EditorCommand.kt`
- Create: `domain/history/HistoryManager.kt`
- Create: `session/ProjectSession.kt`
- Create: `ui/editor/EditorViewModel.kt`
- Create: `ui/editor/EditorScreen.kt`
- Create: `ui/editor/components/TimelinePane.kt`
- Create: `ui/editor/components/InspectorPane.kt`
- Test: `HistoryManagerTest.kt`
- Test: `ProjectSessionTest.kt`

**Interfaces:**
- Consumes: `TimelineOps`, `AtomicProjectStore`, `PreviewController`, `AssetImporter`
- Produces:
  - `EditorCommand.apply(project): Project`
  - `HistoryManager.execute(command)`, `undo()`, `redo()`
  - `ProjectSession.state: StateFlow<ProjectSessionState>`
  - `ProjectSession.dispatch(EditorAction)`

- [ ] **Step 1: Write failing history tests**

Cover move -> undo -> redo; trim -> undo; delete -> undo; redo stack clears after a new command; source assets are untouched.

- [ ] **Step 2: Implement history layer**

Commands hold only the minimum prior/new project metadata required to reverse the operation; cap in-memory history by a fixed V0 count while leaving autosave independent.

- [ ] **Step 3: Run history tests**

Expected: PASS.

- [ ] **Step 4: Write failing session/autosave tests**

Use fakes to assert successful edit schedules autosave; multiple rapid edits coalesce; failed edit does not save invalid state; process recreation loads the last saved project exactly once; missing asset becomes a visible issue, not a crash.

- [ ] **Step 5: Implement `ProjectSession` and `EditorViewModel`**

Session is the only owner of mutable editing state. After a committed edit, refresh preview from the new project and debounce autosave off the main thread.

- [ ] **Step 6: Implement minimal mobile UI**

Portrait layout: preview top, timeline middle, transport controls, inspector bottom sheet. Landscape: preview + inspector above/side and wider timeline. Include import, select clip, move, trim handles, split, delete, undo/redo, play/pause, seek, frame step, loop toggle.

- [ ] **Step 7: Run unit tests and Compose smoke build**

Run: `./gradlew testDebugUnitTest assembleDebug`
Expected: PASS/BUILD SUCCESSFUL.

- [ ] **Step 8: Commit**

```bash
git add app/src/main/java/com/localcut/editor/domain/history app/src/main/java/com/localcut/editor/session app/src/main/java/com/localcut/editor/ui app/src/test/java/com/localcut/editor/domain/history app/src/test/java/com/localcut/editor/session
git commit -m "feat: add editor session timeline ui and undo redo"
```

### Task 8: MP4 export and final-preview range render

**Files:**
- Create: `media/ExportController.kt`
- Create: `media/Media3ExportController.kt`
- Create: `media/FinalPreviewRenderer.kt`
- Create: `domain/timeline/TimelineSlicer.kt`
- Test: `TimelineSlicerTest.kt`
- Extend: `PreviewExportParityTest.kt`

**Interfaces:**
- Consumes: shared `ProjectCompositionCompiler`
- Produces:
  - `TimelineSlicer.slice(project: Project, startUs: Long, endUs: Long): Project`
  - `ExportController.export(project: Project, destination: ExportDestination): Flow<ExportEvent>`
  - `ExportController.cancel()`
  - `FinalPreviewRenderer.renderRange(project, startUs, endUs): Result<File>`

- [ ] **Step 1: Write failing slicer tests**

Assert clips outside range disappear; intersecting clips are trimmed and shifted so sliced project starts at 0; audio follows the same shift; invalid ranges fail; source assets stay unchanged.

- [ ] **Step 2: Implement and verify `TimelineSlicer`**

Run: `./gradlew testDebugUnitTest --tests '*TimelineSlicerTest'`
Expected: PASS.

- [ ] **Step 3: Write failing export/final-preview instrumented tests**

Fixture T01: 1080x1920, 30fps, image 5s, scale 1.0 -> 1.1. Assert exported MP4 is readable, duration within tolerance, video dimensions correct, and file is nonzero. Add cancel test; low-space/temp-copy failure must remove partial destination. Add final-preview 1-second range and verify it is playable.

- [ ] **Step 4: Implement Media3 Transformer export**

Use `RenderMode.EXPORT`, H.264/AAC target, progress events, cancellation, temp-file-first semantics, then copy atomically to user-selected SAF/MediaStore destination. Never write into source asset URI.

- [ ] **Step 5: Implement `FinalPreviewRenderer`**

Slice project, render to app cache using the same compiler/export pipeline, then load the temporary MP4 in the existing preview player as a separate final-preview source.

- [ ] **Step 6: Run parity tests**

Run: `./gradlew connectedDebugAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.localcut.editor.media.PreviewExportParityTest`
Expected: PASS for T01 and final-preview cases.

- [ ] **Step 7: Commit**

```bash
git add app/src/main/java/com/localcut/editor/media app/src/main/java/com/localcut/editor/domain/timeline/TimelineSlicer.kt app/src/test/java/com/localcut/editor/domain/timeline/TimelineSlicerTest.kt app/src/androidTest/java/com/localcut/editor/media/PreviewExportParityTest.kt
git commit -m "feat: export mp4 and render final preview ranges"
```

### Task 9: V0 acceptance regression — T01 through T06

**Files:**
- Create: `androidTest/.../ui/EditorSmokeTest.kt`
- Create: `docs/testing/V0_ACCEPTANCE_RESULTS.md`
- Modify only defects found by tests in existing V0 files

**Interfaces:**
- Consumes: all V0 modules
- Produces: executable acceptance evidence for T01-T06

- [ ] **Step 1: Add end-to-end T01 image-to-video test**

Input: PNG/JPG, 1080x1920, 30fps, 5s, scale 100% -> 110%.
Expected: internal player shows animation; export readable at expected size/duration; source checksum unchanged.

- [ ] **Step 2: Add T02 two-video edit test**

Import two supported MP4s; trim first; split second; reorder; export; validate sequence and A/V duration tolerance.

- [ ] **Step 3: Add T03 sequence-of-images test**

A/B/C image order, individual durations, transform values, optional audio; validate order and audio end behavior.

- [ ] **Step 4: Add T04 save/reopen/process-recreation test**

Save; recreate activity/session; verify exactly the same IDs/times/assets and no duplication.

- [ ] **Step 5: Add T05 undo/redo UI smoke test**

Move, trim, delete; undo/redo each; verify visible timeline/project state.

- [ ] **Step 6: Add T06 player test**

Play, pause, seek, edit transform, resume, loop, frame-step, final-preview range. Verify project edits are visible without full export.

- [ ] **Step 7: Run the full verification suite**

Run:

```bash
./gradlew clean testDebugUnitTest
./gradlew connectedDebugAndroidTest
./gradlew assembleDebug
```

Expected: all unit/instrumented tests PASS; debug APK produced.

- [ ] **Step 8: Perform physical-device regression**

On the target Android phone, run T01-T06 plus: background/foreground during preview, cancel export, low storage simulation where practical, missing asset permission, Unicode names, and repeated open/close. Record device/API, input, expected, obtained, and status in `docs/testing/V0_ACCEPTANCE_RESULTS.md`.

- [ ] **Step 9: Audit for P0/P1 defects**

Check crash, media corruption, project loss, path/URI misuse, duplicated clips, race between autosave/undo/export, leaked player/codec resources, and export cancellation cleanup. Fix defects and rerun affected tests before proceeding.

- [ ] **Step 10: Commit acceptance evidence**

```bash
git add app/src/androidTest docs/testing/V0_ACCEPTANCE_RESULTS.md
git commit -m "test: validate v0 editor acceptance suite"
```

## Plan Self-Review Result

- **Spec coverage:** V0 T01-T06, preview player, save/reopen, undo/redo, import, export, autosave, mobile lifecycle, and key edge cases are assigned to tasks.
- **Intentional V0 limitation:** simultaneous overlapping visual tracks are not implemented; one sequential visual sequence plus audio is the supported V0 composition shape. The schema remains ready for future additional visual tracks.
- **Type consistency:** project time is `Long` microseconds across domain, slicing, preview, and export; Media3 conversion occurs only inside the media adapter.
- **Preview/export parity:** both derive from `ProjectCompositionCompiler`; fast preview may use reduced output resolution but not different timeline semantics.
- **Security/data integrity:** SAF persisted URIs, immutable source media, typed missing-asset errors, atomic JSON writes, and temp-first export are explicit.
- **Scope:** this plan stops at V0. Transitions, full animation UI, 2.5D compositor, particles, masks, and 3D require later plans after V0 acceptance passes.
