package com.localcut.editor.media

private var passed=0
private var failed=0
private fun test(name:String,block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertEquals(e:Any?,a:Any?,m:String=""){if(e!=a)error("expected=$e actual=$a $m")}
private fun assertTrue(v:Boolean,m:String="expected true"){if(!v)error(m)}
private fun assertFalse(v:Boolean,m:String="expected false"){if(v)error(m)}
private fun assertFails(block:()->Unit){try{block();error("expected failure")}catch(_:IllegalArgumentException){}}

fun main(){
    test("load initializes duration fps and resets position"){
        val t=PreviewTransport(); t.load(5_000_000,30)
        assertEquals(0L,t.state.positionUs); assertEquals(5_000_000L,t.state.durationUs); assertEquals(30,t.state.fps); assertFalse(t.state.playing)
    }
    test("play pause and seek clamp"){
        val t=PreviewTransport(); t.load(5_000_000,30); t.play(); assertTrue(t.state.playing); t.pause(); assertFalse(t.state.playing)
        assertEquals(0L,t.seekToUs(-5)); assertEquals(5_000_000L,t.seekToUs(7_000_000)); assertEquals(2_000_000L,t.seekToUs(2_000_000))
    }
    test("frame step pauses and uses deterministic frame math"){
        val t=PreviewTransport(); t.load(5_000_000,30); t.play(); t.seekToUs(1_000_000)
        assertEquals(1_033_333L,t.stepFrames(1)); assertFalse(t.state.playing)
        assertEquals(1_000_000L,t.stepFrames(-1))
    }
    test("valid loop wraps playback position to loop start"){
        val t=PreviewTransport(); t.load(5_000_000,30); t.setLoopRange(1_000_000,2_000_000); t.play()
        assertEquals(null,t.onPlayerPosition(1_999_999))
        assertEquals(1_000_000L,t.onPlayerPosition(2_000_000))
        assertEquals(1_000_000L,t.state.positionUs)
    }
    test("loop does not force wrap while paused"){
        val t=PreviewTransport(); t.load(5_000_000,30); t.setLoopRange(1_000_000,2_000_000)
        assertEquals(null,t.onPlayerPosition(2_500_000)); assertEquals(2_500_000L,t.state.positionUs)
    }
    test("loop range validation and disable"){
        val t=PreviewTransport(); t.load(5_000_000,30)
        assertFails{t.setLoopRange(-1,1_000_000)}; assertFails{t.setLoopRange(2_000_000,2_000_000)}; assertFails{t.setLoopRange(0,6_000_000)}
        t.setLoopRange(1_000_000,2_000_000); t.setLoopRange(0,null); assertEquals(null,t.state.loopRange)
    }
    test("invalid load values are rejected"){
        val t=PreviewTransport(); assertFails{t.load(-1,30)}; assertFails{t.load(1_000_000,0)}
    }
    println("RESULT passed=$passed failed=$failed")
    if(failed!=0)error("$failed tests failed")
}
