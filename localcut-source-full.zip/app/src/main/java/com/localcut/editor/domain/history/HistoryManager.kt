package com.localcut.editor.domain.history

import com.localcut.editor.domain.model.Project
import java.util.ArrayDeque

class HistoryManager(initialProject: Project, private val maxEntries: Int = 100) {
    init { require(maxEntries > 0) { "maxEntries must be > 0" } }

    private data class UndoEntry(val forward: EditorCommand, val inverse: EditorCommand)

    private val undoStack = ArrayDeque<UndoEntry>()
    private val redoStack = ArrayDeque<EditorCommand>()

    var project: Project = initialProject
        private set

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun execute(command: EditorCommand) {
        val result = command.apply(project)
        project = result.project
        undoStack.addLast(UndoEntry(command, result.inverse))
        trimToMax(undoStack)
        redoStack.clear()
    }

    fun undo(): Boolean {
        val entry = undoStack.pollLast() ?: return false
        val result = entry.inverse.apply(project)
        project = result.project
        redoStack.addLast(entry.forward)
        trimToMax(redoStack)
        return true
    }

    fun redo(): Boolean {
        val command = redoStack.pollLast() ?: return false
        val result = command.apply(project)
        project = result.project
        undoStack.addLast(UndoEntry(command, result.inverse))
        trimToMax(undoStack)
        return true
    }

    private fun <T> trimToMax(stack: ArrayDeque<T>) {
        while (stack.size > maxEntries) stack.removeFirst()
    }
}
