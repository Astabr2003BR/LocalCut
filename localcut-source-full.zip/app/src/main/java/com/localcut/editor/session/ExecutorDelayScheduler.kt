package com.localcut.editor.session

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class ExecutorDelayScheduler : DelayScheduler, AutoCloseable {
    private val executor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "localcut-autosave").apply { isDaemon = true }
    }

    override fun schedule(delayMs: Long, action: () -> Unit): Cancellable {
        val future = executor.schedule(action, delayMs.coerceAtLeast(0L), TimeUnit.MILLISECONDS)
        return Cancellable { future.cancel(false) }
    }

    override fun close() {
        executor.shutdownNow()
    }
}
