#!/usr/bin/env bash
set -euo pipefail
s=app/src/main/java/com/localcut/editor/ui/editor/EditorScreen.kt
m=app/src/main/java/com/localcut/editor/MainActivity.kt
[[ -f "$s" ]] || { echo 'FAIL missing EditorScreen.kt'; exit 1; }
grep -q 'ORIENTATION_LANDSCAPE' "$s"
grep -q 'PreviewPane' "$s"
grep -q 'TimelinePane' "$s"
grep -q 'InspectorPane' "$s"
grep -q 'EditorAction.Undo' "$s"
grep -q 'EditorAction.Redo' "$s"
grep -q 'onImportRequested' "$s"
grep -q 'setLoopRange' "$s"
grep -q 'onExportRequested' "$s"
grep -q 'onCancelExport' "$s"
grep -q 'onFinalPreviewRequested' "$s"
grep -q 'Exportar' "$s"
grep -q 'Prévia final' "$s"
grep -q 'ActivityResultContracts.CreateDocument' "$m"
grep -q 'Media3ExportController' "$m"
grep -q 'SafExportDestination' "$m"
grep -q 'FinalPreviewRenderer' "$m"
grep -q 'loadRenderedFile' "$m"
grep -q 'ActivityResultContracts.OpenDocument' "$m"
grep -q 'AndroidAssetImporter' "$m"
grep -q 'ImportedClipFactory.create' "$m"
grep -q 'EditorScreen' "$m"

# Review gate: import metadata/file I/O must leave the Android main thread.
grep -Fq 'withContext(Dispatchers.IO) { importer.import(uri) }' "$m" || {
  echo 'FAIL import still runs on main thread'; exit 1;
}
echo 'PASS editor screen static contract'
