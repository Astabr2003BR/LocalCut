#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="${1:-$ROOT/out/t03}"
mkdir -p "$OUT_DIR"
A="$OUT_DIR/a.png"
B="$OUT_DIR/b.png"
C="$OUT_DIR/c.png"
FINAL="$OUT_DIR/t03-image-sequence.mp4"

ffmpeg -hide_banner -loglevel error -y -f lavfi -i "color=c=red:size=360x640:rate=1" -frames:v 1 "$A"
ffmpeg -hide_banner -loglevel error -y -f lavfi -i "color=c=green:size=360x640:rate=1" -frames:v 1 "$B"
ffmpeg -hide_banner -loglevel error -y -f lavfi -i "color=c=blue:size=360x640:rate=1" -frames:v 1 "$C"

ffmpeg -hide_banner -loglevel error -y \
  -loop 1 -framerate 30 -t 1.0 -i "$A" \
  -loop 1 -framerate 30 -t 2.0 -i "$B" \
  -loop 1 -framerate 30 -t 1.5 -i "$C" \
  -f lavfi -i "sine=frequency=523.25:sample_rate=48000:duration=4.5" \
  -filter_complex "\
[0:v]trim=duration=1.0,setpts=PTS-STARTPTS[v0];\
[1:v]trim=duration=2.0,setpts=PTS-STARTPTS[v1];\
[2:v]trim=duration=1.5,setpts=PTS-STARTPTS[v2];\
[v0][v1][v2]concat=n=3:v=1:a=0[outv]" \
  -map "[outv]" -map 3:a:0 -c:v libx264 -preset veryfast -pix_fmt yuv420p -r 30 -c:a aac -shortest -movflags +faststart "$FINAL"

codec=$(ffprobe -v error -select_streams v:0 -show_entries stream=codec_name -of default=nw=1:nk=1 "$FINAL")
width=$(ffprobe -v error -select_streams v:0 -show_entries stream=width -of default=nw=1:nk=1 "$FINAL")
height=$(ffprobe -v error -select_streams v:0 -show_entries stream=height -of default=nw=1:nk=1 "$FINAL")
fps=$(ffprobe -v error -select_streams v:0 -show_entries stream=r_frame_rate -of default=nw=1:nk=1 "$FINAL")
duration=$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$FINAL")
frames=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of default=nw=1:nk=1 "$FINAL")
audio_codec=$(ffprobe -v error -select_streams a:0 -show_entries stream=codec_name -of default=nw=1:nk=1 "$FINAL")

sample_rgb() {
  local at="$1"
  ffmpeg -hide_banner -loglevel error -ss "$at" -i "$FINAL" -frames:v 1 -vf "scale=1:1" -f rawvideo -pix_fmt rgb24 - 2>/dev/null | od -An -tu1 | tr -s ' ' | sed 's/^ //;s/ $//'
}
rgb_a=$(sample_rgb 0.5)
rgb_b=$(sample_rgb 1.5)
rgb_c=$(sample_rgb 3.75)

[[ "$codec" == "h264" ]]
[[ "$audio_codec" == "aac" ]]
[[ "$width" == "360" && "$height" == "640" ]]
[[ "$fps" == "30/1" ]]
[[ "$frames" == "135" ]]
python3 - "$duration" "$rgb_a" "$rgb_b" "$rgb_c" <<'PY'
import sys
v=float(sys.argv[1]); assert abs(v-4.5)<=0.08, v
samples=[]
for raw in sys.argv[2:]:
    rgb=tuple(map(int, raw.split())); assert len(rgb)==3, rgb; samples.append(rgb)
r,g,b=samples
assert r[0] > r[1] and r[0] > r[2], r
assert g[1] > g[0] and g[1] > g[2], g
assert b[2] > b[0] and b[2] > b[1], b
PY

cat <<META
MP4=$FINAL
codec=$codec
audio_codec=$audio_codec
resolution=${width}x${height}
fps=$fps
duration=$duration
frames=$frames
sample_0.5s_red=$rgb_a
sample_1.5s_green=$rgb_b
sample_3.75s_blue=$rgb_c
META
