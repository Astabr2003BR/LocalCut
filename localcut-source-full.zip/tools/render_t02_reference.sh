#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="${1:-$ROOT/out/t02}"
mkdir -p "$OUT_DIR"
A="$OUT_DIR/source-a.mp4"
B="$OUT_DIR/source-b.mp4"
FINAL="$OUT_DIR/t02-two-video-edit.mp4"

# Source A: 2 s red + 440 Hz audio.
ffmpeg -hide_banner -loglevel error -y \
  -f lavfi -i "color=c=red:size=360x640:rate=30:duration=2" \
  -f lavfi -i "sine=frequency=440:sample_rate=48000:duration=2" \
  -c:v libx264 -preset veryfast -pix_fmt yuv420p -c:a aac -shortest "$A"

# Source B: 1 s green + 2 s blue, with matching audio segments.
ffmpeg -hide_banner -loglevel error -y \
  -f lavfi -i "color=c=green:size=360x640:rate=30:duration=1" \
  -f lavfi -i "sine=frequency=660:sample_rate=48000:duration=1" \
  -f lavfi -i "color=c=blue:size=360x640:rate=30:duration=2" \
  -f lavfi -i "sine=frequency=880:sample_rate=48000:duration=2" \
  -filter_complex "[0:v][1:a][2:v][3:a]concat=n=2:v=1:a=1[v][a]" \
  -map "[v]" -map "[a]" -c:v libx264 -preset veryfast -pix_fmt yuv420p -c:a aac "$B"

# Edit contract:
# - trim A to 0.5..1.5 s (1 s red)
# - split B at 1 s => B1 green 1 s + B2 blue 2 s
# - reorder B2 -> A(trim) -> B1 => 4 s total
ffmpeg -hide_banner -loglevel error -y -i "$A" -i "$B" \
  -filter_complex "\
[1:v]trim=start=1:end=3,setpts=PTS-STARTPTS[b2v];\
[1:a]atrim=start=1:end=3,asetpts=PTS-STARTPTS[b2a];\
[0:v]trim=start=0.5:end=1.5,setpts=PTS-STARTPTS[av];\
[0:a]atrim=start=0.5:end=1.5,asetpts=PTS-STARTPTS[aa];\
[1:v]trim=start=0:end=1,setpts=PTS-STARTPTS[b1v];\
[1:a]atrim=start=0:end=1,asetpts=PTS-STARTPTS[b1a];\
[b2v][b2a][av][aa][b1v][b1a]concat=n=3:v=1:a=1[outv][outa]" \
  -map "[outv]" -map "[outa]" -c:v libx264 -preset veryfast -pix_fmt yuv420p -c:a aac -movflags +faststart "$FINAL"

codec=$(ffprobe -v error -select_streams v:0 -show_entries stream=codec_name -of default=nw=1:nk=1 "$FINAL")
width=$(ffprobe -v error -select_streams v:0 -show_entries stream=width -of default=nw=1:nk=1 "$FINAL")
height=$(ffprobe -v error -select_streams v:0 -show_entries stream=height -of default=nw=1:nk=1 "$FINAL")
fps=$(ffprobe -v error -select_streams v:0 -show_entries stream=r_frame_rate -of default=nw=1:nk=1 "$FINAL")
duration=$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$FINAL")
frames=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of default=nw=1:nk=1 "$FINAL")
audio_codec=$(ffprobe -v error -select_streams a:0 -show_entries stream=codec_name -of default=nw=1:nk=1 "$FINAL")

sample_rgb() {
  local at="$1"
  ffmpeg -hide_banner -loglevel error -ss "$at" -i "$FINAL" -frames:v 1 -vf "scale=1:1" -f rawvideo -pix_fmt rgb24 - 2>/dev/null | od -An -tu1 | tr -s ' ' | sed 's/^ //;s/ $//'
}
rgb_blue=$(sample_rgb 0.5)
rgb_red=$(sample_rgb 2.5)
rgb_green=$(sample_rgb 3.5)

[[ "$codec" == "h264" ]]
[[ "$audio_codec" == "aac" ]]
[[ "$width" == "360" && "$height" == "640" ]]
[[ "$fps" == "30/1" ]]
[[ "$frames" == "120" ]]
python3 - "$duration" "$rgb_blue" "$rgb_red" "$rgb_green" <<'PY'
import sys
v=float(sys.argv[1]); assert abs(v-4.0)<=0.08, v
samples=[]
for raw in sys.argv[2:]:
    rgb=tuple(map(int, raw.split()))
    assert len(rgb)==3, rgb
    samples.append(rgb)
b,r,g=samples
assert b[2] > b[0] and b[2] > b[1], b
assert r[0] > r[1] and r[0] > r[2], r
assert g[1] > g[0] and g[1] > g[2], g
PY

cat <<META
MP4=$FINAL
codec=$codec
audio_codec=$audio_codec
resolution=${width}x${height}
fps=$fps
duration=$duration
frames=$frames
sample_0.5s_blue=$rgb_blue
sample_2.5s_red=$rgb_red
sample_3.5s_green=$rgb_green
META
