#!/usr/bin/env bash
set -euo pipefail
f=app/src/main/java/com/localcut/editor/media/Media3PreviewController.kt
p=app/src/main/java/com/localcut/editor/media/PreviewController.kt
v=app/src/main/java/com/localcut/editor/ui/editor/components/PreviewPane.kt
[[ -f "$f" && -f "$p" && -f "$v" ]] || { echo 'FAIL preview controller files'; exit 1; }
grep -q 'CompositionPlayer.Builder' "$f"
grep -q 'setComposition' "$f"
grep -q 'player.prepare()' "$f"
grep -q 'durationUs == 0L' "$f"
grep -q 'player.stop()' "$f"
grep -q 'player.play()' "$f"
grep -q 'player.pause()' "$f"
grep -q 'player.seekTo' "$f"
grep -q 'currentPosition \* 1_000L' "$f"
grep -q 'player.release()' "$f"
grep -q 'loadRenderedFile' "$f"
grep -q 'withAudioAndVideoFrom' "$f"
grep -q 'setDurationUs(durationUs)' "$f"
grep -q 'Player.Listener' "$f"
grep -q 'PlayerView' "$f"
grep -q 'MutableStateFlow' "$p"
grep -q 'AndroidView' "$v"
grep -q 'onRelease = controller::unbindFrom' "$v"
echo 'PASS preview controller static contract'
