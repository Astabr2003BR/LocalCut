#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/localcut-core-tests"
rm -rf "$OUT"
mkdir -p "$OUT"
KOTLIN_BIN="$(cd "$(dirname "$(command -v kotlinc)")" && pwd)"
COROUTINES_JAR="$KOTLIN_BIN/../lib/kotlinx-coroutines-core-jvm.jar"
[[ -f "$COROUTINES_JAR" ]] || { echo "FAIL missing kotlinx-coroutines-core-jvm.jar"; exit 1; }

mapfile -t MAIN < <(
  find "$ROOT/app/src/main/java/com/localcut/editor" -name '*.kt' \
    ! -name 'MainActivity.kt' \
    ! -name 'AssetImporter.kt' \
    ! -name 'AndroidAssetImporter.kt' \
    ! -name 'AssetUriResolver.kt' \
    ! -name 'ProjectCompositionCompiler.kt' \
    ! -name 'TransformEffectFactory.kt' \
    ! -name 'Media3PreviewController.kt' \
    ! -name 'Media3ExportController.kt' \
    ! -name 'SafExportDestination.kt' \
    ! -name 'EditorScreen.kt' \
    ! -path '*/ui/editor/components/*' \
    | sort
)
mapfile -t TEST < <(find "$ROOT/app/src/test/java/com/localcut/editor" -name '*TestMain.kt' | sort)

kotlinc -cp "$COROUTINES_JAR" "${MAIN[@]}" "${TEST[@]}" -d "$OUT"
classes=(
  com.localcut.editor.acceptance.V0HostAcceptanceTestMainKt
  com.localcut.editor.domain.timeline.CoreTimelineTestMainKt
  com.localcut.editor.media.TransformInterpolatorTestMainKt
  com.localcut.editor.domain.timeline.TimelineMathTestMainKt
  com.localcut.editor.domain.timeline.TimelineSlicerTestMainKt
  com.localcut.editor.domain.history.HistoryManagerTestMainKt
  com.localcut.editor.media.RenderPlanCompilerTestMainKt
  com.localcut.editor.session.ProjectSessionTestMainKt
  com.localcut.editor.session.EditorSessionActionsTestMainKt
  com.localcut.editor.data.project.AtomicProjectStoreTestMainKt
  com.localcut.editor.media.PreviewTransportTestMainKt
  com.localcut.editor.media.ExportTransactionTestMainKt
  com.localcut.editor.media.ExportLifecycleCoordinatorTestMainKt
  com.localcut.editor.media.FinalPreviewRendererTestMainKt
  com.localcut.editor.data.assets.AssetImportPolicyTestMainKt
  com.localcut.editor.data.assets.ImportedClipFactoryTestMainKt
  com.localcut.editor.media.FinalPreviewPlannerTestMainKt
  com.localcut.editor.session.DebouncedProjectSaverTestMainKt
  com.localcut.editor.ui.editor.TimelineGeometryTestMainKt
  com.localcut.editor.ui.editor.TimelineHitTesterTestMainKt
  com.localcut.editor.ui.editor.TimelineDragPlannerTestMainKt
  com.localcut.editor.media.Media3CompositionBlueprintTestMainKt
  com.localcut.editor.media.PreviewControllerTestMainKt
  com.localcut.editor.ui.editor.EditorViewModelTestMainKt
)
for cls in "${classes[@]}"; do
  kotlin -classpath "$OUT:$COROUTINES_JAR" "$cls"
done
