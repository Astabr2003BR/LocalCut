package com.localcut.editor.ui.editor

import com.localcut.editor.media.PreviewController
import com.localcut.editor.media.PreviewState
import com.localcut.editor.session.EditorAction
import com.localcut.editor.session.ProjectSession
import com.localcut.editor.session.ProjectSessionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EditorUiState(
    val session: ProjectSessionState,
    val preview: PreviewState,
)

class EditorViewModel(
    private val session: ProjectSession,
    private val previewController: PreviewController,
) {
    private val mutableSessionState = MutableStateFlow(session.state)
    val sessionState: StateFlow<ProjectSessionState> = mutableSessionState.asStateFlow()
    val previewState: StateFlow<PreviewState> = previewController.state

    private val mutableState = MutableStateFlow(EditorUiState(session.state, previewController.state.value))
    val state: StateFlow<EditorUiState> = mutableState.asStateFlow()

    fun dispatch(action: EditorAction) {
        session.dispatch(action)
        sync()
    }

    fun play() { previewController.play(); sync() }
    fun pause() { previewController.pause(); sync() }
    fun seekToUs(positionUs: Long) { previewController.seekToUs(positionUs); sync() }
    fun stepFrames(deltaFrames: Int) { previewController.stepFrames(deltaFrames, previewController.state.value.fps); sync() }
    fun setLoopRange(startUs: Long, endUs: Long?) { previewController.setLoopRange(startUs, endUs); sync() }

    fun close() { previewController.release(); sync() }

    fun refreshSnapshot() = sync()

    private fun sync() {
        val currentSession = session.state
        mutableSessionState.value = currentSession
        mutableState.value = EditorUiState(currentSession, previewController.state.value)
    }
}
