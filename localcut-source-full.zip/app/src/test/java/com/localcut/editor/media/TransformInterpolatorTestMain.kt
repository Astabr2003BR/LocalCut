package com.localcut.editor.media

import com.localcut.editor.domain.model.TransformKeyframe
import com.localcut.editor.domain.model.TransformValue

private var passed = 0
private var failed = 0
private fun test(name: String, block: () -> Unit) {
    try { block(); passed++; println("PASS $name") } catch (t: Throwable) { failed++; println("FAIL $name: ${t.message}") }
}
private fun assertClose(expected: Double, actual: Double, eps: Double = 1e-9) {
    if (kotlin.math.abs(expected - actual) > eps) error("expected=$expected actual=$actual")
}
private fun assertEquals(expected: Any?, actual: Any?) { if (expected != actual) error("expected=$expected actual=$actual") }

fun main() {
    val frames = listOf(
        TransformKeyframe(0, TransformValue(x = 0.0, y = 10.0, scale = 1.0, rotationDeg = 0.0, opacity = 1.0)),
        TransformKeyframe(5_000_000, TransformValue(x = 100.0, y = 30.0, scale = 1.1, rotationDeg = 90.0, opacity = 0.5))
    )

    test("half duration interpolates linearly") {
        val v = TransformInterpolator.valueAt(frames, 2_500_000)
        assertClose(50.0, v.x)
        assertClose(20.0, v.y)
        assertClose(1.05, v.scale)
        assertClose(45.0, v.rotationDeg)
        assertClose(0.75, v.opacity)
    }
    test("exact keyframe timestamp is stable") {
        assertEquals(frames[1].value, TransformInterpolator.valueAt(frames, 5_000_000))
    }
    test("before first and after last clamp") {
        assertEquals(frames.first().value, TransformInterpolator.valueAt(frames, -1))
        assertEquals(frames.last().value, TransformInterpolator.valueAt(frames, 9_000_000))
    }
    test("single keyframe is constant") {
        val only = listOf(TransformKeyframe(123, TransformValue(scale = 2.0)))
        assertEquals(only[0].value, TransformInterpolator.valueAt(only, 999_999))
    }
    test("duplicate timestamp is rejected") {
        val dup = listOf(
            TransformKeyframe(0, TransformValue(scale = 1.0)),
            TransformKeyframe(0, TransformValue(scale = 2.0))
        )
        try {
            TransformInterpolator.valueAt(dup, 0)
            error("expected duplicate timestamp failure")
        } catch (e: IllegalArgumentException) {
            if (!e.message.orEmpty().contains("duplicate")) error("wrong failure: ${e.message}")
        }
    }
    test("empty list returns identity") {
        assertEquals(TransformValue(), TransformInterpolator.valueAt(emptyList(), 500))
    }

    println("RESULT passed=$passed failed=$failed")
    if (failed != 0) error("$failed tests failed")
}
