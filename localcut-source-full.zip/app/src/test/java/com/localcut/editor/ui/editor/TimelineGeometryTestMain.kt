package com.localcut.editor.ui.editor

private var passed = 0
private var failed = 0
private fun test(name: String, block: () -> Unit) {
    try { block(); println("PASS $name"); passed++ }
    catch (t: Throwable) { println("FAIL $name: ${t.message}"); failed++ }
}
private fun near(expected: Double, actual: Double, eps: Double = 0.000001) {
    check(kotlin.math.abs(expected - actual) <= eps) { "expected=$expected actual=$actual" }
}
private fun eq(expected: Long, actual: Long) { check(expected == actual) { "expected=$expected actual=$actual" } }

fun main() {
    test("one second maps to pixels at configured scale") {
        val g = TimelineGeometry(pixelsPerSecond = 100.0)
        near(100.0, g.timeToPx(1_000_000))
        eq(1_000_000, g.pxToTimeUs(100.0))
    }

    test("scroll offset shifts coordinate origin") {
        val g = TimelineGeometry(pixelsPerSecond = 120.0, scrollUs = 1_000_000)
        near(120.0, g.timeToPx(2_000_000))
        eq(2_000_000, g.pxToTimeUs(120.0))
    }

    test("negative visible coordinate clamps to timeline zero") {
        val g = TimelineGeometry(pixelsPerSecond = 100.0, scrollUs = 500_000)
        eq(0, g.pxToTimeUs(-100.0))
    }

    test("clip bounds preserve duration") {
        val g = TimelineGeometry(pixelsPerSecond = 200.0, scrollUs = 1_000_000)
        val b = g.clipBounds(startUs = 1_500_000, durationUs = 2_000_000)
        near(100.0, b.leftPx)
        near(400.0, b.widthPx)
        near(500.0, b.rightPx)
    }

    test("frame snap rounds to nearest 30fps frame and clamps") {
        val g = TimelineGeometry(pixelsPerSecond = 100.0)
        eq(33_333, g.snapToFrame(20_000, fps = 30, durationUs = 5_000_000))
        eq(0, g.snapToFrame(-1, fps = 30, durationUs = 5_000_000))
        eq(5_000_000, g.snapToFrame(9_000_000, fps = 30, durationUs = 5_000_000))
    }

    test("invalid scales and ranges are rejected") {
        runCatching { TimelineGeometry(0.0) }.onSuccess { error("zero scale accepted") }
        runCatching { TimelineGeometry(Double.NaN) }.onSuccess { error("NaN scale accepted") }
        val g = TimelineGeometry(100.0)
        runCatching { g.clipBounds(0, 0) }.onSuccess { error("zero duration accepted") }
        runCatching { g.snapToFrame(0, 0, 1) }.onSuccess { error("zero fps accepted") }
    }

    println("RESULT passed=$passed failed=$failed")
    check(failed == 0) { "$failed tests failed" }
}
