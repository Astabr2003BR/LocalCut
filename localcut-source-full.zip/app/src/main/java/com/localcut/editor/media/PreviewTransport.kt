package com.localcut.editor.media

data class PreviewLoopRange(val startUs: Long, val endUs: Long)

data class PreviewTransportState(
    val positionUs: Long = 0,
    val durationUs: Long = 0,
    val fps: Int = 30,
    val playing: Boolean = false,
    val loopRange: PreviewLoopRange? = null
)

class PreviewTransport {
    var state: PreviewTransportState = PreviewTransportState()
        private set

    fun load(durationUs: Long, fps: Int) {
        require(durationUs >= 0) { "duration must be >= 0" }
        require(fps > 0) { "fps must be > 0" }
        state = PreviewTransportState(durationUs = durationUs, fps = fps)
    }

    fun play() { state = state.copy(playing = true) }
    fun pause() { state = state.copy(playing = false) }

    fun seekToUs(positionUs: Long): Long {
        val clamped = positionUs.coerceIn(0L, state.durationUs)
        state = state.copy(positionUs = clamped)
        return clamped
    }

    fun stepFrames(deltaFrames: Int): Long {
        state = state.copy(playing = false)
        return seekToUs(PreviewFrameMath.step(state.positionUs, deltaFrames, state.fps, state.durationUs))
    }

    fun setLoopRange(startUs: Long, endUs: Long?) {
        if (endUs == null) {
            state = state.copy(loopRange = null)
            return
        }
        require(startUs >= 0) { "loop start must be >= 0" }
        require(endUs > startUs) { "loop end must be > start" }
        require(endUs <= state.durationUs) { "loop end exceeds duration" }
        state = state.copy(loopRange = PreviewLoopRange(startUs, endUs))
    }

    /** Returns a seek target when playback crosses an active loop boundary. */
    fun onPlayerPosition(positionUs: Long): Long? {
        val clamped = positionUs.coerceIn(0L, state.durationUs)
        val loop = state.loopRange
        if (state.playing && loop != null && clamped >= loop.endUs) {
            state = state.copy(positionUs = loop.startUs)
            return loop.startUs
        }
        state = state.copy(positionUs = clamped)
        return null
    }
}
