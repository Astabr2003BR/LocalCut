#!/usr/bin/env bash
set -euo pipefail

WORKFLOW=".github/workflows/android-debug.yml"

fail() {
  echo "FAIL: $*" >&2
  exit 1
}

require() {
  local pattern="$1"
  grep -Eq -- "$pattern" "$WORKFLOW" || fail "missing pattern: $pattern"
}

[[ -f "$WORKFLOW" ]] || fail "$WORKFLOW does not exist"

require '^name:[[:space:]]+Android Debug APK$'
require 'workflow_dispatch:'
require 'runs-on:[[:space:]]+ubuntu-24\.04'
require 'uses:[[:space:]]+actions/checkout@v7'
require 'uses:[[:space:]]+actions/setup-java@v6'
require 'distribution:[[:space:]]+temurin'
require "java-version:[[:space:]]+'?17'?"
require 'uses:[[:space:]]+gradle/actions/setup-gradle@v6'
require "gradle-version:[[:space:]]+'9\.5'"
require 'run:[[:space:]]+gradle[[:space:]]+--no-daemon[[:space:]]+testDebugUnitTest[[:space:]]+assembleDebug'
require 'uses:[[:space:]]+actions/upload-artifact@v7'
require 'name:[[:space:]]+localcut-debug-apk'
require 'path:[[:space:]]+app/build/outputs/apk/debug/app-debug\.apk'
require 'if-no-files-found:[[:space:]]+error'

if grep -Eq 'setup-android|sdkmanager|--licenses|yes[[:space:]]*\|' "$WORKFLOW"; then
  fail "workflow must use the Android SDK preinstalled on the runner and must not accept SDK licenses"
fi

echo 'PASS: GitHub Android workflow contract'
