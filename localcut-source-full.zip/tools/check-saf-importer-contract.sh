#!/usr/bin/env bash
set -euo pipefail
f=app/src/main/java/com/localcut/editor/data/assets/AndroidAssetImporter.kt
r=app/src/main/java/com/localcut/editor/data/assets/AssetUriResolver.kt
[[ -f "$f" ]] || { echo 'FAIL missing AndroidAssetImporter.kt'; exit 1; }
[[ -f "$r" ]] || { echo 'FAIL missing AssetUriResolver.kt'; exit 1; }
grep -q 'takePersistableUriPermission' "$f"
grep -q 'OpenableColumns.DISPLAY_NAME' "$f"
grep -q 'OpenableColumns.SIZE' "$f"
grep -q 'MediaMetadataRetriever' "$f"
grep -q 'openFileDescriptor(uri, "r")?.use' "$f"
grep -q 'AssetImportPolicy.create' "$f"
grep -q 'ASSET_UNAVAILABLE' "$r"
echo 'PASS saf importer static contract'
