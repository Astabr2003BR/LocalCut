package com.localcut.editor.acceptance

import com.localcut.editor.data.assets.AssetImportPolicy
import com.localcut.editor.data.assets.ImportedClipFactory
import com.localcut.editor.data.project.AtomicProjectStore
import com.localcut.editor.domain.model.*
import com.localcut.editor.media.FinalPreviewPlanner
import com.localcut.editor.media.PreviewTransport
import com.localcut.editor.media.RenderAssetResolver
import com.localcut.editor.session.*
import java.nio.file.Files

private var passed = 0
private var failed = 0

private fun test(name: String, block: () -> Unit) {
    try {
        block()
        passed++
        println("PASS $name")
    } catch (t: Throwable) {
        failed++
        println("FAIL $name: ${t.message}")
        t.printStackTrace()
    }
}

private fun checkEq(expected: Any?, actual: Any?) {
    check(expected == actual) { "expected=$expected actual=$actual" }
}

private class NoopScheduler : DelayScheduler {
    override fun schedule(delayMs: Long, action: () -> Unit): Cancellable = Cancellable { }
}

private class MemoryStore(initial: Project? = null) : com.localcut.editor.data.project.ProjectStore {
    var value: Project? = initial
    override fun save(project: Project): Result<Unit> = Result.success(Unit).also { value = project }
    override fun load(): Result<Project> = value?.let { Result.success(it) }
        ?: Result.failure(IllegalStateException("empty store"))
}

private class RecordingPreview : ProjectPreviewLoader {
    val projects = mutableListOf<Project>()
    override fun load(project: Project): Result<Unit> {
        projects += project
        return Result.success(Unit)
    }
}

private fun acceptanceProject(): Project {
    val video = Asset(
        id = "asset-vídeo-01",
        type = AssetType.VIDEO,
        uri = "content://media/video/01",
        sourceDurationUs = 10_000_000,
        sizeBytes = 1_234_567,
        displayName = "vídeo ação 01.mp4",
        mimeType = "video/mp4",
        fingerprint = "video-fingerprint"
    )
    val audio = Asset(
        id = "asset-áudio-01",
        type = AssetType.AUDIO,
        uri = "content://media/audio/01",
        sourceDurationUs = 6_000_000,
        sizeBytes = 456_789,
        displayName = "música teste.mp3",
        mimeType = "audio/mpeg",
        fingerprint = "audio-fingerprint"
    )
    val visualClip = Clip(
        id = "clip-v1",
        assetId = video.id,
        startUs = 0,
        durationUs = 6_000_000,
        sourceInUs = 0,
        sourceOutUs = 6_000_000,
        keyframes = listOf(
            TransformKeyframe(0, TransformValue(scale = 1.0)),
            TransformKeyframe(6_000_000, TransformValue(scale = 1.1))
        )
    )
    val audioClip = Clip(
        id = "clip-a1",
        assetId = audio.id,
        startUs = 0,
        durationUs = 6_000_000,
        sourceInUs = 0,
        sourceOutUs = 6_000_000,
        volume = 0.75
    )
    return Project.create("Projeto Aceitação 🎬", 1080, 1920, 30, id = "project-v0-acceptance").copy(
        assets = listOf(video, audio),
        tracks = listOf(
            Track("visual-1", TrackType.VISUAL, 0, clips = listOf(visualClip)),
            Track("audio-1", TrackType.AUDIO, 1, clips = listOf(audioClip))
        )
    )
}

private fun newSession(project: Project, preview: ProjectPreviewLoader = RecordingPreview()): ProjectSession {
    val store = MemoryStore(project)
    return ProjectSession(
        initialProject = project,
        preview = preview,
        autosave = DebouncedProjectSaver(store, NoopScheduler(), 250),
        store = store
    )
}

fun main() {
    test("T04 save reopen process recreation preserves exact project without duplication") {
        val original = acceptanceProject()
        val dir = Files.createTempDirectory("localcut-t04-")
        try {
            val store = AtomicProjectStore(dir)
            check(store.save(original).isSuccess)

            val preview = RecordingPreview()
            val recreated = ProjectSession(
                initialProject = Project.create("blank", 1080, 1920, 30),
                preview = preview,
                autosave = DebouncedProjectSaver(store, NoopScheduler(), 250),
                store = store
            )
            check(recreated.restore().isSuccess)
            checkEq(original, recreated.state.project)
            checkEq(original.assets.map { it.id }, recreated.state.project.assets.map { it.id })
            checkEq(
                original.tracks.flatMap { it.clips }.map { it.id },
                recreated.state.project.tracks.flatMap { it.clips }.map { it.id }
            )
            checkEq(original.assets.size, recreated.state.project.assets.map { it.id }.distinct().size)
            checkEq(
                original.tracks.sumOf { it.clips.size },
                recreated.state.project.tracks.flatMap { it.clips }.map { it.id }.distinct().size
            )
            checkEq(1, preview.projects.size)

            // A second restore on the same recreated session is idempotent.
            check(recreated.restore().isSuccess)
            checkEq(original, recreated.state.project)
            checkEq(1, preview.projects.size)
        } finally {
            dir.toFile().deleteRecursively()
        }
    }

    test("T05 move trim delete each undo redo through visible session state") {
        val session = newSession(acceptanceProject())
        session.dispatch(EditorAction.SelectClip("clip-v1"))

        session.dispatch(EditorAction.MoveSelected(1_000_000))
        checkEq(1_000_000L, session.state.project.findClip("clip-v1")!!.startUs)
        session.dispatch(EditorAction.Undo)
        checkEq(0L, session.state.project.findClip("clip-v1")!!.startUs)
        session.dispatch(EditorAction.Redo)
        checkEq(1_000_000L, session.state.project.findClip("clip-v1")!!.startUs)

        session.dispatch(EditorAction.TrimSelected(1_000_000, 5_000_000))
        var clip = session.state.project.findClip("clip-v1")!!
        checkEq(1_000_000L, clip.sourceInUs)
        checkEq(5_000_000L, clip.sourceOutUs)
        checkEq(4_000_000L, clip.durationUs)
        session.dispatch(EditorAction.Undo)
        clip = session.state.project.findClip("clip-v1")!!
        checkEq(0L, clip.sourceInUs)
        checkEq(6_000_000L, clip.sourceOutUs)
        session.dispatch(EditorAction.Redo)
        checkEq(4_000_000L, session.state.project.findClip("clip-v1")!!.durationUs)

        session.dispatch(EditorAction.DeleteSelected)
        checkEq(null, session.state.project.findClip("clip-v1"))
        session.dispatch(EditorAction.Undo)
        check(session.state.project.findClip("clip-v1") != null)
        session.dispatch(EditorAction.Redo)
        checkEq(null, session.state.project.findClip("clip-v1"))
    }

    test("T06 play pause seek transform resume loop frame-step and final-preview plan") {
        val preview = RecordingPreview()
        val session = newSession(acceptanceProject(), preview)
        session.dispatch(EditorAction.SelectClip("clip-v1"))

        val editedTransform = TransformValue(x = 32.0, y = -18.0, scale = 1.2, rotationDeg = 4.0, opacity = 0.9)
        session.dispatch(EditorAction.SetSelectedTransform(editedTransform))
        checkEq(editedTransform, session.state.project.findClip("clip-v1")!!.transform)
        check(preview.projects.isNotEmpty())
        checkEq(editedTransform, preview.projects.last().findClip("clip-v1")!!.transform)

        val transport = PreviewTransport()
        transport.load(durationUs = 6_000_000, fps = 30)
        transport.play()
        check(transport.state.playing)
        checkEq(2_250_000L, transport.seekToUs(2_250_000))
        transport.pause()
        check(!transport.state.playing)
        transport.play()
        transport.setLoopRange(2_000_000, 3_000_000)
        checkEq(2_000_000L, transport.onPlayerPosition(3_000_000))
        checkEq(2_033_333L, transport.stepFrames(1))
        check(!transport.state.playing)

        val finalPreview = FinalPreviewPlanner.plan(
            project = session.state.project,
            startUs = 1_000_000,
            endUs = 3_000_000,
            resolver = RenderAssetResolver { asset -> Result.success(asset.uri) }
        ).getOrThrow()
        checkEq(2_000_000L, finalPreview.renderPlan.durationUs)
        checkEq(1080, finalPreview.renderPlan.width)
        checkEq(1920, finalPreview.renderPlan.height)
        checkEq(30, finalPreview.renderPlan.fps)
        checkEq(editedTransform, finalPreview.slicedProject.findClip("clip-v1")!!.transform)
    }

    test("host vertical slice import animate save reopen and preview plan") {
        val dir = Files.createTempDirectory("localcut-vertical-")
        try {
            val store = AtomicProjectStore(dir)
            val saver = DebouncedProjectSaver(store, NoopScheduler(), 250)
            val preview = RecordingPreview()
            val session = ProjectSession(
                initialProject = Project.create("Vertical",1080,1920,30),
                preview = preview,
                autosave = saver,
                store = store,
            )
            val asset = AssetImportPolicy.create(
                id = "vertical-image",
                uri = "content://vertical/image",
                sizeBytes = 2048,
                displayName = "quadro 01.png",
                mimeType = "image/png",
                sourceDurationUs = null,
                lastModifiedMillis = 1234,
            ).getOrThrow()
            val clip = ImportedClipFactory.create(asset,"vertical-clip",0).getOrThrow()
            session.dispatch(EditorAction.AddImportedClip("visual-1",asset,clip))
            session.dispatch(EditorAction.SetSelectedKeyframes(listOf(
                TransformKeyframe(0,TransformValue(scale=1.0)),
                TransformKeyframe(5_000_000,TransformValue(scale=1.1)),
            )))
            check(saver.flushNow().isSuccess)

            val recreatedPreview = RecordingPreview()
            val recreated = ProjectSession(
                initialProject = Project.create("blank",1080,1920,30),
                preview = recreatedPreview,
                autosave = DebouncedProjectSaver(store,NoopScheduler(),250),
                store = store,
            )
            check(recreated.restore().isSuccess)
            val restoredClip = recreated.state.project.findClip("vertical-clip")!!
            checkEq(5_000_000L,restoredClip.durationUs)
            checkEq(2,restoredClip.keyframes.size)
            checkEq(1.1,restoredClip.keyframes.last().value.scale)

            val plan = FinalPreviewPlanner.plan(
                recreated.state.project,
                0,
                5_000_000,
                RenderAssetResolver { a -> Result.success(a.uri) },
            ).getOrThrow()
            checkEq(5_000_000L,plan.renderPlan.durationUs)
            checkEq(1,plan.renderPlan.visual.segments.filterIsInstance<com.localcut.editor.media.RenderSegment.Media>().size)
            checkEq(2,plan.slicedProject.findClip("vertical-clip")!!.keyframes.size)
        } finally {
            dir.toFile().deleteRecursively()
        }
    }

    println("RESULT passed=$passed failed=$failed")
    check(failed == 0) { "$failed acceptance tests failed" }
}
