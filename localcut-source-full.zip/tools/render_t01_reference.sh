#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="${1:-$ROOT/out/t01}"
mkdir -p "$OUT_DIR"
SRC="$OUT_DIR/source.png"
MP4="$OUT_DIR/t01-image-zoom.mp4"

ffmpeg -hide_banner -loglevel error -y \
  -f lavfi -i "testsrc2=size=1080x1920:rate=1" -frames:v 1 "$SRC"

ffmpeg -hide_banner -loglevel error -y \
  -loop 1 -i "$SRC" \
  -vf "zoompan=z='1+0.1*on/149':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=150:s=1080x1920:fps=30" \
  -frames:v 150 -c:v libx264 -preset veryfast -pix_fmt yuv420p -movflags +faststart "$MP4"

codec=$(ffprobe -v error -select_streams v:0 -show_entries stream=codec_name -of default=nw=1:nk=1 "$MP4")
width=$(ffprobe -v error -select_streams v:0 -show_entries stream=width -of default=nw=1:nk=1 "$MP4")
height=$(ffprobe -v error -select_streams v:0 -show_entries stream=height -of default=nw=1:nk=1 "$MP4")
fps=$(ffprobe -v error -select_streams v:0 -show_entries stream=avg_frame_rate -of default=nw=1:nk=1 "$MP4")
duration=$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$MP4")
frames=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of default=nw=1:nk=1 "$MP4")
first_md5=$(ffmpeg -hide_banner -loglevel error -i "$MP4" -frames:v 1 -f md5 - | cut -d= -f2)
last_md5=$(ffmpeg -hide_banner -loglevel error -ss 4.9 -i "$MP4" -frames:v 1 -f md5 - | cut -d= -f2)

[[ "$codec" == "h264" ]]
[[ "$width" == "1080" ]]
[[ "$height" == "1920" ]]
[[ "$fps" == "30/1" ]]
[[ "$frames" == "150" ]]
python3 - "$duration" <<'PY'
import sys
v=float(sys.argv[1])
assert abs(v-5.0)<=0.05, v
PY
[[ "$first_md5" != "$last_md5" ]]

cat <<META
MP4=$MP4
codec=$codec
resolution=${width}x${height}
fps=$fps
duration=$duration
frames=$frames
first_frame_md5=$first_md5
last_frame_md5=$last_md5
META
