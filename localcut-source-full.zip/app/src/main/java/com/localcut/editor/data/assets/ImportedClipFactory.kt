package com.localcut.editor.data.assets

import com.localcut.editor.domain.model.Asset
import com.localcut.editor.domain.model.AssetType
import com.localcut.editor.domain.model.Clip

enum class ImportedClipErrorCode {
    INVALID_ID,
    INVALID_START,
    INVALID_DURATION,
    MISSING_DURATION,
}

class ImportedClipException(
    val code: ImportedClipErrorCode,
    message: String,
) : Exception(message)

object ImportedClipFactory {
    const val DEFAULT_IMAGE_DURATION_US: Long = 5_000_000L

    fun create(
        asset: Asset,
        clipId: String,
        startUs: Long,
        imageDurationUs: Long = DEFAULT_IMAGE_DURATION_US,
    ): Result<Clip> = runCatching {
        if (asset.id.isBlank() || clipId.isBlank()) {
            throw ImportedClipException(ImportedClipErrorCode.INVALID_ID, "asset and clip ids must be non-blank")
        }
        if (startUs < 0) {
            throw ImportedClipException(ImportedClipErrorCode.INVALID_START, "clip start must be >= 0")
        }
        val durationUs = when (asset.type) {
            AssetType.IMAGE -> {
                if (imageDurationUs <= 0) {
                    throw ImportedClipException(ImportedClipErrorCode.INVALID_DURATION, "image duration must be > 0")
                }
                imageDurationUs
            }
            AssetType.VIDEO, AssetType.AUDIO -> asset.sourceDurationUs
                ?.takeIf { it > 0 }
                ?: throw ImportedClipException(
                    ImportedClipErrorCode.MISSING_DURATION,
                    "${asset.type.name.lowercase()} source duration is required",
                )
        }
        Clip(
            id = clipId,
            assetId = asset.id,
            startUs = startUs,
            durationUs = durationUs,
            sourceInUs = 0,
            sourceOutUs = durationUs,
        )
    }
}
