package com.localcut.editor.ui.editor

import com.localcut.editor.domain.model.Project
import com.localcut.editor.session.EditorAction

data class TimelineDragContext(
    val clipId: String,
    val region: TimelineHitRegion,
    val grabOffsetUs: Long,
) {
    val selectAction: EditorAction = EditorAction.SelectClip(clipId)
}

object TimelineDragPlanner {
    fun begin(
        project: Project,
        trackId: String,
        pointerXPx: Double,
        geometry: TimelineGeometry,
        handleWidthPx: Double,
    ): TimelineDragContext? {
        val hit = TimelineHitTester.hit(project, trackId, pointerXPx, geometry, handleWidthPx) ?: return null
        val clip = project.findClip(hit.clipId) ?: return null
        val pointerUs = geometry.pxToTimeUs(pointerXPx)
        val grabOffsetUs = if (hit.region == TimelineHitRegion.BODY) {
            (pointerUs - clip.startUs).coerceIn(0L, clip.durationUs)
        } else {
            0L
        }
        return TimelineDragContext(hit.clipId, hit.region, grabOffsetUs)
    }

    fun actionAt(
        context: TimelineDragContext,
        pointerXPx: Double,
        geometry: TimelineGeometry,
    ): EditorAction {
        val pointerUs = geometry.pxToTimeUs(pointerXPx)
        return when (context.region) {
            TimelineHitRegion.BODY -> EditorAction.MoveSelected(
                (pointerUs - context.grabOffsetUs).coerceAtLeast(0L)
            )
            TimelineHitRegion.LEFT_HANDLE -> EditorAction.TrimSelectedLeftEdge(pointerUs)
            TimelineHitRegion.RIGHT_HANDLE -> EditorAction.TrimSelectedRightEdge(pointerUs)
        }
    }
}
