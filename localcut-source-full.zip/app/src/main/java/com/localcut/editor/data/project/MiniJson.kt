package com.localcut.editor.data.project

internal sealed interface JValue
internal data class JObject(val fields: LinkedHashMap<String, JValue>) : JValue
internal data class JArray(val values: List<JValue>) : JValue
internal data class JString(val value: String) : JValue
internal data class JNumber(val raw: String) : JValue
internal data class JBool(val value: Boolean) : JValue
internal data object JNull : JValue

internal object MiniJson {
    fun parse(text: String): JValue = Parser(text).parse()

    private class Parser(private val text: String) {
        private var index = 0

        fun parse(): JValue {
            skipWs()
            val value = parseValue()
            skipWs()
            require(index == text.length) { "trailing JSON content at $index" }
            return value
        }

        private fun parseValue(): JValue {
            skipWs()
            require(index < text.length) { "unexpected end of JSON" }
            return when (val c = text[index]) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> JString(parseString())
                't' -> { expectLiteral("true"); JBool(true) }
                'f' -> { expectLiteral("false"); JBool(false) }
                'n' -> { expectLiteral("null"); JNull }
                '-', in '0'..'9' -> parseNumber()
                else -> error("unexpected JSON token '$c' at $index")
            }
        }

        private fun parseObject(): JObject {
            expect('{')
            skipWs()
            val map = LinkedHashMap<String, JValue>()
            if (peek('}')) { index++; return JObject(map) }
            while (true) {
                skipWs()
                require(peek('"')) { "object key must be a string at $index" }
                val key = parseString()
                skipWs(); expect(':')
                map[key] = parseValue()
                skipWs()
                when {
                    peek(',') -> index++
                    peek('}') -> { index++; return JObject(map) }
                    else -> error("expected ',' or '}' at $index")
                }
            }
        }

        private fun parseArray(): JArray {
            expect('[')
            skipWs()
            val values = mutableListOf<JValue>()
            if (peek(']')) { index++; return JArray(values) }
            while (true) {
                values += parseValue()
                skipWs()
                when {
                    peek(',') -> index++
                    peek(']') -> { index++; return JArray(values) }
                    else -> error("expected ',' or ']' at $index")
                }
            }
        }

        private fun parseString(): String {
            expect('"')
            val out = StringBuilder()
            while (index < text.length) {
                val c = text[index++]
                when (c) {
                    '"' -> return out.toString()
                    '\\' -> {
                        require(index < text.length) { "unterminated escape" }
                        when (val e = text[index++]) {
                            '"', '\\', '/' -> out.append(e)
                            'b' -> out.append('\b')
                            'f' -> out.append('\u000C')
                            'n' -> out.append('\n')
                            'r' -> out.append('\r')
                            't' -> out.append('\t')
                            'u' -> {
                                require(index + 4 <= text.length) { "short unicode escape" }
                                val hex = text.substring(index, index + 4)
                                out.append(hex.toInt(16).toChar())
                                index += 4
                            }
                            else -> error("invalid escape \\$e")
                        }
                    }
                    else -> {
                        require(c.code >= 0x20) { "unescaped control character" }
                        out.append(c)
                    }
                }
            }
            error("unterminated string")
        }

        private fun parseNumber(): JNumber {
            val start = index
            if (peek('-')) index++
            require(index < text.length) { "invalid number" }
            if (peek('0')) index++ else {
                require(text[index] in '1'..'9') { "invalid number at $index" }
                while (index < text.length && text[index].isDigit()) index++
            }
            if (peek('.')) {
                index++
                require(index < text.length && text[index].isDigit()) { "invalid fraction" }
                while (index < text.length && text[index].isDigit()) index++
            }
            if (index < text.length && (text[index] == 'e' || text[index] == 'E')) {
                index++
                if (index < text.length && (text[index] == '+' || text[index] == '-')) index++
                require(index < text.length && text[index].isDigit()) { "invalid exponent" }
                while (index < text.length && text[index].isDigit()) index++
            }
            return JNumber(text.substring(start, index))
        }

        private fun expectLiteral(literal: String) {
            require(text.regionMatches(index, literal, 0, literal.length)) { "expected $literal at $index" }
            index += literal.length
        }
        private fun expect(c: Char) { require(peek(c)) { "expected '$c' at $index" }; index++ }
        private fun peek(c: Char): Boolean = index < text.length && text[index] == c
        private fun skipWs() { while (index < text.length && text[index].isWhitespace()) index++ }
    }
}

internal fun jsonString(value: String): String = buildString {
    append('"')
    for (c in value) {
        when (c) {
            '"' -> append("\\\"")
            '\\' -> append("\\\\")
            '\b' -> append("\\b")
            '\u000C' -> append("\\f")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> if (c.code < 0x20) append("\\u%04x".format(c.code)) else append(c)
        }
    }
    append('"')
}

internal fun JValue.asObject(): JObject = this as? JObject ?: error("expected JSON object")
internal fun JValue.asArray(): JArray = this as? JArray ?: error("expected JSON array")
internal fun JValue.asString(): String = (this as? JString)?.value ?: error("expected JSON string")
internal fun JValue.asLong(): Long = (this as? JNumber)?.raw?.toLong() ?: error("expected integer")
internal fun JValue.asInt(): Int = asLong().also { require(it in Int.MIN_VALUE..Int.MAX_VALUE) }.toInt()
internal fun JValue.asDouble(): Double = (this as? JNumber)?.raw?.toDouble() ?: error("expected number")
internal fun JValue.asBoolean(): Boolean = (this as? JBool)?.value ?: error("expected boolean")
internal fun JObject.required(key: String): JValue = fields[key] ?: error("missing JSON field '$key'")
internal fun JObject.optional(key: String): JValue? = fields[key]
