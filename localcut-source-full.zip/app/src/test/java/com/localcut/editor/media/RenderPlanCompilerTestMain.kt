package com.localcut.editor.media

import com.localcut.editor.domain.model.*

private var passed=0
private var failed=0
private fun test(name:String,block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertEquals(e:Any?,a:Any?,m:String=""){if(e!=a)error("expected=$e actual=$a $m")}
private fun assertTrue(v:Boolean,m:String="expected true"){if(!v)error(m)}

private fun project(): Project {
    val img=Asset("img",AssetType.IMAGE,"content://img",null,100,"frame.png","image/png","fi")
    val vid=Asset("vid",AssetType.VIDEO,"content://vid",4_000_000,200,"clip.mp4","video/mp4","fv")
    val aud=Asset("aud",AssetType.AUDIO,"content://aud",8_000_000,300,"sound.m4a","audio/mp4","fa")
    val p=Project.create("render",1080,1920,30).copy(assets=listOf(img,vid,aud))
    val visual=listOf(
        Clip("i","img",0,5_000_000,0,5_000_000,keyframes=listOf(TransformKeyframe(0,TransformValue(scale=1.0)),TransformKeyframe(5_000_000,TransformValue(scale=1.1)))),
        Clip("v","vid",7_000_000,2_000_000,1_000_000,3_000_000)
    )
    val audio=listOf(Clip("a","aud",1_000_000,3_000_000,2_000_000,5_000_000,volume=0.7))
    return p.copy(tracks=p.tracks.map{when(it.type){TrackType.VISUAL->it.copy(clips=visual);TrackType.AUDIO->it.copy(clips=audio)}})
}
private val resolver = RenderAssetResolver { asset -> Result.success("resolved://${asset.id}") }

fun main(){
    test("export plan keeps project size fps and duration"){
        val plan=ProjectRenderPlanCompiler.compile(project(),RenderMode.EXPORT,resolver).getOrThrow()
        assertEquals(1080,plan.width); assertEquals(1920,plan.height); assertEquals(30,plan.fps); assertEquals(9_000_000L,plan.durationUs)
    }
    test("fast preview reduces longest edge to 720 preserving aspect"){
        val plan=ProjectRenderPlanCompiler.compile(project(),RenderMode.FAST_PREVIEW,resolver).getOrThrow()
        assertEquals(405,plan.width); assertEquals(720,plan.height)
        val full=ProjectRenderPlanCompiler.compile(project(),RenderMode.FULL_PREVIEW,resolver).getOrThrow()
        assertEquals(1080,full.width); assertEquals(1920,full.height)
    }
    test("visual sequence preserves ordering and explicit gaps"){
        val p=ProjectRenderPlanCompiler.compile(project(),RenderMode.EXPORT,resolver).getOrThrow()
        assertEquals(3,p.visual.segments.size)
        val first=p.visual.segments[0] as RenderSegment.Media
        val gap=p.visual.segments[1] as RenderSegment.Gap
        val last=p.visual.segments[2] as RenderSegment.Media
        assertEquals("i",first.clipId); assertEquals(5_000_000L,first.durationUs); assertTrue(first.isImage)
        assertEquals(2_000_000L,gap.durationUs)
        assertEquals("v",last.clipId); assertEquals(1_000_000L,last.sourceInUs); assertEquals(3_000_000L,last.sourceOutUs)
        assertEquals("resolved://img",first.uri)
    }
    test("audio sequence has leading and trailing gaps to project duration"){
        val p=ProjectRenderPlanCompiler.compile(project(),RenderMode.EXPORT,resolver).getOrThrow()
        assertEquals(listOf(1_000_000L,3_000_000L,5_000_000L),p.audio.segments.map{it.durationUs})
        assertTrue(p.audio.segments[0] is RenderSegment.Gap)
        val media=p.audio.segments[1] as RenderSegment.Media
        assertEquals("a",media.clipId); assertEquals(0.7,media.volume)
        assertTrue(p.audio.segments[2] is RenderSegment.Gap)
    }
    test("image media carries project fps and keyframes"){
        val first=ProjectRenderPlanCompiler.compile(project(),RenderMode.EXPORT,resolver).getOrThrow().visual.segments[0] as RenderSegment.Media
        assertEquals(30,first.imageFrameRate)
        assertEquals(2,first.keyframes.size)
    }
    test("unavailable asset returns typed failure"){
        val bad=RenderAssetResolver { asset -> if(asset.id=="vid") Result.failure(IllegalStateException("revoked")) else Result.success(asset.uri) }
        val result=ProjectRenderPlanCompiler.compile(project(),RenderMode.EXPORT,bad)
        assertTrue(result.isFailure)
        val e=result.exceptionOrNull() as RenderPlanException
        assertEquals(RenderPlanErrorCode.ASSET_UNAVAILABLE,e.code)
        assertEquals("vid",e.assetId)
    }
    test("invalid overlapping project fails before rendering"){
        val p=project()
        val vt=p.tracks.first{it.type==TrackType.VISUAL}
        val clips=vt.clips.toMutableList().also{it[1]=it[1].copy(startUs=4_000_000)}
        val bad=p.copy(tracks=p.tracks.map{if(it.id==vt.id)it.copy(clips=clips)else it})
        val result=ProjectRenderPlanCompiler.compile(bad,RenderMode.EXPORT,resolver)
        assertTrue(result.isFailure)
        assertEquals(RenderPlanErrorCode.INVALID_PROJECT,(result.exceptionOrNull() as RenderPlanException).code)
    }
    println("RESULT passed=$passed failed=$failed")
    if(failed!=0)error("$failed tests failed")
}
