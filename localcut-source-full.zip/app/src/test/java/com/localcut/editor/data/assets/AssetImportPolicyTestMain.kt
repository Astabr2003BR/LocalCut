package com.localcut.editor.data.assets

import com.localcut.editor.domain.model.AssetType

private var passed=0
private var failed=0
private fun test(name:String,block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertEquals(e:Any?,a:Any?,m:String=""){if(e!=a)error("expected=$e actual=$a $m")}
private fun assertTrue(v:Boolean,m:String="expected true"){if(!v)error(m)}

fun main(){
    test("supported mime maps to asset type case insensitively"){
        assertEquals(AssetType.IMAGE,AssetImportPolicy.typeForMime("image/png"))
        assertEquals(AssetType.VIDEO,AssetImportPolicy.typeForMime("Video/MP4"))
        assertEquals(AssetType.AUDIO,AssetImportPolicy.typeForMime("audio/mpeg"))
    }
    test("unsupported or blank mime is typed failure"){
        val a=AssetImportPolicy.create("id","content://x",10,"x.bin","application/octet-stream",null,null)
        assertTrue(a.isFailure)
        assertEquals(AssetImportErrorCode.UNSUPPORTED_TYPE,(a.exceptionOrNull() as AssetImportException).code)
        val b=AssetImportPolicy.create("id","content://x",10,"x",null,null,null)
        assertEquals(AssetImportErrorCode.UNSUPPORTED_TYPE,(b.exceptionOrNull() as AssetImportException).code)
    }
    test("zero or negative size is rejected"){
        for(size in listOf(0L,-1L)){
            val result=AssetImportPolicy.create("id","content://x",size,"x.png","image/png",null,null)
            assertEquals(AssetImportErrorCode.EMPTY_ASSET,(result.exceptionOrNull() as AssetImportException).code)
        }
    }
    test("blank uri or id is rejected"){
        val uri=AssetImportPolicy.create("id"," ",10,"x.png","image/png",null,null)
        assertEquals(AssetImportErrorCode.INVALID_METADATA,(uri.exceptionOrNull() as AssetImportException).code)
        val id=AssetImportPolicy.create(" ","content://x",10,"x.png","image/png",null,null)
        assertEquals(AssetImportErrorCode.INVALID_METADATA,(id.exceptionOrNull() as AssetImportException).code)
    }
    test("unicode display name survives and fingerprint is deterministic"){
        val a=AssetImportPolicy.create("a","content://media/123",1234,"vídeo ação 你好.mp4","video/mp4",5_000_000,999).getOrThrow()
        val b=AssetImportPolicy.create("b","content://media/123",1234,"vídeo ação 你好.mp4","video/mp4",5_000_000,999).getOrThrow()
        assertEquals("vídeo ação 你好.mp4",a.displayName)
        assertEquals(a.fingerprint,b.fingerprint)
        assertEquals(64,a.fingerprint.length)
    }
    test("fingerprint changes when stable source metadata changes"){
        val a=AssetImportPolicy.create("a","content://media/123",1234,"x.mp4","video/mp4",5_000_000,999).getOrThrow()
        val b=AssetImportPolicy.create("b","content://media/123",1235,"x.mp4","video/mp4",5_000_000,999).getOrThrow()
        val c=AssetImportPolicy.create("c","content://media/123",1234,"x.mp4","video/mp4",5_000_000,1000).getOrThrow()
        assertTrue(a.fingerprint!=b.fingerprint)
        assertTrue(a.fingerprint!=c.fingerprint)
    }
    test("unknown duration and last modified remain valid"){
        val a=AssetImportPolicy.create("a","content://media/img",120,"foto.png","image/png",null,null).getOrThrow()
        assertEquals(null,a.sourceDurationUs)
        assertEquals(AssetType.IMAGE,a.type)
    }
    println("RESULT passed=$passed failed=$failed")
    if(failed!=0)error("$failed tests failed")
}
