package com.localcut.editor.media

import com.localcut.editor.BuildContract
import com.localcut.editor.domain.model.*

private var passed = 0
private var failed = 0
private fun checkCase(name: String, block: () -> Unit) {
    try { block(); passed++; println("PASS $name") }
    catch (t: Throwable) { failed++; println("FAIL $name: ${t.message}") }
}
private fun assertThat(value: Boolean, message: String) { if (!value) error(message) }

fun main() {
    val image = Asset("img", AssetType.IMAGE, "content://img", null, 10, "Imagem ç.png", "image/png", "f1")
    val video = Asset("vid", AssetType.VIDEO, "content://vid", 8_000_000, 20, "video.mp4", "video/mp4", "f2")
    val audio = Asset("aud", AssetType.AUDIO, "content://aud", 9_000_000, 30, "audio.m4a", "audio/mp4", "f3")
    val project = Project(
        id = "p", schemaVersion = BuildContract.PROJECT_SCHEMA_VERSION, title = "P",
        width = 1080, height = 1920, fps = 30,
        assets = listOf(image, video, audio),
        tracks = listOf(
            Track("visual-1", TrackType.VISUAL, 0, clips = listOf(
                Clip("v1", "vid", startUs = 1_000_000, durationUs = 2_000_000, sourceInUs = 2_000_000, sourceOutUs = 4_000_000),
                Clip("i1", "img", startUs = 4_000_000, durationUs = 3_000_000, sourceInUs = 0, sourceOutUs = 3_000_000)
            )),
            Track("audio-1", TrackType.AUDIO, 1, clips = listOf(
                Clip("a1", "aud", startUs = 500_000, durationUs = 5_000_000, sourceInUs = 1_000_000, sourceOutUs = 6_000_000, volume = 0.5)
            ))
        )
    )
    val resolver = RenderAssetResolver { asset -> Result.success(asset.uri) }
    val plan = ProjectRenderPlanCompiler.compile(project, RenderMode.EXPORT, resolver).getOrThrow()

    checkCase("video keeps embedded audio and original source duration") {
        val bp = Media3CompositionBlueprintCompiler.compile(plan)
        val media = bp.visual.items.filterIsInstance<Media3BlueprintItem.Media>().first { it.clipId == "v1" }
        assertThat(media.outputTracks == Media3OutputTracks.AUDIO_VIDEO, "video must preserve embedded audio")
        assertThat(media.sourceMediaDurationUs == 8_000_000L, "expected original duration")
        assertThat(media.sourceInUs == 2_000_000L && media.sourceOutUs == 4_000_000L, "trim lost")
    }
    checkCase("image has explicit duration and fps and video only output") {
        val bp = Media3CompositionBlueprintCompiler.compile(plan)
        val media = bp.visual.items.filterIsInstance<Media3BlueprintItem.Media>().first { it.clipId == "i1" }
        assertThat(media.outputTracks == Media3OutputTracks.VIDEO_ONLY, "image must be video only")
        assertThat(media.presentationDurationUs == 3_000_000L, "image duration")
        assertThat(media.imageFrameRate == 30, "image fps")
    }
    checkCase("visual gaps are explicit and preserved") {
        val items = Media3CompositionBlueprintCompiler.compile(plan).visual.items
        assertThat(items[0] == Media3BlueprintItem.Gap(1_000_000L), "initial visual gap")
        assertThat(items[2] == Media3BlueprintItem.Gap(1_000_000L), "internal visual gap")
    }
    checkCase("external audio is separate and volume preserved") {
        val bp = Media3CompositionBlueprintCompiler.compile(plan)
        val media = bp.audio.items.filterIsInstance<Media3BlueprintItem.Media>().single()
        assertThat(media.outputTracks == Media3OutputTracks.AUDIO_ONLY, "external audio track type")
        assertThat(media.volume == 0.5, "volume")
        assertThat(bp.audio !== bp.visual, "sequences must differ")
    }
    checkCase("fast preview keeps timeline and transform coordinate space while reducing canvas") {
        val fastPlan = ProjectRenderPlanCompiler.compile(project, RenderMode.FAST_PREVIEW, resolver).getOrThrow()
        val bp = Media3CompositionBlueprintCompiler.compile(fastPlan)
        assertThat(bp.width < project.width || bp.height < project.height, "fast preview should reduce canvas")
        assertThat(bp.transformSpaceWidth == project.width, "transform X space must stay in project pixels")
        assertThat(bp.transformSpaceHeight == project.height, "transform Y space must stay in project pixels")
        assertThat(bp.durationUs == plan.durationUs, "duration must not change")
    }

    println("RESULT passed=$passed failed=$failed")
    if (failed != 0) error("failed=$failed")
}
