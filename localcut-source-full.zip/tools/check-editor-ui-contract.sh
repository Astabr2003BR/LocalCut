#!/usr/bin/env bash
set -euo pipefail
p=app/src/main/java/com/localcut/editor/ui/editor/components/PreviewPane.kt
t=app/src/main/java/com/localcut/editor/ui/editor/components/TimelinePane.kt
i=app/src/main/java/com/localcut/editor/ui/editor/components/InspectorPane.kt
for f in "$p" "$t" "$i"; do [[ -f "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done
grep -q 'AndroidView' "$p"
grep -q 'controller::bindTo' "$p"
grep -q 'onRelease = controller::unbindFrom' "$p"
grep -q 'Slider' "$p"
grep -q 'onStepFrames' "$p"
grep -q 'draggable' "$t"
grep -q 'onTrimLeft' "$t"
grep -q 'onTrimRight' "$t"
grep -q 'onMoveClip' "$t"
grep -q 'onSeek' "$t"
grep -q 'detectTapGestures' "$t"
grep -q 'onDelete' "$i"
grep -q 'onSplit' "$i"
grep -q 'onTransform' "$i"
grep -q 'onVolume' "$i"
grep -q 'onValueChangeFinished' "$i"
echo 'PASS editor ui components static contract'
