package com.localcut.editor.data.project

import com.localcut.editor.domain.model.Project

interface ProjectStore {
    fun save(project: Project): Result<Unit>
    fun load(): Result<Project>
}
