package com.localcut.editor.data.assets

import com.localcut.editor.domain.model.Asset
import com.localcut.editor.domain.model.AssetType
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

enum class AssetImportErrorCode {
    INVALID_METADATA,
    EMPTY_ASSET,
    UNSUPPORTED_TYPE,
}

class AssetImportException(
    val code: AssetImportErrorCode,
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause)

object AssetImportPolicy {
    fun typeForMime(mimeType: String): AssetType {
        val normalized = mimeType.substringBefore(';').trim().lowercase()
        return when {
            normalized.startsWith("image/") -> AssetType.IMAGE
            normalized.startsWith("video/") -> AssetType.VIDEO
            normalized.startsWith("audio/") -> AssetType.AUDIO
            else -> throw AssetImportException(
                AssetImportErrorCode.UNSUPPORTED_TYPE,
                "Unsupported MIME type: $mimeType",
            )
        }
    }

    fun create(
        id: String,
        uri: String,
        sizeBytes: Long?,
        displayName: String,
        mimeType: String?,
        sourceDurationUs: Long?,
        lastModifiedMillis: Long?,
    ): Result<Asset> = runCatching {
        if (id.isBlank() || uri.isBlank() || displayName.isBlank()) {
            throw AssetImportException(
                AssetImportErrorCode.INVALID_METADATA,
                "Asset id, URI and display name must be non-blank",
            )
        }
        if (sizeBytes != null && sizeBytes <= 0L) {
            throw AssetImportException(
                AssetImportErrorCode.EMPTY_ASSET,
                "Asset size must be greater than zero when known",
            )
        }
        if (sourceDurationUs != null && sourceDurationUs <= 0L) {
            throw AssetImportException(
                AssetImportErrorCode.INVALID_METADATA,
                "Asset duration must be greater than zero when known",
            )
        }
        val normalizedMime = mimeType?.substringBefore(';')?.trim()?.lowercase()
            ?.takeIf { it.isNotBlank() }
            ?: throw AssetImportException(
                AssetImportErrorCode.UNSUPPORTED_TYPE,
                "Missing MIME type",
            )
        val type = typeForMime(normalizedMime)
        val fingerprint = fingerprint(
            uri = uri,
            sizeBytes = sizeBytes,
            lastModifiedMillis = lastModifiedMillis,
            mimeType = normalizedMime,
        )
        Asset(
            id = id,
            type = type,
            uri = uri,
            sourceDurationUs = sourceDurationUs,
            sizeBytes = sizeBytes,
            displayName = displayName,
            mimeType = normalizedMime,
            fingerprint = fingerprint,
        )
    }

    private fun fingerprint(
        uri: String,
        sizeBytes: Long?,
        lastModifiedMillis: Long?,
        mimeType: String,
    ): String {
        val canonical = buildString {
            append("uri=").append(uri).append('\n')
            append("size=").append(sizeBytes?.toString() ?: "?").append('\n')
            append("modified=").append(lastModifiedMillis?.toString() ?: "?").append('\n')
            append("mime=").append(mimeType)
        }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString(separator = "") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }
}
