package com.localcut.editor.domain.model

enum class AssetType { IMAGE, VIDEO, AUDIO }

data class Asset(
    val id: String,
    val type: AssetType,
    val uri: String,
    val sourceDurationUs: Long?,
    val sizeBytes: Long?,
    val displayName: String,
    val mimeType: String?,
    val fingerprint: String
)
