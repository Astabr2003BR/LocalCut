package com.localcut.editor.ui.editor

import com.localcut.editor.BuildContract
import com.localcut.editor.data.project.ProjectStore
import com.localcut.editor.domain.model.*
import com.localcut.editor.media.PreviewController
import com.localcut.editor.media.PreviewState
import com.localcut.editor.session.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

private var passed=0; private var failed=0
private fun case(name:String, block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertThat(v:Boolean,m:String){if(!v) error(m)}

private class FakePreviewController : PreviewController {
    private val s=MutableStateFlow(PreviewState())
    override val state: StateFlow<PreviewState> = s
    var released=false
    override fun load(project: Project): Result<Unit> { s.value=s.value.copy(durationUs=5_000_000,fps=project.fps); return Result.success(Unit) }
    override fun play(){s.value=s.value.copy(playing=true)}
    override fun pause(){s.value=s.value.copy(playing=false)}
    override fun seekToUs(positionUs:Long){s.value=s.value.copy(positionUs=positionUs)}
    override fun stepFrames(deltaFrames:Int,fps:Int){}
    override fun setLoopRange(startUs:Long,endUs:Long?){}
    override fun release(){released=true}
}
private class NoSave : ProjectStore { override fun save(project:Project)=Result.success(Unit); override fun load()=Result.failure<Project>(IllegalStateException()) }
private class NoDelay: DelayScheduler { override fun schedule(delayMs:Long,action:()->Unit)=Cancellable{} }
private fun project():Project{
    val a=Asset("img",AssetType.IMAGE,"content://img",null,1,"a.png","image/png","f")
    return Project("p",BuildContract.PROJECT_SCHEMA_VERSION,"P",1080,1920,30,listOf(a),listOf(
        Track("visual-1",TrackType.VISUAL,0,clips=listOf(Clip("c","img",0,5_000_000,0,5_000_000))),
        Track("audio-1",TrackType.AUDIO,1)))
}
fun main(){
    case("dispatch mirrors session selection"){
        val p=project(); val preview=FakePreviewController(); val saver=DebouncedProjectSaver(NoSave(),NoDelay(),250)
        val session=ProjectSession(p, object: ProjectPreviewLoader { override fun load(project: Project)=Result.success(Unit) }, saver)
        val vm=EditorViewModel(session,preview)
        vm.dispatch(EditorAction.SelectClip("c"))
        assertThat(vm.state.value.session.selectedClipId=="c","selection")
    }
    case("transport delegates and preview state stays observable"){
        val p=project(); val preview=FakePreviewController(); val saver=DebouncedProjectSaver(NoSave(),NoDelay(),250)
        val vm=EditorViewModel(ProjectSession(p,object: ProjectPreviewLoader { override fun load(project: Project)=Result.success(Unit) },saver),preview)
        preview.load(p); vm.play(); assertThat(vm.state.value.preview.playing,"play")
        vm.seekToUs(2_000_000); assertThat(vm.state.value.preview.positionUs==2_000_000L,"seek")
        vm.pause(); assertThat(!vm.state.value.preview.playing,"pause")
    }
    case("close releases preview"){
        val p=project(); val preview=FakePreviewController(); val saver=DebouncedProjectSaver(NoSave(),NoDelay(),250)
        val vm=EditorViewModel(ProjectSession(p,object: ProjectPreviewLoader { override fun load(project: Project)=Result.success(Unit) },saver),preview)
        vm.close(); assertThat(preview.released,"release")
    }
    println("RESULT passed=$passed failed=$failed"); if(failed!=0) error("failed=$failed")
}
