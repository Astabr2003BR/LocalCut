package com.localcut.editor.media

import com.localcut.editor.domain.model.Asset
import com.localcut.editor.domain.model.AssetType
import com.localcut.editor.domain.model.Clip
import com.localcut.editor.domain.model.Project
import com.localcut.editor.domain.model.Track
import com.localcut.editor.domain.model.TrackType
import java.io.File
import java.nio.file.Files
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.runBlocking

private var passed = 0
private var failed = 0
private suspend fun case(name: String, block: suspend () -> Unit) {
    try { block(); passed++; println("PASS $name") }
    catch (t: Throwable) { failed++; println("FAIL $name: ${t.message}") }
}
private fun assertThat(value: Boolean, message: String) { if (!value) error(message) }

private fun project(): Project {
    val asset = Asset(
        id = "a",
        type = AssetType.VIDEO,
        uri = "content://a",
        sourceDurationUs = 6_000_000L,
        sizeBytes = 10L,
        displayName = "a.mp4",
        mimeType = "video/mp4",
        fingerprint = "fp-a",
    )
    val clip = Clip("c", "a", startUs = 1_000_000L, durationUs = 4_000_000L, sourceInUs = 500_000L, sourceOutUs = 4_500_000L)
    return Project.create(title = "P", width = 1080, height = 1920, fps = 30, id = "p").copy(
        assets = listOf(asset),
        tracks = listOf(Track(id = "v", type = TrackType.VISUAL, order = 0, clips = listOf(clip))),
    )
}

private class FakeExportController(
    private val terminal: ExportEvent,
    private val writeOutput: Boolean = true,
) : ExportController {
    var exportedProject: Project? = null
    var calls = 0
    override fun export(project: Project, destination: ExportDestination): Flow<ExportEvent> = flow {
        calls++
        exportedProject = project
        emit(ExportEvent.Started)
        if (terminal is ExportEvent.Completed) {
            val temp = Files.createTempFile("localcut-final-preview-source", ".mp4").toFile()
            if (writeOutput) temp.writeText("mp4")
            val commit = destination.commitFrom(temp)
            temp.delete()
            if (commit.isFailure) emit(ExportEvent.Failed("commit", commit.exceptionOrNull())) else emit(terminal)
        } else {
            emit(terminal)
        }
    }
    override fun cancel() = Unit
}

fun main() = runBlocking {
    case("success slices range and returns committed cache mp4") {
        val cache = Files.createTempDirectory("localcut-final-preview").toFile()
        val exporter = FakeExportController(ExportEvent.Completed)
        val renderer = FinalPreviewRenderer(exporter, cache)
        val result = renderer.renderRange(project(), 2_000_000L, 4_000_000L)
        assertThat(result.isSuccess, "render should succeed: ${result.exceptionOrNull()}")
        val file = result.getOrThrow()
        assertThat(file.exists() && file.readText() == "mp4", "output mp4 missing")
        val sliced = exporter.exportedProject ?: error("project not exported")
        val clip = sliced.tracks.single().clips.single()
        assertThat(clip.startUs == 0L, "slice must zero-shift clip")
        assertThat(clip.durationUs == 2_000_000L, "slice duration")
        assertThat(clip.sourceInUs == 1_500_000L && clip.sourceOutUs == 3_500_000L, "source trim")
        file.delete(); cache.deleteRecursively()
    }
    case("invalid range fails before export") {
        val cache = Files.createTempDirectory("localcut-final-preview").toFile()
        val exporter = FakeExportController(ExportEvent.Completed)
        val result = FinalPreviewRenderer(exporter, cache).renderRange(project(), 4_000_000L, 2_000_000L)
        assertThat(result.isFailure, "invalid range must fail")
        assertThat(exporter.calls == 0, "export must not start")
        cache.deleteRecursively()
    }
    case("export failure returns failure and leaves no final mp4") {
        val cache = Files.createTempDirectory("localcut-final-preview").toFile()
        val exporter = FakeExportController(ExportEvent.Failed("codec"))
        val result = FinalPreviewRenderer(exporter, cache).renderRange(project(), 2_000_000L, 4_000_000L)
        assertThat(result.isFailure, "failure expected")
        assertThat(cache.listFiles().orEmpty().none { it.extension == "mp4" }, "partial final preview left behind")
        cache.deleteRecursively()
    }
    case("cancelled export is a failed render result") {
        val cache = Files.createTempDirectory("localcut-final-preview").toFile()
        val exporter = FakeExportController(ExportEvent.Cancelled)
        val result = FinalPreviewRenderer(exporter, cache).renderRange(project(), 2_000_000L, 4_000_000L)
        assertThat(result.isFailure, "cancel should not return a playable file")
        cache.deleteRecursively()
    }
    println("RESULT passed=$passed failed=$failed")
    if (failed != 0) error("failed=$failed")
}
