#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

run() {
  local name="$1"
  shift
  echo "=== $name ==="
  "$@"
}

run "CORE REGRESSION" ./tools/run-core-tests.sh
run "T01 HOST RENDER" ./tools/render_t01_reference.sh
run "T02 HOST RENDER" ./tools/render_t02_reference.sh
run "T03 HOST RENDER" ./tools/render_t03_reference.sh
run "ANDROID SCAFFOLD CONTRACT" ./tools/check-android-scaffold.sh
run "SAF IMPORT CONTRACT" ./tools/check-saf-importer-contract.sh
run "MEDIA3 COMPOSITION CONTRACT" ./tools/check-media3-composition-contract.sh
run "PREVIEW CONTROLLER CONTRACT" ./tools/check-preview-controller-contract.sh
run "EDITOR UI CONTRACT" ./tools/check-editor-ui-contract.sh
run "EDITOR SCREEN CONTRACT" ./tools/check-editor-screen-contract.sh
run "MEDIA3 EXPORT CONTRACT" ./tools/check-media3-export-contract.sh
run "DIFF CHECK" git diff --check

echo "=== V0 HOST ACCEPTANCE: PASS ==="
echo "Android APK/device gates are intentionally not executed by this host-only script."
