package com.localcut.editor.media

import com.localcut.editor.domain.model.Project
import com.localcut.editor.domain.timeline.TimelineSlicer

enum class FinalPreviewPlanErrorCode {
    INVALID_RANGE,
    RENDER_PLAN_FAILED,
}

class FinalPreviewPlanException(
    val code: FinalPreviewPlanErrorCode,
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause)

data class FinalPreviewPlan(
    val slicedProject: Project,
    val renderPlan: RenderPlan,
)

object FinalPreviewPlanner {
    fun plan(
        project: Project,
        startUs: Long,
        endUs: Long,
        resolver: RenderAssetResolver,
    ): Result<FinalPreviewPlan> {
        val sliced = try {
            TimelineSlicer.slice(project, startUs, endUs)
        } catch (t: IllegalArgumentException) {
            return Result.failure(
                FinalPreviewPlanException(
                    FinalPreviewPlanErrorCode.INVALID_RANGE,
                    "Invalid final-preview range",
                    t,
                )
            )
        }

        val renderPlan = ProjectRenderPlanCompiler
            .compile(sliced, RenderMode.FULL_PREVIEW, resolver)
            .getOrElse { cause ->
                return Result.failure(
                    FinalPreviewPlanException(
                        FinalPreviewPlanErrorCode.RENDER_PLAN_FAILED,
                        "Unable to build final-preview render plan",
                        cause,
                    )
                )
            }

        return Result.success(FinalPreviewPlan(sliced, renderPlan))
    }
}
