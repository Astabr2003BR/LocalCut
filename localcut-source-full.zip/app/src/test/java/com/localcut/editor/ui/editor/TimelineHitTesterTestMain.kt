package com.localcut.editor.ui.editor

import com.localcut.editor.domain.model.*

private var passed = 0
private var failed = 0
private fun test(name: String, block: () -> Unit) {
    try { block(); println("PASS $name"); passed++ }
    catch (t: Throwable) { println("FAIL $name: ${t.message}"); failed++ }
}
private fun eq(expected: Any?, actual: Any?) { check(expected == actual) { "expected=$expected actual=$actual" } }

private fun project(): Project {
    val asset = Asset("a", AssetType.VIDEO, "content://a", 10_000_000, 1, "a.mp4", "video/mp4", "fp")
    val clip = Clip("c", "a", 1_000_000, 2_000_000, 0, 2_000_000)
    return Project.create("p", 1080, 1920, 30).copy(
        assets = listOf(asset),
        tracks = listOf(
            Track("visual-1", TrackType.VISUAL, 0, clips = listOf(clip)),
            Track("audio-1", TrackType.AUDIO, 1)
        )
    )
}

fun main() {
    val geometry = TimelineGeometry(100.0)

    test("outside clip returns no hit") {
        eq(null, TimelineHitTester.hit(project(), "visual-1", 99.0, geometry, 12.0))
        eq(null, TimelineHitTester.hit(project(), "visual-1", 301.0, geometry, 12.0))
    }

    test("clip center hits body") {
        eq(TimelineHit("c", TimelineHitRegion.BODY), TimelineHitTester.hit(project(), "visual-1", 200.0, geometry, 12.0))
    }

    test("near edges hits trim handles") {
        eq(TimelineHit("c", TimelineHitRegion.LEFT_HANDLE), TimelineHitTester.hit(project(), "visual-1", 105.0, geometry, 12.0))
        eq(TimelineHit("c", TimelineHitRegion.RIGHT_HANDLE), TimelineHitTester.hit(project(), "visual-1", 295.0, geometry, 12.0))
    }

    test("short clip chooses nearest edge when handle zones overlap") {
        val p = project().let { base ->
            base.copy(tracks = base.tracks.map { t ->
                if (t.id == "visual-1") t.copy(clips = listOf(t.clips.single().copy(durationUs = 100_000, sourceOutUs = 100_000))) else t
            })
        }
        eq(TimelineHitRegion.LEFT_HANDLE, TimelineHitTester.hit(p, "visual-1", 102.0, geometry, 12.0)!!.region)
        eq(TimelineHitRegion.RIGHT_HANDLE, TimelineHitTester.hit(p, "visual-1", 108.0, geometry, 12.0)!!.region)
    }

    test("unknown track and non finite input are safe") {
        eq(null, TimelineHitTester.hit(project(), "missing", 150.0, geometry, 12.0))
        runCatching { TimelineHitTester.hit(project(), "visual-1", Double.NaN, geometry, 12.0) }
            .onSuccess { error("NaN accepted") }
        runCatching { TimelineHitTester.hit(project(), "visual-1", 150.0, geometry, -1.0) }
            .onSuccess { error("negative handle width accepted") }
    }

    println("RESULT passed=$passed failed=$failed")
    check(failed == 0) { "$failed tests failed" }
}
