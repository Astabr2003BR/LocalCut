package com.localcut.editor.domain.model

data class TransformValue(
    val x: Double = 0.0,
    val y: Double = 0.0,
    val scale: Double = 1.0,
    val rotationDeg: Double = 0.0,
    val opacity: Double = 1.0
)

data class TransformKeyframe(
    val offsetUs: Long,
    val value: TransformValue
)
