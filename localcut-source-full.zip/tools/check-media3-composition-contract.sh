#!/usr/bin/env bash
set -euo pipefail
c=app/src/main/java/com/localcut/editor/media/ProjectCompositionCompiler.kt
e=app/src/main/java/com/localcut/editor/media/TransformEffectFactory.kt
b=app/src/main/java/com/localcut/editor/media/Media3CompositionBlueprint.kt
for f in "$c" "$e" "$b"; do [[ -f "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done
grep -q 'Composition.Builder' "$c"
grep -q 'EditedMediaItemSequence.Builder' "$c"
grep -q 'addGap' "$c"
grep -q 'setStartPositionUs' "$c"
grep -q 'setEndPositionUs' "$c"
grep -q 'setImageDurationMs' "$c"
grep -q 'setDurationUs(item.sourceMediaDurationUs)' "$c"
grep -q 'setFrameRate' "$c"
grep -q 'GainProcessor' "$c"
grep -q 'Presentation.createForWidthAndHeight' "$e"
grep -q 'MatrixTransformation' "$e"
grep -q 'transformSpaceWidth' "$e"
grep -q 'transformSpaceHeight' "$e"
grep -q 'AlphaScale' "$e"
echo 'PASS media3 composition static contract'
