package com.localcut.editor.domain.animation

import com.localcut.editor.domain.model.TransformKeyframe
import com.localcut.editor.domain.model.TransformValue

object TransformInterpolation {
    fun valueAt(keyframes: List<TransformKeyframe>, offsetUs: Long): TransformValue {
        if (keyframes.isEmpty()) return TransformValue()
        val sorted = keyframes.sortedBy { it.offsetUs }
        require(sorted.zipWithNext().none { (a, b) -> a.offsetUs == b.offsetUs }) {
            "duplicate keyframe timestamp"
        }
        if (sorted.size == 1 || offsetUs <= sorted.first().offsetUs) return sorted.first().value
        if (offsetUs >= sorted.last().offsetUs) return sorted.last().value
        val rightIndex = sorted.indexOfFirst { it.offsetUs >= offsetUs }
        val right = sorted[rightIndex]
        if (right.offsetUs == offsetUs) return right.value
        val left = sorted[rightIndex - 1]
        val spanUs = right.offsetUs - left.offsetUs
        val t = (offsetUs - left.offsetUs).toDouble() / spanUs.toDouble()
        return TransformValue(
            x = lerp(left.value.x, right.value.x, t),
            y = lerp(left.value.y, right.value.y, t),
            scale = lerp(left.value.scale, right.value.scale, t),
            rotationDeg = lerp(left.value.rotationDeg, right.value.rotationDeg, t),
            opacity = lerp(left.value.opacity, right.value.opacity, t)
        )
    }

    private fun lerp(a: Double, b: Double, t: Double): Double = a + (b - a) * t
}
