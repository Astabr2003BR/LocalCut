package com.localcut.editor.domain.timeline

import com.localcut.editor.domain.model.*

private var passed = 0
private var failed = 0
private fun test(name: String, block: () -> Unit) {
    try { block(); passed++; println("PASS $name") } catch (t: Throwable) { failed++; println("FAIL $name: ${t.message}") }
}
private fun assertEquals(expected: Any?, actual: Any?, msg: String = "") { if (expected != actual) error("expected=$expected actual=$actual $msg") }
private fun assertClose(expected: Double, actual: Double, eps: Double = 1e-9) { if (kotlin.math.abs(expected-actual) > eps) error("expected=$expected actual=$actual") }
private fun assertFails(block: () -> Unit) { try { block(); error("expected failure") } catch (_: IllegalArgumentException) {} }

private fun sourceProject(): Project {
    val video = Asset("v", AssetType.VIDEO, "content://v", 12_000_000, 10, "v.mp4", "video/mp4", "fv")
    val audio = Asset("a", AssetType.AUDIO, "content://a", 12_000_000, 10, "a.m4a", "audio/mp4", "fa")
    val extra = Asset("x", AssetType.IMAGE, "content://x", null, 5, "x.png", "image/png", "fx")
    val visual = Clip(
        id="vc", assetId="v", startUs=1_000_000, durationUs=6_000_000,
        sourceInUs=2_000_000, sourceOutUs=8_000_000,
        keyframes=listOf(
            TransformKeyframe(0, TransformValue(scale=1.0, x=0.0)),
            TransformKeyframe(6_000_000, TransformValue(scale=1.6, x=60.0))
        )
    )
    val outside = Clip("outside", "x", 8_000_000, 1_000_000, 0, 1_000_000)
    val audioClip = Clip("ac", "a", 0, 10_000_000, 0, 10_000_000)
    val p = Project.create("p",1080,1920,30).copy(assets=listOf(video,audio,extra))
    return p.copy(tracks=p.tracks.map {
        when(it.type) {
            TrackType.VISUAL -> it.copy(clips=listOf(visual,outside))
            TrackType.AUDIO -> it.copy(clips=listOf(audioClip))
        }
    })
}

fun main() {
    test("slice trims intersects removes outside and shifts to zero") {
        val src = sourceProject()
        val out = TimelineSlicer.slice(src, 3_000_000, 6_000_000)
        val visual = out.tracks.first { it.type == TrackType.VISUAL }.clips
        val audio = out.tracks.first { it.type == TrackType.AUDIO }.clips
        assertEquals(1, visual.size)
        assertEquals("vc", visual[0].id)
        assertEquals(0L, visual[0].startUs)
        assertEquals(3_000_000L, visual[0].durationUs)
        assertEquals(4_000_000L, visual[0].sourceInUs)
        assertEquals(7_000_000L, visual[0].sourceOutUs)
        assertEquals(1, audio.size)
        assertEquals(0L, audio[0].startUs)
        assertEquals(3_000_000L, audio[0].durationUs)
        assertEquals(3_000_000L, audio[0].sourceInUs)
        assertEquals(6_000_000L, audio[0].sourceOutUs)
        assertEquals(src.assets, out.assets, "assets must stay immutable")
    }

    test("slice creates animation boundary keyframes preserving visual state") {
        val out = TimelineSlicer.slice(sourceProject(), 3_000_000, 6_000_000)
        val clip = out.findClip("vc")!!
        assertEquals(listOf(0L, 3_000_000L), clip.keyframes.map { it.offsetUs })
        assertClose(1.2, clip.keyframes[0].value.scale)
        assertClose(20.0, clip.keyframes[0].value.x)
        assertClose(1.5, clip.keyframes[1].value.scale)
        assertClose(50.0, clip.keyframes[1].value.x)
    }

    test("full clip contained in range only shifts start") {
        val src = sourceProject()
        val out = TimelineSlicer.slice(src, 0, 10_000_000)
        val vc = out.findClip("vc")!!
        assertEquals(1_000_000L, vc.startUs)
        assertEquals(6_000_000L, vc.durationUs)
        assertEquals(src.findClip("vc")!!.keyframes, vc.keyframes)
    }

    test("invalid ranges fail") {
        val src = sourceProject()
        assertFails { TimelineSlicer.slice(src, -1, 1_000_000) }
        assertFails { TimelineSlicer.slice(src, 2_000_000, 2_000_000) }
        assertFails { TimelineSlicer.slice(src, 0, 11_000_000) }
    }

    println("RESULT passed=$passed failed=$failed")
    if (failed != 0) error("$failed tests failed")
}
