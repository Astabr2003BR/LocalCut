package com.localcut.editor.ui.editor

import com.localcut.editor.media.PreviewFrameMath
import kotlin.math.roundToLong

data class ClipPixelBounds(
    val leftPx: Double,
    val widthPx: Double,
) {
    val rightPx: Double get() = leftPx + widthPx
}

class TimelineGeometry(
    val pixelsPerSecond: Double,
    val scrollUs: Long = 0L,
) {
    init {
        require(pixelsPerSecond.isFinite() && pixelsPerSecond > 0.0) { "pixelsPerSecond must be finite and > 0" }
        require(scrollUs >= 0L) { "scrollUs must be >= 0" }
    }

    fun timeToPx(timeUs: Long): Double {
        require(timeUs >= 0L) { "timeUs must be >= 0" }
        return (timeUs - scrollUs).toDouble() / MICROS_PER_SECOND * pixelsPerSecond
    }

    fun pxToTimeUs(xPx: Double): Long {
        require(xPx.isFinite()) { "xPx must be finite" }
        val deltaUs = xPx / pixelsPerSecond * MICROS_PER_SECOND
        if (deltaUs <= -scrollUs.toDouble()) return 0L
        if (deltaUs >= Long.MAX_VALUE.toDouble() - scrollUs.toDouble()) return Long.MAX_VALUE
        return (scrollUs.toDouble() + deltaUs).roundToLong().coerceAtLeast(0L)
    }

    fun clipBounds(startUs: Long, durationUs: Long): ClipPixelBounds {
        require(startUs >= 0L) { "startUs must be >= 0" }
        require(durationUs > 0L) { "durationUs must be > 0" }
        return ClipPixelBounds(
            leftPx = timeToPx(startUs),
            widthPx = durationUs.toDouble() / MICROS_PER_SECOND * pixelsPerSecond,
        )
    }

    fun snapToFrame(timeUs: Long, fps: Int, durationUs: Long): Long {
        require(durationUs >= 0L) { "durationUs must be >= 0" }
        val frameUs = PreviewFrameMath.frameDurationUs(fps)
        val clamped = timeUs.coerceIn(0L, durationUs)
        if (clamped == 0L || clamped == durationUs) return clamped
        val frameIndex = (clamped.toDouble() / frameUs.toDouble()).roundToLong()
        val snapped = try {
            Math.multiplyExact(frameIndex, frameUs)
        } catch (_: ArithmeticException) {
            return durationUs
        }
        return snapped.coerceIn(0L, durationUs)
    }

    private companion object {
        const val MICROS_PER_SECOND = 1_000_000.0
    }
}
