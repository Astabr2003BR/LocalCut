package com.localcut.editor.domain.timeline

import com.localcut.editor.domain.model.Project

object TimelineMath {
    fun durationUs(project: Project): Long {
        var maxEnd = 0L
        for (clip in project.tracks.flatMap { it.clips }) {
            require(clip.startUs >= 0 && clip.durationUs >= 0) { "negative timeline value" }
            val end = try {
                Math.addExact(clip.startUs, clip.durationUs)
            } catch (_: ArithmeticException) {
                throw IllegalArgumentException("timeline duration overflow")
            }
            if (end > maxEnd) maxEnd = end
        }
        return maxEnd
    }
}
