package com.localcut.editor.session

import com.localcut.editor.domain.model.*

private class ImmediatePreview : ProjectPreviewLoader {
    override fun load(project: Project): Result<Unit> = Result.success(Unit)
}

private class NoopStore : com.localcut.editor.data.project.ProjectStore {
    override fun save(project: Project): Result<Unit> = Result.success(Unit)
    override fun load(): Result<Project> = Result.failure(IllegalStateException("unused"))
}

private class EditorActionsScheduler : DelayScheduler {
    override fun schedule(delayMs: Long, action: () -> Unit): Cancellable = Cancellable { }
}

private fun project(): Project {
    val asset = Asset("a1", AssetType.VIDEO, "content://a1", 10_000_000, 1, "vídeo.mp4", "video/mp4", "fp")
    val clip = Clip("c1", "a1", 0, 6_000_000, 0, 6_000_000)
    return Project.create("Teste", 1080, 1920, 30).copy(
        assets = listOf(asset),
        tracks = listOf(
            Track("visual-1", TrackType.VISUAL, 0, clips = listOf(clip)),
            Track("audio-1", TrackType.AUDIO, 1)
        )
    )
}

private fun newSession(): ProjectSession = ProjectSession(
    initialProject = project(),
    preview = ImmediatePreview(),
    autosave = DebouncedProjectSaver(NoopStore(), EditorActionsScheduler(), 300)
)

private var passed = 0
private var failed = 0
private fun test(name: String, body: () -> Unit) {
    try { body(); println("PASS $name"); passed++ }
    catch (t: Throwable) { println("FAIL $name: ${t.message}"); failed++ }
}
private fun checkEq(expected: Any?, actual: Any?) { check(expected == actual) { "expected=$expected actual=$actual" } }

fun main() {
    test("select move trim and delete selected clip") {
        val s = newSession()
        s.dispatch(EditorAction.SelectClip("c1"))
        checkEq("c1", s.state.selectedClipId)
        s.dispatch(EditorAction.MoveSelected(1_000_000))
        checkEq(1_000_000L, s.state.project.findClip("c1")!!.startUs)
        check(s.state.canUndo)
        s.dispatch(EditorAction.TrimSelected(1_000_000, 4_000_000))
        checkEq(3_000_000L, s.state.project.findClip("c1")!!.durationUs)
        s.dispatch(EditorAction.DeleteSelected)
        checkEq(null, s.state.project.findClip("c1"))
        checkEq(null, s.state.selectedClipId)
    }

    test("left and right trim handles are single session actions") {
        val s = newSession()
        s.dispatch(EditorAction.SelectClip("c1"))
        s.dispatch(EditorAction.TrimSelectedLeftEdge(1_000_000))
        var clip = s.state.project.findClip("c1")!!
        checkEq(1_000_000L, clip.startUs)
        checkEq(1_000_000L, clip.sourceInUs)
        checkEq(5_000_000L, clip.durationUs)
        s.dispatch(EditorAction.TrimSelectedRightEdge(4_000_000))
        clip = s.state.project.findClip("c1")!!
        checkEq(3_000_000L, clip.durationUs)
        checkEq(4_000_000L, clip.sourceOutUs)
        s.dispatch(EditorAction.Undo)
        checkEq(5_000_000L, s.state.project.findClip("c1")!!.durationUs)
        s.dispatch(EditorAction.Undo)
        clip = s.state.project.findClip("c1")!!
        checkEq(0L, clip.startUs)
        checkEq(0L, clip.sourceInUs)
        checkEq(6_000_000L, clip.durationUs)
    }

    test("split selected clip is reversible") {
        val s = newSession()
        s.dispatch(EditorAction.SelectClip("c1"))
        s.dispatch(EditorAction.SplitSelected(2_000_000))
        val clips = s.state.project.tracks.first { it.id == "visual-1" }.clips
        checkEq(2, clips.size)
        checkEq(2_000_000L, clips[0].durationUs)
        checkEq(4_000_000L, clips[1].durationUs)
        check(s.state.canUndo)
        s.dispatch(EditorAction.Undo)
        val restored = s.state.project.tracks.first { it.id == "visual-1" }.clips
        checkEq(1, restored.size)
        checkEq(6_000_000L, restored.single().durationUs)
        check(s.state.canRedo)
        s.dispatch(EditorAction.Redo)
        checkEq(2, s.state.project.tracks.first { it.id == "visual-1" }.clips.size)
    }

    test("selection of missing clip is rejected without modifying project") {
        val s = newSession()
        val before = s.state.project
        s.dispatch(EditorAction.SelectClip("missing"))
        checkEq(null, s.state.selectedClipId)
        check(s.state.lastError != null)
        checkEq(before, s.state.project)
    }

    test("selected operations require selection") {
        val s = newSession()
        s.dispatch(EditorAction.MoveSelected(2_000_000))
        check(s.state.lastError != null)
        checkEq(0L, s.state.project.findClip("c1")!!.startUs)
    }

    test("undo redo flags reflect history") {
        val s = newSession()
        check(!s.state.canUndo && !s.state.canRedo)
        s.dispatch(EditorAction.SelectClip("c1"))
        s.dispatch(EditorAction.MoveSelected(1_000_000))
        check(s.state.canUndo && !s.state.canRedo)
        s.dispatch(EditorAction.Undo)
        check(!s.state.canUndo && s.state.canRedo)
        s.dispatch(EditorAction.Redo)
        check(s.state.canUndo && !s.state.canRedo)
    }

    test("selected transform edit is reversible and refreshes session state") {
        val s = newSession()
        s.dispatch(EditorAction.SelectClip("c1"))
        val edited = TransformValue(x = 24.0, y = -12.0, scale = 1.15, rotationDeg = 3.0, opacity = 0.8)
        s.dispatch(EditorAction.SetSelectedTransform(edited))
        checkEq(edited, s.state.project.findClip("c1")!!.transform)
        check(s.state.canUndo)
        s.dispatch(EditorAction.Undo)
        checkEq(TransformValue(), s.state.project.findClip("c1")!!.transform)
        s.dispatch(EditorAction.Redo)
        checkEq(edited, s.state.project.findClip("c1")!!.transform)
    }

    test("selected volume edit is reversible and rejects negative gain") {
        val audio=Asset("a2",AssetType.AUDIO,"content://a2",6_000_000,1,"áudio.mp3","audio/mpeg","fa")
        val base=project()
        val audioClip=Clip("ca","a2",0,6_000_000,0,6_000_000,volume=1.0)
        val p=base.copy(
            assets=base.assets+audio,
            tracks=base.tracks.map { if(it.type==TrackType.AUDIO) it.copy(clips=listOf(audioClip)) else it }
        )
        val store=NoopStore()
        val s=ProjectSession(p,ImmediatePreview(),DebouncedProjectSaver(store,EditorActionsScheduler(),300))
        s.dispatch(EditorAction.SelectClip("ca"))
        s.dispatch(EditorAction.SetSelectedVolume(0.4))
        checkEq(0.4,s.state.project.findClip("ca")!!.volume)
        s.dispatch(EditorAction.Undo)
        checkEq(1.0,s.state.project.findClip("ca")!!.volume)
        s.dispatch(EditorAction.Redo)
        checkEq(0.4,s.state.project.findClip("ca")!!.volume)
        val before=s.state.project
        s.dispatch(EditorAction.SetSelectedVolume(-0.1))
        checkEq(before,s.state.project)
        check(s.state.lastError!=null)
    }

    test("selected keyframes are reversible and invalid offsets are rejected") {
        val s = newSession()
        s.dispatch(EditorAction.SelectClip("c1"))
        val frames = listOf(
            TransformKeyframe(0, TransformValue(scale = 1.0)),
            TransformKeyframe(6_000_000, TransformValue(scale = 1.1)),
        )
        s.dispatch(EditorAction.SetSelectedKeyframes(frames))
        checkEq(frames, s.state.project.findClip("c1")!!.keyframes)
        s.dispatch(EditorAction.Undo)
        checkEq(emptyList<TransformKeyframe>(), s.state.project.findClip("c1")!!.keyframes)
        s.dispatch(EditorAction.Redo)
        checkEq(frames, s.state.project.findClip("c1")!!.keyframes)

        val before = s.state.project
        s.dispatch(EditorAction.SetSelectedKeyframes(listOf(TransformKeyframe(7_000_000, TransformValue(scale = 1.2)))))
        checkEq(before, s.state.project)
        check(s.state.lastError != null)
    }

    test("imported clip enters through session as one undoable action and becomes selected") {
        val s = newSession()
        val asset = Asset("img-session",AssetType.IMAGE,"content://img-session",null,100,"foto nova.png","image/png","fsi")
        val clip = Clip("img-session-clip","img-session",7_000_000,2_000_000,0,2_000_000)
        s.dispatch(EditorAction.AddImportedClip("visual-1",asset,clip))
        checkEq(asset,s.state.project.assets.firstOrNull { it.id==asset.id })
        checkEq(clip,s.state.project.findClip(clip.id))
        checkEq(clip.id,s.state.selectedClipId)
        check(s.state.canUndo)
        s.dispatch(EditorAction.Undo)
        checkEq(null,s.state.project.findClip(clip.id))
        checkEq(null,s.state.project.assets.firstOrNull { it.id==asset.id })
        checkEq(null,s.state.selectedClipId)
    }

    println("RESULT passed=$passed failed=$failed")
    check(failed == 0) { "$failed tests failed" }
}
