package com.localcut.editor.domain.model

enum class TrackType { VISUAL, AUDIO }

data class Track(
    val id: String,
    val type: TrackType,
    val order: Int,
    val muted: Boolean = false,
    val hidden: Boolean = false,
    val locked: Boolean = false,
    val clips: List<Clip> = emptyList()
)
