package com.localcut.editor.domain.history

import com.localcut.editor.domain.model.*
import com.localcut.editor.domain.timeline.TimelineOps

private var passed=0
private var failed=0
private fun test(name:String, block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertEquals(e:Any?,a:Any?,m:String=""){if(e!=a)error("expected=$e actual=$a $m")}
private fun assertTrue(v:Boolean,m:String="expected true"){if(!v)error(m)}
private fun assertFalse(v:Boolean,m:String="expected false"){if(v)error(m)}

private fun project(): Project {
    val asset=Asset("a",AssetType.VIDEO,"content://a",10_000_000,1,"a.mp4","video/mp4","f")
    val p=Project.create("p",1080,1920,30).copy(assets=listOf(asset))
    val visual=p.tracks.first{it.type==TrackType.VISUAL}
    return TimelineOps.insertClip(p,visual.id,Clip("c","a",0,5_000_000,0,5_000_000))
}

fun main(){
    test("move undo redo"){
        val h=HistoryManager(project())
        h.execute(MoveClipCommand("c",2_000_000))
        assertEquals(2_000_000L,h.project.findClip("c")!!.startUs)
        h.undo()
        assertEquals(0L,h.project.findClip("c")!!.startUs)
        h.redo()
        assertEquals(2_000_000L,h.project.findClip("c")!!.startUs)
    }
    test("trim undo"){
        val h=HistoryManager(project())
        h.execute(TrimClipCommand("c",1_000_000,4_000_000))
        assertEquals(3_000_000L,h.project.findClip("c")!!.durationUs)
        h.undo()
        assertEquals(0L,h.project.findClip("c")!!.sourceInUs)
        assertEquals(5_000_000L,h.project.findClip("c")!!.sourceOutUs)
    }
    test("left edge trim undo redo is atomic"){
        val h=HistoryManager(project())
        h.execute(TrimClipLeftEdgeCommand("c",1_000_000))
        val trimmed=h.project.findClip("c")!!
        assertEquals(1_000_000L,trimmed.startUs)
        assertEquals(1_000_000L,trimmed.sourceInUs)
        assertEquals(4_000_000L,trimmed.durationUs)
        h.undo()
        val restored=h.project.findClip("c")!!
        assertEquals(0L,restored.startUs)
        assertEquals(0L,restored.sourceInUs)
        assertEquals(5_000_000L,restored.durationUs)
        h.redo()
        assertEquals(1_000_000L,h.project.findClip("c")!!.startUs)
    }
    test("right edge trim undo redo is atomic"){
        val h=HistoryManager(project())
        h.execute(TrimClipRightEdgeCommand("c",3_000_000))
        assertEquals(3_000_000L,h.project.findClip("c")!!.durationUs)
        h.undo()
        assertEquals(5_000_000L,h.project.findClip("c")!!.durationUs)
        h.redo()
        assertEquals(3_000_000L,h.project.findClip("c")!!.durationUs)
    }
    test("delete undo restores original track position"){
        val p=project()
        val visual=p.tracks.first{it.type==TrackType.VISUAL}
        val p2=TimelineOps.insertClip(p,visual.id,Clip("d","a",6_000_000,1_000_000,0,1_000_000))
        val h=HistoryManager(p2)
        h.execute(DeleteClipCommand("c"))
        assertEquals(listOf("d"),h.project.tracks.first{it.id==visual.id}.clips.map{it.id})
        h.undo()
        assertEquals(listOf("c","d"),h.project.tracks.first{it.id==visual.id}.clips.map{it.id})
    }
    test("new command after undo clears redo"){
        val h=HistoryManager(project())
        h.execute(MoveClipCommand("c",1_000_000))
        h.undo()
        assertTrue(h.canRedo)
        h.execute(MoveClipCommand("c",3_000_000))
        assertFalse(h.canRedo)
    }
    test("history never mutates source assets"){
        val p=project()
        val original=p.assets
        val h=HistoryManager(p)
        h.execute(MoveClipCommand("c",1_000_000)); h.undo(); h.redo(); h.undo()
        assertEquals(original,h.project.assets)
    }
    test("history cap drops oldest undo entry"){
        val h=HistoryManager(project(), maxEntries=2)
        h.execute(MoveClipCommand("c",1_000_000))
        h.execute(MoveClipCommand("c",2_000_000))
        h.execute(MoveClipCommand("c",3_000_000))
        h.undo(); h.undo()
        assertEquals(1_000_000L,h.project.findClip("c")!!.startUs)
        assertFalse(h.canUndo)
    }
    test("imported asset and clip are inserted atomically and undo removes both") {
        val p=project()
        val image=Asset("img-new",AssetType.IMAGE,"content://img-new",null,100,"imagem nova.png","image/png","fp-new")
        val clip=Clip("img-clip","img-new",5_000_000,2_000_000,0,2_000_000)
        val h=HistoryManager(p,10)
        h.execute(InsertAssetClipCommand(p.tracks.first{it.type==TrackType.VISUAL}.id,image,clip))
        assertEquals(image,h.project.assets.firstOrNull { it.id=="img-new" })
        assertEquals(clip,h.project.findClip("img-clip"))
        assertTrue(h.undo())
        assertEquals(null,h.project.assets.firstOrNull { it.id=="img-new" })
        assertEquals(null,h.project.findClip("img-clip"))
        assertTrue(h.redo())
        assertEquals(clip,h.project.findClip("img-clip"))
    }

    test("atomic import rejects duplicate asset id and wrong track type") {
        val p=project()
        val duplicate=p.assets.first()
        val clip=Clip("new-clip",duplicate.id,5_000_000,1_000_000,0,1_000_000)
        val h=HistoryManager(p,10)
        try {
            h.execute(InsertAssetClipCommand(p.tracks.first{it.type==TrackType.VISUAL}.id,duplicate,clip))
            error("expected duplicate asset rejection")
        } catch (_: IllegalArgumentException) {}
        val audio=Asset("audio-new",AssetType.AUDIO,"content://audio",2_000_000,10,"a.mp3","audio/mpeg","fa")
        val audioClip=Clip("audio-clip","audio-new",0,2_000_000,0,2_000_000)
        try {
            h.execute(InsertAssetClipCommand(p.tracks.first{it.type==TrackType.VISUAL}.id,audio,audioClip))
            error("expected track type rejection")
        } catch (_: IllegalArgumentException) {}
        assertEquals(p,h.project)
    }

    println("RESULT passed=$passed failed=$failed")
    if(failed!=0)error("$failed tests failed")
}
