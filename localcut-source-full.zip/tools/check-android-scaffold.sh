#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
required=(
  "$ROOT/settings.gradle.kts"
  "$ROOT/build.gradle.kts"
  "$ROOT/gradle.properties"
  "$ROOT/app/build.gradle.kts"
  "$ROOT/app/src/main/AndroidManifest.xml"
  "$ROOT/app/src/main/java/com/localcut/editor/MainActivity.kt"
)
for file in "${required[@]}"; do
  [[ -f "$file" ]] || { echo "FAIL missing $file"; exit 1; }
done

grep -q 'id("com.android.application") version "9.3.0"' "$ROOT/build.gradle.kts"
grep -q 'id("org.jetbrains.kotlin.plugin.compose") version "2.3.21"' "$ROOT/build.gradle.kts"
! grep -q 'org.jetbrains.kotlin.android' "$ROOT/build.gradle.kts"
! grep -q 'org.jetbrains.kotlin.android' "$ROOT/app/build.gradle.kts"
grep -q 'compileSdk = 37' "$ROOT/app/build.gradle.kts"
grep -q 'targetSdk = 36' "$ROOT/app/build.gradle.kts"
grep -q 'minSdk = 26' "$ROOT/app/build.gradle.kts"
grep -q 'androidx.compose:compose-bom:2026.09.00' "$ROOT/app/build.gradle.kts"
grep -q 'androidx.activity:activity-compose:1.13.0' "$ROOT/app/build.gradle.kts"
grep -q 'androidx.media3:media3-exoplayer:1.11.1' "$ROOT/app/build.gradle.kts"
grep -q 'androidx.media3:media3-transformer:1.11.1' "$ROOT/app/build.gradle.kts"
grep -q 'androidx.media3:media3-effect:1.11.1' "$ROOT/app/build.gradle.kts"
grep -q 'org.jetbrains.kotlinx:kotlinx-serialization-json:1.11.0' "$ROOT/app/build.gradle.kts"
grep -q 'namespace = "com.localcut.editor"' "$ROOT/app/build.gradle.kts"
grep -q 'package com.localcut.editor' "$ROOT/app/src/main/java/com/localcut/editor/MainActivity.kt"
grep -q 'android:name=".MainActivity"' "$ROOT/app/src/main/AndroidManifest.xml"
echo 'PASS android scaffold static contract'
