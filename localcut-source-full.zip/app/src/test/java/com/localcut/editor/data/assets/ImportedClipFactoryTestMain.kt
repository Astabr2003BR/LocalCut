package com.localcut.editor.data.assets

import com.localcut.editor.domain.model.*

private var passed=0
private var failed=0
private fun test(name:String,block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertEquals(e:Any?,a:Any?,m:String=""){if(e!=a)error("expected=$e actual=$a $m")}
private fun assertTrue(v:Boolean,m:String="expected true"){if(!v)error(m)}

fun main(){
    test("image clip uses five second default duration") {
        val asset=Asset("i",AssetType.IMAGE,"content://i",null,10,"foto.png","image/png","f")
        val clip=ImportedClipFactory.create(asset,"c",1_000_000).getOrThrow()
        assertEquals(1_000_000L,clip.startUs)
        assertEquals(5_000_000L,clip.durationUs)
        assertEquals(0L,clip.sourceInUs)
        assertEquals(5_000_000L,clip.sourceOutUs)
    }
    test("image clip accepts explicit positive duration") {
        val asset=Asset("i",AssetType.IMAGE,"content://i",null,10,"foto.png","image/png","f")
        val clip=ImportedClipFactory.create(asset,"c",0,imageDurationUs=2_500_000).getOrThrow()
        assertEquals(2_500_000L,clip.durationUs)
        assertEquals(2_500_000L,clip.sourceOutUs)
    }
    test("video and audio clips use known source duration") {
        for(type in listOf(AssetType.VIDEO,AssetType.AUDIO)) {
            val asset=Asset(type.name,type,"content://${type.name}",7_000_000,10,"m","x/y","f")
            val clip=ImportedClipFactory.create(asset,"c-${type.name}",0).getOrThrow()
            assertEquals(7_000_000L,clip.durationUs)
            assertEquals(7_000_000L,clip.sourceOutUs)
        }
    }
    test("video or audio without known duration fails typed") {
        val asset=Asset("v",AssetType.VIDEO,"content://v",null,10,"v.mp4","video/mp4","f")
        val result=ImportedClipFactory.create(asset,"c",0)
        assertTrue(result.isFailure)
        assertEquals(ImportedClipErrorCode.MISSING_DURATION,(result.exceptionOrNull() as ImportedClipException).code)
    }
    test("invalid start image duration and ids fail") {
        val asset=Asset("i",AssetType.IMAGE,"content://i",null,10,"foto.png","image/png","f")
        assertEquals(ImportedClipErrorCode.INVALID_START,(ImportedClipFactory.create(asset,"c",-1).exceptionOrNull() as ImportedClipException).code)
        assertEquals(ImportedClipErrorCode.INVALID_DURATION,(ImportedClipFactory.create(asset,"c",0,0).exceptionOrNull() as ImportedClipException).code)
        assertEquals(ImportedClipErrorCode.INVALID_ID,(ImportedClipFactory.create(asset," ",0).exceptionOrNull() as ImportedClipException).code)
    }
    println("RESULT passed=$passed failed=$failed")
    if(failed!=0)error("$failed tests failed")
}
