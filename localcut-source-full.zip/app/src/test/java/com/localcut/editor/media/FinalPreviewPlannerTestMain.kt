package com.localcut.editor.media

import com.localcut.editor.domain.model.*
import com.localcut.editor.domain.timeline.TimelineOps

private var passed=0
private var failed=0
private fun test(name:String,block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertEquals(e:Any?,a:Any?,m:String=""){if(e!=a)error("expected=$e actual=$a $m")}
private fun assertTrue(v:Boolean,m:String="expected true"){if(!v)error(m)}
private fun assertDouble(e:Double,a:Double,eps:Double=1e-9){if(kotlin.math.abs(e-a)>eps)error("expected=$e actual=$a")}

private fun animatedProject(): Project {
    val asset=Asset("img",AssetType.IMAGE,"content://img",5_000_000,100,"frame.png","image/png","fp")
    val clip=Clip(
        id="c1", assetId="img", startUs=0, durationUs=5_000_000,
        sourceInUs=0, sourceOutUs=5_000_000,
        keyframes=listOf(
            TransformKeyframe(0,TransformValue(scale=1.0)),
            TransformKeyframe(5_000_000,TransformValue(scale=1.1)),
        )
    )
    val base=Project.create("preview",1080,1920,30)
    return base.copy(
        assets=listOf(asset),
        tracks=base.tracks.map { if(it.type==TrackType.VISUAL) it.copy(clips=listOf(clip)) else it }
    )
}

fun main(){
    val resolver=RenderAssetResolver { Result.success(it.uri) }
    test("range preview slices to zero and keeps full project resolution"){
        val original=animatedProject()
        val result=FinalPreviewPlanner.plan(original,1_000_000,2_000_000,resolver).getOrThrow()
        assertEquals(1_000_000L,result.slicedProject.tracks.first { it.type==TrackType.VISUAL }.clips.single().durationUs)
        assertEquals(0L,result.slicedProject.tracks.first { it.type==TrackType.VISUAL }.clips.single().startUs)
        assertEquals(1_000_000L,result.renderPlan.durationUs)
        assertEquals(1080,result.renderPlan.width)
        assertEquals(1920,result.renderPlan.height)
        assertEquals(original,animatedProject(),"planner must not mutate source project")
    }
    test("range preview synthesizes correct animation values at both boundaries"){
        val result=FinalPreviewPlanner.plan(animatedProject(),1_000_000,2_000_000,resolver).getOrThrow()
        val frames=result.slicedProject.tracks.first { it.type==TrackType.VISUAL }.clips.single().keyframes
        assertEquals(2,frames.size)
        assertEquals(0L,frames[0].offsetUs)
        assertEquals(1_000_000L,frames[1].offsetUs)
        assertDouble(1.02,frames[0].value.scale)
        assertDouble(1.04,frames[1].value.scale)
    }
    test("invalid range is typed failure"){
        val result=FinalPreviewPlanner.plan(animatedProject(),2_000_000,1_000_000,resolver)
        assertTrue(result.isFailure)
        val error=result.exceptionOrNull() as FinalPreviewPlanException
        assertEquals(FinalPreviewPlanErrorCode.INVALID_RANGE,error.code)
    }
    test("missing asset remains typed render failure"){
        val resolverMissing=RenderAssetResolver { Result.failure(IllegalStateException("revoked")) }
        val result=FinalPreviewPlanner.plan(animatedProject(),0,1_000_000,resolverMissing)
        assertTrue(result.isFailure)
        val error=result.exceptionOrNull() as FinalPreviewPlanException
        assertEquals(FinalPreviewPlanErrorCode.RENDER_PLAN_FAILED,error.code)
        assertEquals(RenderPlanErrorCode.ASSET_UNAVAILABLE,(error.cause as RenderPlanException).code)
    }
    test("planned preview snapshot is immutable when later edits create a new project") {
        val original=animatedProject()
        val planned=FinalPreviewPlanner.plan(original,0,2_000_000,resolver).getOrThrow()
        val edited=TimelineOps.setTransform(original,"c1",TransformValue(scale=1.5))
        assertDouble(1.0,planned.slicedProject.findClip("c1")!!.transform.scale)
        assertDouble(1.5,edited.findClip("c1")!!.transform.scale)
        val media=planned.renderPlan.visual.segments.filterIsInstance<RenderSegment.Media>().single()
        assertDouble(1.0,media.transform.scale)
    }
    println("RESULT passed=$passed failed=$failed")
    if(failed!=0)error("$failed tests failed")
}
