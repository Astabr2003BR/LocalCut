package com.localcut.editor.domain.history

import com.localcut.editor.domain.model.Asset
import com.localcut.editor.domain.model.Clip
import com.localcut.editor.domain.model.Project
import com.localcut.editor.domain.model.TransformKeyframe
import com.localcut.editor.domain.model.TransformValue
import com.localcut.editor.domain.timeline.TimelineEditException
import com.localcut.editor.domain.timeline.TimelineErrorCode
import com.localcut.editor.domain.timeline.TimelineOps
import com.localcut.editor.domain.timeline.TimelineValidator

data class CommandResult(val project: Project, val inverse: EditorCommand)

interface EditorCommand {
    fun apply(project: Project): CommandResult
}

data class InsertAssetClipCommand(
    val trackId: String,
    val asset: Asset,
    val clip: Clip,
) : EditorCommand {
    override fun apply(project: Project): CommandResult = CommandResult(
        project = TimelineOps.insertAssetClip(project, trackId, asset, clip),
        inverse = RemoveImportedAssetClipCommand(trackId, asset, clip),
    )
}

private data class RemoveImportedAssetClipCommand(
    val trackId: String,
    val asset: Asset,
    val clip: Clip,
) : EditorCommand {
    override fun apply(project: Project): CommandResult = CommandResult(
        project = TimelineOps.removeImportedAssetClip(project, trackId, asset.id, clip.id),
        inverse = InsertAssetClipCommand(trackId, asset, clip),
    )
}

data class MoveClipCommand(val clipId: String, val newStartUs: Long) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val old = project.findClip(clipId)
            ?: throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
        return CommandResult(
            project = TimelineOps.moveClip(project, clipId, newStartUs),
            inverse = MoveClipCommand(clipId, old.startUs)
        )
    }
}

data class SetTransformCommand(val clipId: String, val transform: TransformValue) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val old = project.findClip(clipId)
            ?: throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
        return CommandResult(
            project = TimelineOps.setTransform(project, clipId, transform),
            inverse = SetTransformCommand(clipId, old.transform)
        )
    }
}

data class SetVolumeCommand(val clipId: String, val volume: Double) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val old = project.findClip(clipId)
            ?: throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
        return CommandResult(
            project = TimelineOps.setVolume(project, clipId, volume),
            inverse = SetVolumeCommand(clipId, old.volume)
        )
    }
}

data class SetKeyframesCommand(val clipId: String, val keyframes: List<TransformKeyframe>) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val old = project.findClip(clipId)
            ?: throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
        return CommandResult(
            project = TimelineOps.setKeyframes(project, clipId, keyframes),
            inverse = SetKeyframesCommand(clipId, old.keyframes)
        )
    }
}

data class TrimClipCommand(
    val clipId: String,
    val newSourceInUs: Long,
    val newSourceOutUs: Long
) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val old = project.findClip(clipId)
            ?: throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
        return CommandResult(
            project = TimelineOps.trimClip(project, clipId, newSourceInUs, newSourceOutUs),
            inverse = TrimClipCommand(clipId, old.sourceInUs, old.sourceOutUs)
        )
    }
}


data class TrimClipLeftEdgeCommand(
    val clipId: String,
    val newProjectStartUs: Long
) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val old = project.findClip(clipId)
            ?: throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
        val oldEndUs = clipEnd(old)
        return CommandResult(
            project = TimelineOps.trimClipEdges(project, clipId, newProjectStartUs, oldEndUs),
            inverse = TrimClipLeftEdgeCommand(clipId, old.startUs)
        )
    }
}

data class TrimClipRightEdgeCommand(
    val clipId: String,
    val newProjectEndUs: Long
) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val old = project.findClip(clipId)
            ?: throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
        val oldEndUs = clipEnd(old)
        return CommandResult(
            project = TimelineOps.trimClipEdges(project, clipId, old.startUs, newProjectEndUs),
            inverse = TrimClipRightEdgeCommand(clipId, oldEndUs)
        )
    }
}

data class SplitClipCommand(val clipId: String, val splitAtProjectUs: Long) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val trackIndex = project.tracks.indexOfFirst { track -> track.clips.any { it.id == clipId } }
        if (trackIndex < 0) {
            throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
        }
        val track = project.tracks[trackIndex]
        val clipIndex = track.clips.indexOfFirst { it.id == clipId }
        val original = track.clips[clipIndex]
        val splitProject = TimelineOps.splitClip(project, clipId, splitAtProjectUs)
        val splitTrack = splitProject.tracks[trackIndex]
        val second = splitTrack.clips.getOrNull(clipIndex + 1)
            ?: throw IllegalStateException("split did not create second clip")
        return CommandResult(
            project = splitProject,
            inverse = RestoreSplitCommand(
                trackId = track.id,
                clipIndex = clipIndex,
                original = original,
                secondClipId = second.id,
                splitAtProjectUs = splitAtProjectUs
            )
        )
    }
}

private data class RestoreSplitCommand(
    val trackId: String,
    val clipIndex: Int,
    val original: Clip,
    val secondClipId: String,
    val splitAtProjectUs: Long
) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        val trackIndex = project.tracks.indexOfFirst { it.id == trackId }
        if (trackIndex < 0) throw TimelineEditException(TimelineErrorCode.TRACK_NOT_FOUND, "track $trackId not found")
        val track = project.tracks[trackIndex]
        val firstIndex = track.clips.indexOfFirst { it.id == original.id }
        val secondIndex = track.clips.indexOfFirst { it.id == secondClipId }
        if (firstIndex < 0 || secondIndex < 0 || secondIndex != firstIndex + 1) {
            throw TimelineEditException(TimelineErrorCode.INVALID_PROJECT, "split clips are not adjacent")
        }
        val clips = track.clips.toMutableList()
        clips[firstIndex] = original
        clips.removeAt(secondIndex)
        val tracks = project.tracks.toMutableList().also { it[trackIndex] = track.copy(clips = clips) }
        val restored = project.copy(tracks = tracks)
        val issues = TimelineValidator.validate(restored)
        if (issues.isNotEmpty()) {
            throw TimelineEditException(TimelineErrorCode.INVALID_PROJECT, "restored split invalid: ${issues.first()}")
        }
        return CommandResult(restored, SplitClipCommand(original.id, splitAtProjectUs))
    }
}

data class DeleteClipCommand(val clipId: String) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        project.tracks.forEach { track ->
            val index = track.clips.indexOfFirst { it.id == clipId }
            if (index >= 0) {
                val clip = track.clips[index]
                return CommandResult(
                    project = TimelineOps.deleteClip(project, clipId),
                    inverse = RestoreClipCommand(track.id, index, clip)
                )
            }
        }
        throw TimelineEditException(TimelineErrorCode.CLIP_NOT_FOUND, "clip $clipId not found")
    }
}

private data class RestoreClipCommand(
    val trackId: String,
    val index: Int,
    val clip: Clip
) : EditorCommand {
    override fun apply(project: Project): CommandResult {
        if (project.findClip(clip.id) != null) {
            throw TimelineEditException(TimelineErrorCode.DUPLICATE_CLIP_ID, "clip ${clip.id} already exists")
        }
        val trackIndex = project.tracks.indexOfFirst { it.id == trackId }
        if (trackIndex < 0) throw TimelineEditException(TimelineErrorCode.TRACK_NOT_FOUND, "track $trackId not found")
        val track = project.tracks[trackIndex]
        require(index in 0..track.clips.size) { "restore index out of range" }
        val clips = track.clips.toMutableList().also { it.add(index, clip) }
        val tracks = project.tracks.toMutableList().also { it[trackIndex] = track.copy(clips = clips) }
        val restored = project.copy(tracks = tracks)
        val issues = TimelineValidator.validate(restored)
        require(issues.isEmpty()) { "restored project invalid: ${issues.firstOrNull()}" }
        return CommandResult(restored, DeleteClipCommand(clip.id))
    }
}
private fun clipEnd(clip: Clip): Long = try {
    Math.addExact(clip.startUs, clip.durationUs)
} catch (_: ArithmeticException) {
    throw TimelineEditException(TimelineErrorCode.INVALID_PROJECT, "timeline overflow for clip ${clip.id}")
}
