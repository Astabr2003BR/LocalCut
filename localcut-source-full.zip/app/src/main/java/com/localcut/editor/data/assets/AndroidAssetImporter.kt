package com.localcut.editor.data.assets

import android.content.ContentResolver
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.localcut.editor.domain.model.AssetType
import java.util.UUID

class AndroidAssetImporter(
    private val contentResolver: ContentResolver,
    private val idFactory: () -> String = { UUID.randomUUID().toString() },
) : AssetImporter {
    override fun import(uri: Uri) = runCatching {
        val mimeType = contentResolver.getType(uri)
            ?: throw AssetImportException(AssetImportErrorCode.UNSUPPORTED_TYPE, "Missing MIME type")
        val type = AssetImportPolicy.typeForMime(mimeType)
        val metadata = queryOpenableMetadata(uri)
        val durationUs = if (type == AssetType.VIDEO || type == AssetType.AUDIO) readDurationUs(uri) else null

        // Best effort: ACTION_OPEN_DOCUMENT grants may be persistable, while other providers may
        // legitimately reject this call. Current read access remains useful for this import.
        runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        AssetImportPolicy.create(
            id = idFactory(),
            uri = uri.toString(),
            sizeBytes = metadata.sizeBytes,
            displayName = metadata.displayName,
            mimeType = mimeType,
            sourceDurationUs = durationUs,
            lastModifiedMillis = null,
        ).getOrThrow()
    }

    private fun queryOpenableMetadata(uri: Uri): OpenableMetadata {
        contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null,
        )?.use { cursor ->
            if (!cursor.moveToFirst()) {
                throw AssetImportException(AssetImportErrorCode.INVALID_METADATA, "No metadata row for URI")
            }
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            val displayName = if (nameIndex >= 0 && !cursor.isNull(nameIndex)) cursor.getString(nameIndex) else uri.lastPathSegment
            val size = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else null
            return OpenableMetadata(
                displayName = displayName?.takeIf { it.isNotBlank() }
                    ?: throw AssetImportException(AssetImportErrorCode.INVALID_METADATA, "Missing display name"),
                sizeBytes = size,
            )
        }
        throw AssetImportException(AssetImportErrorCode.INVALID_METADATA, "Unable to query URI metadata")
    }

    private fun readDurationUs(uri: Uri): Long? {
        val retriever = MediaMetadataRetriever()
        return try {
            contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                retriever.setDataSource(descriptor.fileDescriptor)
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()
                    ?.takeIf { it > 0L }
                    ?.let { millis -> Math.multiplyExact(millis, 1_000L) }
            } ?: throw AssetImportException(
                AssetImportErrorCode.INVALID_METADATA,
                "Unable to open media",
            )
        } finally {
            retriever.release()
        }
    }

    private data class OpenableMetadata(val displayName: String, val sizeBytes: Long?)
}
