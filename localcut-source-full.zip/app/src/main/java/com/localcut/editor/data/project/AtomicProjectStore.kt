package com.localcut.editor.data.project

import com.localcut.editor.domain.model.Project
import com.localcut.editor.domain.timeline.TimelineValidator
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.charset.StandardCharsets
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.nio.file.StandardOpenOption

enum class ProjectStoreErrorCode { NOT_FOUND, CORRUPT_PROJECT, UNSUPPORTED_SCHEMA, INVALID_PROJECT, IO_ERROR }

class ProjectStoreException(
    val code: ProjectStoreErrorCode,
    message: String,
    cause: Throwable? = null
) : Exception(message, cause)

class AtomicProjectStore(private val projectDir: Path) : ProjectStore {
    private val current: Path get() = projectDir.resolve("project.json")
    private val backup: Path get() = projectDir.resolve("project.json.bak")
    private val temp: Path get() = projectDir.resolve("project.json.tmp")

    override fun save(project: Project): Result<Unit> = runCatching {
        val issues = TimelineValidator.validate(project)
        if (issues.isNotEmpty()) throw ProjectStoreException(ProjectStoreErrorCode.INVALID_PROJECT, "refusing to save invalid project: ${issues.first()}")
        Files.createDirectories(projectDir)
        writeForced(temp, ProjectJson.encode(project).toByteArray(StandardCharsets.UTF_8))

        if (Files.exists(current) && isValidCurrent(current)) {
            Files.copy(current, backup, StandardCopyOption.REPLACE_EXISTING)
            forceFile(backup)
        }
        replaceAtomically(temp, current)
        forceDirectoryBestEffort(projectDir)
    }.recoverCatching { cause ->
        if (cause is ProjectStoreException) throw cause
        throw ProjectStoreException(ProjectStoreErrorCode.IO_ERROR, "project save failed", cause)
    }

    override fun load(): Result<Project> {
        if (Files.exists(current)) {
            try {
                return Result.success(readProject(current))
            } catch (e: UnsupportedProjectSchemaException) {
                return Result.failure(ProjectStoreException(ProjectStoreErrorCode.UNSUPPORTED_SCHEMA, e.message ?: "unsupported schema", e))
            } catch (_: Throwable) {
                // Corrupt/incomplete current may recover from the last known-good backup.
            }
        }
        if (Files.exists(backup)) {
            return try {
                Result.success(readProject(backup))
            } catch (e: UnsupportedProjectSchemaException) {
                Result.failure(ProjectStoreException(ProjectStoreErrorCode.UNSUPPORTED_SCHEMA, e.message ?: "unsupported schema", e))
            } catch (e: Throwable) {
                Result.failure(ProjectStoreException(ProjectStoreErrorCode.CORRUPT_PROJECT, "current and backup project files are unreadable", e))
            }
        }
        return Result.failure(ProjectStoreException(ProjectStoreErrorCode.NOT_FOUND, "project.json not found"))
    }

    private fun readProject(path: Path): Project = ProjectJson.decode(Files.readString(path, StandardCharsets.UTF_8))

    private fun isValidCurrent(path: Path): Boolean = try {
        readProject(path)
        true
    } catch (_: Throwable) {
        false
    }

    private fun writeForced(path: Path, bytes: ByteArray) {
        FileChannel.open(path, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE).use { channel ->
            val buffer = ByteBuffer.wrap(bytes)
            while (buffer.hasRemaining()) channel.write(buffer)
            channel.force(true)
        }
    }

    private fun forceFile(path: Path) {
        FileChannel.open(path, StandardOpenOption.READ).use { it.force(true) }
    }

    private fun replaceAtomically(from: Path, to: Path) {
        try {
            Files.move(from, to, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(from, to, StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun forceDirectoryBestEffort(dir: Path) {
        try {
            FileChannel.open(dir, StandardOpenOption.READ).use { it.force(true) }
        } catch (_: Throwable) {
            // Some providers do not allow opening directories as channels; file fsync already completed.
        }
    }

    companion object {
        fun save(projectDir: Path, project: Project): Result<Unit> = AtomicProjectStore(projectDir).save(project)
        fun load(projectDir: Path): Result<Project> = AtomicProjectStore(projectDir).load()
    }
}
