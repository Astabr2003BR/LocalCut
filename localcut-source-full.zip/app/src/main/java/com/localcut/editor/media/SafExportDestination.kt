package com.localcut.editor.media

import android.content.ContentResolver
import android.net.Uri
import java.io.File

class SafExportDestination(
    private val contentResolver: ContentResolver,
    private val destinationUri: Uri,
) : ExportDestination {
    override fun commitFrom(tempFile: File): Result<Unit> = runCatching {
        val output = contentResolver.openOutputStream(destinationUri, "w")
            ?: error("Unable to open export destination")
        output.use { sink ->
            tempFile.inputStream().use { source -> source.copyTo(sink) }
            sink.flush()
        }
    }.onFailure {
        discard()
    }

    override fun discard(): Result<Unit> = runCatching {
        contentResolver.delete(destinationUri, null, null)
        Unit
    }
}
