package com.localcut.editor.ui.editor

import com.localcut.editor.domain.model.Project

enum class TimelineHitRegion { LEFT_HANDLE, BODY, RIGHT_HANDLE }

data class TimelineHit(
    val clipId: String,
    val region: TimelineHitRegion,
)

object TimelineHitTester {
    fun hit(
        project: Project,
        trackId: String,
        xPx: Double,
        geometry: TimelineGeometry,
        handleWidthPx: Double,
    ): TimelineHit? {
        require(xPx.isFinite()) { "xPx must be finite" }
        require(handleWidthPx.isFinite() && handleWidthPx >= 0.0) { "handleWidthPx must be finite and >= 0" }
        val track = project.tracks.firstOrNull { it.id == trackId } ?: return null
        for (clip in track.clips.asReversed()) {
            val bounds = geometry.clipBounds(clip.startUs, clip.durationUs)
            if (xPx < bounds.leftPx || xPx > bounds.rightPx) continue
            val distanceLeft = xPx - bounds.leftPx
            val distanceRight = bounds.rightPx - xPx
            val inLeft = distanceLeft <= handleWidthPx
            val inRight = distanceRight <= handleWidthPx
            val region = when {
                inLeft && inRight -> if (distanceLeft <= distanceRight) TimelineHitRegion.LEFT_HANDLE else TimelineHitRegion.RIGHT_HANDLE
                inLeft -> TimelineHitRegion.LEFT_HANDLE
                inRight -> TimelineHitRegion.RIGHT_HANDLE
                else -> TimelineHitRegion.BODY
            }
            return TimelineHit(clip.id, region)
        }
        return null
    }
}
