package com.localcut.editor.session

import com.localcut.editor.domain.history.MoveClipCommand
import com.localcut.editor.domain.model.*
import com.localcut.editor.domain.timeline.TimelineOps

private var passed=0
private var failed=0
private fun test(name:String,block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertEquals(e:Any?,a:Any?,m:String=""){if(e!=a)error("expected=$e actual=$a $m")}
private fun assertTrue(v:Boolean,m:String="expected true"){if(!v)error(m)}
private fun assertFalse(v:Boolean,m:String="expected false"){if(v)error(m)}

private fun project(startUs:Long=0): Project {
    val asset=Asset("a",AssetType.VIDEO,"content://a",10_000_000,1,"a.mp4","video/mp4","f")
    val p=Project.create("p",1080,1920,30).copy(assets=listOf(asset))
    val visual=p.tracks.first{it.type==TrackType.VISUAL}
    return TimelineOps.insertClip(p,visual.id,Clip("c","a",startUs,5_000_000,0,5_000_000))
}

private class FakeStore(var stored:Project?=null): ProjectStore {
    var saveCalls=0; var loadCalls=0
    override fun save(project:Project):Result<Unit>{saveCalls++;stored=project;return Result.success(Unit)}
    override fun load():Result<Project>{loadCalls++;return stored?.let{Result.success(it)}?:Result.failure(IllegalStateException("empty"))}
}
private class FakeScheduler: DelayScheduler {
    var scheduleCalls=0
    private var action:(()->Unit)?=null
    override fun schedule(delayMs:Long, action:()->Unit):Cancellable { scheduleCalls++; this.action=action; return Cancellable{this.action=null} }
    fun runPending(){val a=action; action=null; a?.invoke()}
    fun hasPending()=action!=null
}
private class FakePreview(var failure:Throwable?=null): ProjectPreviewLoader {
    var loadCalls=0
    var last:Project?=null
    override fun load(project:Project):Result<Unit>{loadCalls++;last=project;return failure?.let{Result.failure(it)}?:Result.success(Unit)}
}

fun main(){
    test("successful edit refreshes preview and schedules autosave"){
        val store=FakeStore(); val scheduler=FakeScheduler(); val preview=FakePreview()
        val saver=DebouncedProjectSaver(store,scheduler,500)
        val session=ProjectSession(project(),preview,saver)
        session.dispatch(EditorAction.Execute(MoveClipCommand("c",2_000_000)))
        assertEquals(2_000_000L,session.state.project.findClip("c")!!.startUs)
        assertEquals(1,preview.loadCalls); assertEquals(1,scheduler.scheduleCalls); assertTrue(scheduler.hasPending())
        scheduler.runPending()
        assertEquals(1,store.saveCalls); assertEquals(2_000_000L,store.stored!!.findClip("c")!!.startUs)
    }
    test("rapid edits coalesce to one save of latest project"){
        val store=FakeStore(); val scheduler=FakeScheduler(); val preview=FakePreview()
        val session=ProjectSession(project(),preview,DebouncedProjectSaver(store,scheduler,500))
        session.dispatch(EditorAction.Execute(MoveClipCommand("c",1_000_000)))
        session.dispatch(EditorAction.Execute(MoveClipCommand("c",2_000_000)))
        session.dispatch(EditorAction.Execute(MoveClipCommand("c",3_000_000)))
        assertEquals(1,scheduler.scheduleCalls)
        assertEquals(0,store.saveCalls)
        scheduler.runPending()
        assertEquals(1,store.saveCalls)
        assertEquals(3_000_000L,store.stored!!.findClip("c")!!.startUs)
    }
    test("failed edit leaves project unchanged and does not autosave"){
        val store=FakeStore(); val scheduler=FakeScheduler(); val preview=FakePreview()
        val session=ProjectSession(project(),preview,DebouncedProjectSaver(store,scheduler,500))
        session.dispatch(EditorAction.Execute(MoveClipCommand("c",-1)))
        assertEquals(0L,session.state.project.findClip("c")!!.startUs)
        assertEquals(0,scheduler.scheduleCalls); assertFalse(scheduler.hasPending()); assertTrue(session.state.lastError!=null)
    }
    test("restore loads saved project exactly once and refreshes preview"){
        val store=FakeStore(project(2_000_000)); val scheduler=FakeScheduler(); val preview=FakePreview()
        val session=ProjectSession(project(),preview,DebouncedProjectSaver(store,scheduler,500),store)
        assertTrue(session.restore().isSuccess)
        assertTrue(session.restore().isSuccess)
        assertEquals(1,store.loadCalls); assertEquals(1,preview.loadCalls)
        assertEquals(2_000_000L,session.state.project.findClip("c")!!.startUs)
    }
    test("missing asset preview error is visible but project remains editable"){
        val store=FakeStore(project()); val scheduler=FakeScheduler()
        val preview=FakePreview(PreviewLoadException(PreviewErrorCode.ASSET_UNAVAILABLE,"a","permission revoked"))
        val session=ProjectSession(project(),preview,DebouncedProjectSaver(store,scheduler,500),store)
        assertTrue(session.restore().isSuccess)
        assertTrue(session.state.issues.any{it.code==SessionIssueCode.ASSET_UNAVAILABLE && it.assetId=="a"})
        session.dispatch(EditorAction.Execute(MoveClipCommand("c",1_000_000)))
        assertEquals(1_000_000L,session.state.project.findClip("c")!!.startUs)
        assertEquals(1,scheduler.scheduleCalls)
    }
    test("undo and redo refresh preview and autosave"){
        val store=FakeStore(); val scheduler=FakeScheduler(); val preview=FakePreview()
        val session=ProjectSession(project(),preview,DebouncedProjectSaver(store,scheduler,500))
        session.dispatch(EditorAction.Execute(MoveClipCommand("c",1_000_000)))
        session.dispatch(EditorAction.Undo)
        assertEquals(0L,session.state.project.findClip("c")!!.startUs)
        session.dispatch(EditorAction.Redo)
        assertEquals(1_000_000L,session.state.project.findClip("c")!!.startUs)
        assertEquals(3,preview.loadCalls)
        assertEquals(1,scheduler.scheduleCalls)
    }
    test("undo before pending autosave flush persists the undone state") {
        val store=FakeStore(); val scheduler=FakeScheduler(); val preview=FakePreview()
        val session=ProjectSession(project(),preview,DebouncedProjectSaver(store,scheduler,500))
        session.dispatch(EditorAction.Execute(MoveClipCommand("c",2_000_000)))
        session.dispatch(EditorAction.Undo)
        assertEquals(0L,session.state.project.findClip("c")!!.startUs)
        assertEquals(1,scheduler.scheduleCalls)
        scheduler.runPending()
        assertEquals(1,store.saveCalls)
        assertEquals(0L,store.stored!!.findClip("c")!!.startUs)
    }
    println("RESULT passed=$passed failed=$failed")
    if(failed!=0)error("$failed tests failed")
}
