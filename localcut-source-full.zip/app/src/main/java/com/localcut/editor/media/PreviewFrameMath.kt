package com.localcut.editor.media

object PreviewFrameMath {
    fun frameDurationUs(fps: Int): Long {
        require(fps > 0) { "fps must be > 0" }
        return (1_000_000L + fps / 2L) / fps.toLong()
    }

    fun step(positionUs: Long, deltaFrames: Int, fps: Int, durationUs: Long): Long {
        require(durationUs >= 0) { "duration must be >= 0" }
        val frameUs = frameDurationUs(fps)
        val base = positionUs.coerceIn(0L, durationUs)
        val deltaUs = frameUs * deltaFrames.toLong()
        val raw = try {
            Math.addExact(base, deltaUs)
        } catch (_: ArithmeticException) {
            return if (deltaUs >= 0) durationUs else 0L
        }
        return raw.coerceIn(0L, durationUs)
    }
}
