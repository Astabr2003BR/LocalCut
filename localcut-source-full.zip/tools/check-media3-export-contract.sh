#!/usr/bin/env bash
set -euo pipefail
m=app/src/main/java/com/localcut/editor/media/Media3ExportController.kt
s=app/src/main/java/com/localcut/editor/media/SafExportDestination.kt
[[ -f "$m" ]] || { echo 'FAIL missing Media3ExportController.kt'; exit 1; }
[[ -f "$s" ]] || { echo 'FAIL missing SafExportDestination.kt'; exit 1; }
grep -q 'callbackFlow' "$m"
grep -q 'Transformer.Builder' "$m"
grep -q 'MimeTypes.VIDEO_H264' "$m"
grep -q 'MimeTypes.AUDIO_AAC' "$m"
grep -q 'RenderMode.EXPORT' "$m"
grep -q 'ProgressHolder' "$m"
grep -q 'getProgress' "$m"
grep -Eq 'transformer\??\.cancel\(\)' "$m"
grep -q 'File.createTempFile' "$m"
grep -q 'destination.discard()' "$m"
grep -q 'openOutputStream' "$s"
grep -q 'contentResolver.delete' "$s"
grep -q 'override fun discard' "$s"
# Review gate: ContentResolver destination cleanup must never execute on the main thread.
grep -q 'cleanupExecutor' "$m" || { echo 'FAIL missing off-main export cleanup executor'; exit 1; }
grep -q 'cleanupExecutor.execute' "$m" || { echo 'FAIL export cleanup not dispatched off main'; exit 1; }
echo 'PASS media3 export static contract'
