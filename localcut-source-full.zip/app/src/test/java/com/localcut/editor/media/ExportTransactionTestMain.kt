package com.localcut.editor.media

import java.nio.file.Files
import java.nio.file.Path

private var passed=0
private var failed=0
private fun test(name:String,block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertEquals(e:Any?,a:Any?,m:String=""){if(e!=a)error("expected=$e actual=$a $m")}
private fun assertTrue(v:Boolean,m:String="expected true"){if(!v)error(m)}
private fun assertFalse(v:Boolean,m:String="expected false"){if(v)error(m)}

private class FakeRenderer(
    private val bytes: ByteArray = "rendered".toByteArray(),
    private val fail: Boolean = false,
    private val cancelAfterWrite: Boolean = false,
) : TempExportRenderer {
    override fun render(tempFile: Path, cancellation: ExportCancellation): Result<Unit> = runCatching {
        Files.write(tempFile, bytes)
        if (cancelAfterWrite) cancellation.cancel()
        if (fail) error("renderer failed")
    }
}

private class FileDestination(private val path: Path) : ExportDestinationWriter {
    var commits = 0
    override fun commitFrom(tempFile: Path): Result<Unit> = runCatching {
        commits++
        Files.copy(tempFile, path, java.nio.file.StandardCopyOption.REPLACE_EXISTING)
    }
}

fun main(){
    test("success commits rendered temp and removes temp file"){
        val dir=Files.createTempDirectory("localcut-export-ok")
        val destinationPath=dir.resolve("final.mp4")
        val destination=FileDestination(destinationPath)
        val result=ExportTransaction(FakeRenderer(),dir).run(destination)
        assertTrue(result.isSuccess)
        assertEquals("rendered",Files.readString(destinationPath))
        assertEquals(1,destination.commits)
        assertEquals(0L,Files.list(dir).use { s -> s.filter { it.fileName.toString().endsWith(".tmp") }.count() })
    }
    test("renderer failure leaves existing destination untouched and cleans temp"){
        val dir=Files.createTempDirectory("localcut-export-render-fail")
        val destinationPath=dir.resolve("final.mp4")
        Files.writeString(destinationPath,"old")
        val destination=FileDestination(destinationPath)
        val result=ExportTransaction(FakeRenderer(fail=true),dir).run(destination)
        assertTrue(result.isFailure)
        assertEquals("old",Files.readString(destinationPath))
        assertEquals(0,destination.commits)
        assertEquals(0L,Files.list(dir).use { s -> s.filter { it.fileName.toString().endsWith(".tmp") }.count() })
    }
    test("cancellation after render prevents destination commit and cleans temp"){
        val dir=Files.createTempDirectory("localcut-export-cancel")
        val destinationPath=dir.resolve("final.mp4")
        val destination=FileDestination(destinationPath)
        val result=ExportTransaction(FakeRenderer(cancelAfterWrite=true),dir).run(destination)
        assertTrue(result.isFailure)
        assertFalse(Files.exists(destinationPath))
        assertEquals(0,destination.commits)
        val error=result.exceptionOrNull() as ExportTransactionException
        assertEquals(ExportTransactionErrorCode.CANCELLED,error.code)
        assertEquals(0L,Files.list(dir).use { s -> s.filter { it.fileName.toString().endsWith(".tmp") }.count() })
    }
    test("commit failure leaves no partial temp behind"){
        val dir=Files.createTempDirectory("localcut-export-commit-fail")
        val destination=ExportDestinationWriter { Result.failure(IllegalStateException("no space")) }
        val result=ExportTransaction(FakeRenderer(),dir).run(destination)
        assertTrue(result.isFailure)
        val error=result.exceptionOrNull() as ExportTransactionException
        assertEquals(ExportTransactionErrorCode.DESTINATION_WRITE_FAILED,error.code)
        assertEquals(0L,Files.list(dir).use { s -> s.filter { it.fileName.toString().endsWith(".tmp") }.count() })
    }
    test("pre-cancelled transaction never invokes renderer or destination"){
        val dir=Files.createTempDirectory("localcut-export-pre-cancel")
        var renders=0
        var commits=0
        val renderer=TempExportRenderer { _, _ -> renders++; Result.success(Unit) }
        val destination=ExportDestinationWriter { commits++; Result.success(Unit) }
        val cancellation=ExportCancellation().also { it.cancel() }
        val result=ExportTransaction(renderer,dir,cancellation).run(destination)
        assertTrue(result.isFailure)
        assertEquals(0,renders)
        assertEquals(0,commits)
    }
    println("RESULT passed=$passed failed=$failed")
    if(failed!=0)error("$failed tests failed")
}
