package com.localcut.editor.media

import java.io.File
import java.nio.file.Files

private var passed=0; private var failed=0
private fun case(name:String, block:()->Unit){try{block();passed++;println("PASS $name")}catch(t:Throwable){failed++;println("FAIL $name: ${t.message}")}}
private fun assertThat(v:Boolean,m:String){if(!v) error(m)}

private class RecordingDestination(private val result: Result<Unit> = Result.success(Unit)) : ExportDestination {
    var commits=0; var discards=0
    override fun commitFrom(tempFile: File): Result<Unit> { commits++; return result }
    override fun discard(): Result<Unit> { discards++; return Result.success(Unit) }
}

fun main(){
    case("completed render commits once and deletes temp"){
        val dir=Files.createTempDirectory("localcut-export-life").toFile(); val temp=File(dir,"a.tmp").apply{writeText("mp4")}
        var commits=0; val events=mutableListOf<ExportEvent>()
        val c=ExportLifecycleCoordinator(temp, ExportDestination { commits++; Result.success(Unit) }, events::add)
        c.started(); c.progress(10); c.progress(10); c.progress(80); c.renderCompleted()
        assertThat(commits==1,"commit count")
        assertThat(!temp.exists(),"temp cleanup")
        assertThat(events.filterIsInstance<ExportEvent.Progress>().map{it.percent}==listOf(10,80),"progress coalesce")
        assertThat(events.last() is ExportEvent.Completed,"completed")
        dir.deleteRecursively()
    }
    case("cancel prevents commit and late completion is ignored"){
        val dir=Files.createTempDirectory("localcut-export-life").toFile(); val temp=File(dir,"a.tmp").apply{writeText("mp4")}
        val destination=RecordingDestination(); val events=mutableListOf<ExportEvent>()
        val c=ExportLifecycleCoordinator(temp, destination, events::add)
        c.started(); c.cancel(); c.renderCompleted()
        assertThat(destination.commits==0,"must not commit")
        assertThat(destination.discards==1,"fresh destination must be discarded")
        assertThat(events.last() is ExportEvent.Cancelled,"cancel event")
        assertThat(!temp.exists(),"temp cleanup")
        dir.deleteRecursively()
    }
    case("render failure does not touch destination"){
        val dir=Files.createTempDirectory("localcut-export-life").toFile(); val temp=File(dir,"a.tmp").apply{writeText("partial")}
        val destination=RecordingDestination(); val events=mutableListOf<ExportEvent>()
        val c=ExportLifecycleCoordinator(temp, destination, events::add)
        c.started(); c.renderFailed(IllegalStateException("codec"))
        assertThat(destination.commits==0,"destination touched")
        assertThat(destination.discards==1,"failed render must discard fresh destination")
        assertThat(events.last() is ExportEvent.Failed,"failed event")
        assertThat(!temp.exists(),"temp cleanup")
        dir.deleteRecursively()
    }
    case("destination failure reports failed and cleans temp"){
        val dir=Files.createTempDirectory("localcut-export-life").toFile(); val temp=File(dir,"a.tmp").apply{writeText("mp4")}
        val events=mutableListOf<ExportEvent>(); val destination=RecordingDestination(Result.failure(IllegalStateException("disk full")))
        val c=ExportLifecycleCoordinator(temp, destination, events::add)
        c.started(); c.renderCompleted()
        assertThat(events.last() is ExportEvent.Failed,"failed event")
        assertThat(destination.discards==1,"failed commit must discard partial destination")
        assertThat(!temp.exists(),"temp cleanup")
        dir.deleteRecursively()
    }
    println("RESULT passed=$passed failed=$failed"); if(failed!=0) error("failed=$failed")
}
