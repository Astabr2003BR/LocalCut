package com.localcut.editor.domain.timeline

import com.localcut.editor.domain.model.*

private var passed = 0
private var failed = 0

private fun test(name: String, block: () -> Unit) {
    try {
        block()
        passed++
        println("PASS $name")
    } catch (t: Throwable) {
        failed++
        println("FAIL $name: ${t.message}")
    }
}

private fun assertTrue(value: Boolean, message: String = "expected true") {
    if (!value) error(message)
}

private fun assertEquals(expected: Any?, actual: Any?, message: String = "") {
    if (expected != actual) error("expected=$expected actual=$actual $message")
}

private fun assertFailsCode(code: TimelineErrorCode, block: () -> Unit) {
    try {
        block()
        error("expected TimelineEditException($code)")
    } catch (e: TimelineEditException) {
        assertEquals(code, e.code)
    }
}

private fun baseProject(): Project {
    val asset = Asset(
        id = "asset-1",
        type = AssetType.VIDEO,
        uri = "content://video/1",
        sourceDurationUs = 10_000_000,
        sizeBytes = 1234,
        displayName = "vídeo teste ção.mp4",
        mimeType = "video/mp4",
        fingerprint = "fp-1"
    )
    return Project.create("Projeto çã 日本", 1080, 1920, 30).copy(assets = listOf(asset))
}

fun main() {
    test("unicode names are valid and VFR asset needs no fps") {
        val issues = TimelineValidator.validate(baseProject())
        assertTrue(issues.isEmpty(), "issues=$issues")
    }

    test("unknown asset is invalid") {
        val p = baseProject()
        val clip = Clip("clip-1", "missing", 0, 1_000_000, 0, 1_000_000)
        val withClip = p.copy(tracks = p.tracks.map { if (it.type == TrackType.VISUAL) it.copy(clips = listOf(clip)) else it })
        assertTrue(TimelineValidator.validate(withClip).any { it.code == ProjectIssueCode.UNKNOWN_ASSET })
    }

    test("zero duration is invalid") {
        val p = baseProject()
        val clip = Clip("clip-1", "asset-1", 0, 0, 0, 1)
        val withClip = p.copy(tracks = p.tracks.map { if (it.type == TrackType.VISUAL) it.copy(clips = listOf(clip)) else it })
        assertTrue(TimelineValidator.validate(withClip).any { it.code == ProjectIssueCode.NON_POSITIVE_DURATION })
    }

    test("insert move trim split delete are immutable") {
        val p0 = baseProject()
        val visual = p0.tracks.first { it.type == TrackType.VISUAL }
        val clip = Clip("clip-1", "asset-1", 0, 5_000_000, 0, 5_000_000)
        val p1 = TimelineOps.insertClip(p0, visual.id, clip)
        assertEquals(0, visual.clips.size, "source project mutated")
        assertEquals(1, p1.tracks.first { it.id == visual.id }.clips.size)

        val p2 = TimelineOps.moveClip(p1, "clip-1", 1_000_000)
        assertEquals(1_000_000L, p2.findClip("clip-1")!!.startUs)

        val p3 = TimelineOps.trimClip(p2, "clip-1", 1_000_000, 4_000_000)
        assertEquals(3_000_000L, p3.findClip("clip-1")!!.durationUs)
        assertEquals(1_000_000L, p3.findClip("clip-1")!!.sourceInUs)

        val p4 = TimelineOps.splitClip(p3, "clip-1", 2_500_000)
        val clips = p4.tracks.first { it.id == visual.id }.clips.sortedBy { it.startUs }
        assertEquals(2, clips.size)
        assertEquals(1_500_000L, clips[0].durationUs)
        assertEquals(1_500_000L, clips[1].durationUs)

        val p5 = TimelineOps.deleteClip(p4, clips[0].id)
        assertEquals(1, p5.tracks.first { it.id == visual.id }.clips.size)
        assertEquals(p0.assets, p5.assets, "source Asset metadata changed")
    }

    test("edge trim updates project position source range and animation atomically") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val animated = Clip(
            "edge",
            "asset-1",
            1_000_000,
            6_000_000,
            0,
            6_000_000,
            keyframes = listOf(
                TransformKeyframe(0, TransformValue(scale = 1.0)),
                TransformKeyframe(3_000_000, TransformValue(scale = 1.3)),
                TransformKeyframe(6_000_000, TransformValue(scale = 1.6))
            )
        )
        val p1 = TimelineOps.insertClip(p, visual.id, animated)
        val p2 = TimelineOps.trimClipEdges(p1, "edge", newStartUs = 2_000_000, newEndUs = 6_000_000)
        val clip = p2.findClip("edge")!!
        assertEquals(2_000_000L, clip.startUs)
        assertEquals(4_000_000L, clip.durationUs)
        assertEquals(1_000_000L, clip.sourceInUs)
        assertEquals(5_000_000L, clip.sourceOutUs)
        assertEquals(listOf(0L, 2_000_000L, 4_000_000L), clip.keyframes.map { it.offsetUs })
        assertTrue(kotlin.math.abs(clip.keyframes.first().value.scale - 1.1) < 0.000001)
        assertTrue(kotlin.math.abs(clip.keyframes.last().value.scale - 1.5) < 0.000001)
    }

    test("edge trim can extend back into available source but rejects source bounds") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val p1 = TimelineOps.insertClip(p, visual.id, Clip("edge2", "asset-1", 2_000_000, 4_000_000, 2_000_000, 6_000_000))
        val extended = TimelineOps.trimClipEdges(p1, "edge2", 1_000_000, 7_000_000).findClip("edge2")!!
        assertEquals(1_000_000L, extended.sourceInUs)
        assertEquals(7_000_000L, extended.sourceOutUs)
        assertEquals(6_000_000L, extended.durationUs)
        assertFailsCode(TimelineErrorCode.INVALID_START) {
            TimelineOps.trimClipEdges(p1, "edge2", -1, 6_000_000)
        }
        assertFailsCode(TimelineErrorCode.SOURCE_RANGE_OUT_OF_BOUNDS) {
            TimelineOps.trimClipEdges(p1, "edge2", 2_000_000, 11_000_001)
        }
    }

    test("trim remaps animation to the new source window") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val animated = Clip(
            "trim-animated",
            "asset-1",
            0,
            6_000_000,
            0,
            6_000_000,
            keyframes = listOf(
                TransformKeyframe(0, TransformValue(scale = 1.0)),
                TransformKeyframe(3_000_000, TransformValue(scale = 1.3)),
                TransformKeyframe(6_000_000, TransformValue(scale = 1.6))
            )
        )
        val p1 = TimelineOps.insertClip(p, visual.id, animated)
        val p2 = TimelineOps.trimClip(p1, "trim-animated", 1_000_000, 5_000_000)
        val clip = p2.findClip("trim-animated")!!
        assertEquals(4_000_000L, clip.durationUs)
        assertEquals(listOf(0L, 2_000_000L, 4_000_000L), clip.keyframes.map { it.offsetUs })
        assertTrue(kotlin.math.abs(clip.keyframes[0].value.scale - 1.1) < 0.000001)
        assertTrue(kotlin.math.abs(clip.keyframes[1].value.scale - 1.3) < 0.000001)
        assertTrue(kotlin.math.abs(clip.keyframes[2].value.scale - 1.5) < 0.000001)
    }

    test("split preserves animation by synthesizing boundary keyframes") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val animated = Clip(
            "animated",
            "asset-1",
            0,
            6_000_000,
            0,
            6_000_000,
            keyframes = listOf(
                TransformKeyframe(0, TransformValue(scale = 1.0)),
                TransformKeyframe(3_000_000, TransformValue(scale = 1.3)),
                TransformKeyframe(6_000_000, TransformValue(scale = 1.6))
            )
        )
        val p1 = TimelineOps.insertClip(p, visual.id, animated)
        val p2 = TimelineOps.splitClip(p1, "animated", 2_000_000)
        val clips = p2.tracks.first { it.id == visual.id }.clips
        val first = clips[0]
        val second = clips[1]
        assertEquals(listOf(0L, 2_000_000L), first.keyframes.map { it.offsetUs })
        assertTrue(kotlin.math.abs(first.keyframes.last().value.scale - 1.2) < 0.000001)
        assertEquals(listOf(0L, 1_000_000L, 4_000_000L), second.keyframes.map { it.offsetUs })
        assertTrue(kotlin.math.abs(second.keyframes.first().value.scale - 1.2) < 0.000001)
        assertTrue(kotlin.math.abs(second.keyframes[1].value.scale - 1.3) < 0.000001)
        assertTrue(kotlin.math.abs(second.keyframes.last().value.scale - 1.6) < 0.000001)
    }

    test("minimum one microsecond clip is accepted") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val clip = Clip("micro", "asset-1", 0, 1, 0, 1)
        val result = TimelineOps.insertClip(p, visual.id, clip)
        assertEquals(1L, result.findClip("micro")!!.durationUs)
    }

    test("trim past source duration is rejected") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val p1 = TimelineOps.insertClip(p, visual.id, Clip("c", "asset-1", 0, 5_000_000, 0, 5_000_000))
        assertFailsCode(TimelineErrorCode.SOURCE_RANGE_OUT_OF_BOUNDS) {
            TimelineOps.trimClip(p1, "c", 0, 11_000_000)
        }
    }

    test("split at clip boundary is rejected") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val p1 = TimelineOps.insertClip(p, visual.id, Clip("c", "asset-1", 1_000_000, 5_000_000, 0, 5_000_000))
        assertFailsCode(TimelineErrorCode.SPLIT_OUTSIDE_CLIP) { TimelineOps.splitClip(p1, "c", 1_000_000) }
        assertFailsCode(TimelineErrorCode.SPLIT_OUTSIDE_CLIP) { TimelineOps.splitClip(p1, "c", 6_000_000) }
    }

    test("duplicate asset id is rejected") {
        val p = baseProject().let { it.copy(assets = it.assets + it.assets.first().copy(displayName = "other")) }
        assertTrue(TimelineValidator.validate(p).any { it.code == ProjectIssueCode.DUPLICATE_ASSET_ID })
    }

    test("duplicate clip id is rejected") {
        val p = baseProject()
        val c = Clip("same", "asset-1", 0, 1_000_000, 0, 1_000_000)
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val withDupes = p.copy(tracks = p.tracks.map { if (it.id == visual.id) it.copy(clips = listOf(c, c.copy(startUs = 2_000_000))) else it })
        assertTrue(TimelineValidator.validate(withDupes).any { it.code == ProjectIssueCode.DUPLICATE_CLIP_ID })
    }

    test("overlapping clips on the same track are rejected but adjacency is valid") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val a = Clip("a", "asset-1", 0, 2_000_000, 0, 2_000_000)
        val b = Clip("b", "asset-1", 1_999_999, 1_000_000, 2_000_000, 3_000_000)
        val overlap = p.copy(tracks = p.tracks.map { if (it.id == visual.id) it.copy(clips = listOf(a,b)) else it })
        assertTrue(TimelineValidator.validate(overlap).any { it.code == ProjectIssueCode.OVERLAPPING_CLIPS })
        val adjacent = overlap.copy(tracks = overlap.tracks.map { if (it.id == visual.id) it.copy(clips = listOf(a,b.copy(startUs=2_000_000))) else it })
        assertTrue(TimelineValidator.validate(adjacent).none { it.code == ProjectIssueCode.OVERLAPPING_CLIPS })
    }


    test("duration must match source range while speed is fixed at 1x") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val bad = Clip("mismatch", "asset-1", 0, 2_000_000, 0, 3_000_000)
        val withBad = p.copy(tracks = p.tracks.map { if (it.id == visual.id) it.copy(clips = listOf(bad)) else it })
        assertTrue(TimelineValidator.validate(withBad).any { it.code == ProjectIssueCode.DURATION_SOURCE_MISMATCH })
    }

    test("non finite or non positive transform values are rejected") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val bad = Clip("bad-transform", "asset-1", 0, 1_000_000, 0, 1_000_000, transform = TransformValue(x = Double.NaN, scale = 0.0))
        val withBad = p.copy(tracks = p.tracks.map { if (it.id == visual.id) it.copy(clips = listOf(bad)) else it })
        assertTrue(TimelineValidator.validate(withBad).any { it.code == ProjectIssueCode.INVALID_TRANSFORM })
    }

    test("clip opacity and volume ranges are validated") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val bad = Clip("bad-av", "asset-1", 0, 1_000_000, 0, 1_000_000, opacity = 1.1, volume = -0.1)
        val withBad = p.copy(tracks = p.tracks.map { if (it.id == visual.id) it.copy(clips = listOf(bad)) else it })
        val issues = TimelineValidator.validate(withBad)
        assertTrue(issues.any { it.code == ProjectIssueCode.INVALID_OPACITY })
        assertTrue(issues.any { it.code == ProjectIssueCode.INVALID_VOLUME })
    }

    test("keyframe transform must be finite and valid") {
        val p = baseProject()
        val visual = p.tracks.first { it.type == TrackType.VISUAL }
        val bad = Clip("bad-kf", "asset-1", 0, 1_000_000, 0, 1_000_000, keyframes = listOf(TransformKeyframe(0, TransformValue(rotationDeg = Double.POSITIVE_INFINITY))))
        val withBad = p.copy(tracks = p.tracks.map { if (it.id == visual.id) it.copy(clips = listOf(bad)) else it })
        assertTrue(TimelineValidator.validate(withBad).any { it.code == ProjectIssueCode.INVALID_TRANSFORM })
    }

    println("RESULT passed=$passed failed=$failed")
    if (failed != 0) error("$failed tests failed")
}
