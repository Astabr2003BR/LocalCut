package com.localcut.editor.domain.timeline

import com.localcut.editor.domain.model.*
import com.localcut.editor.media.PreviewFrameMath

private var passed = 0
private var failed = 0
private fun test(name: String, block: () -> Unit) {
    try { block(); passed++; println("PASS $name") } catch (t: Throwable) { failed++; println("FAIL $name: ${t.message}") }
}
private fun assertEquals(expected: Any?, actual: Any?) { if (expected != actual) error("expected=$expected actual=$actual") }
private fun assertFails(block: () -> Unit) { try { block(); error("expected failure") } catch (_: IllegalArgumentException) {} }

private fun projectWith(trackType: TrackType, clip: Clip): Project {
    val assetType = if (trackType == TrackType.AUDIO) AssetType.AUDIO else AssetType.VIDEO
    val asset = Asset("a", assetType, "content://a", 20_000_000, 1, "a", null, "f")
    val p = Project.create("p", 1080, 1920, 30).copy(assets = listOf(asset))
    return p.copy(tracks = p.tracks.map { if (it.type == trackType) it.copy(clips = listOf(clip)) else it })
}

fun main() {
    test("empty project duration is zero") {
        assertEquals(0L, TimelineMath.durationUs(Project.create("p", 1080, 1920, 30)))
    }
    test("duration uses latest clip end") {
        val p = projectWith(TrackType.VISUAL, Clip("c", "a", 2_000_000, 5_000_000, 0, 5_000_000))
        assertEquals(7_000_000L, TimelineMath.durationUs(p))
    }
    test("audio-only project contributes duration") {
        val p = projectWith(TrackType.AUDIO, Clip("c", "a", 1_000_000, 8_000_000, 0, 8_000_000))
        assertEquals(9_000_000L, TimelineMath.durationUs(p))
    }
    test("duration overflow is rejected") {
        val p = projectWith(TrackType.VISUAL, Clip("c", "a", Long.MAX_VALUE - 5, 10, 0, 10))
        assertFails { TimelineMath.durationUs(p) }
    }
    test("30fps step is 33333us and clamps") {
        assertEquals(33_333L, PreviewFrameMath.step(0, 1, 30, 5_000_000))
        assertEquals(0L, PreviewFrameMath.step(0, -1, 30, 5_000_000))
        assertEquals(5_000_000L, PreviewFrameMath.step(4_999_999, 1, 30, 5_000_000))
    }
    test("60fps step rounds to 16667us") {
        assertEquals(16_667L, PreviewFrameMath.step(0, 1, 60, 5_000_000))
    }
    test("large frame deltas clamp without overflow") {
        assertEquals(5_000_000L, PreviewFrameMath.step(1, Int.MAX_VALUE, 60, 5_000_000))
        assertEquals(0L, PreviewFrameMath.step(4_000_000, Int.MIN_VALUE, 60, 5_000_000))
    }
    test("invalid fps or duration rejected") {
        assertFails { PreviewFrameMath.step(0, 1, 0, 5_000_000) }
        assertFails { PreviewFrameMath.step(0, 1, 30, -1) }
    }

    println("RESULT passed=$passed failed=$failed")
    if (failed != 0) error("$failed tests failed")
}
