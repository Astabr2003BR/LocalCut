package com.localcut.editor.media

import com.localcut.editor.domain.animation.TransformInterpolation
import com.localcut.editor.domain.model.TransformKeyframe
import com.localcut.editor.domain.model.TransformValue

object TransformInterpolator {
    fun valueAt(keyframes: List<TransformKeyframe>, offsetUs: Long): TransformValue =
        TransformInterpolation.valueAt(keyframes, offsetUs)
}
