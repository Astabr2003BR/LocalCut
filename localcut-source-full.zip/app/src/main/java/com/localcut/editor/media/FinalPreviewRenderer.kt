package com.localcut.editor.media

import com.localcut.editor.domain.model.Project
import com.localcut.editor.domain.timeline.TimelineSlicer
import java.io.File
import java.io.FileOutputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.UUID
import kotlinx.coroutines.flow.first

enum class FinalPreviewRenderErrorCode {
    INVALID_RANGE,
    EXPORT_FAILED,
    CANCELLED,
}

class FinalPreviewRenderException(
    val code: FinalPreviewRenderErrorCode,
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause)

class FinalPreviewRenderer(
    private val exportController: ExportController,
    private val cacheDir: File,
) {
    suspend fun renderRange(project: Project, startUs: Long, endUs: Long): Result<File> {
        val slicedProject = try {
            TimelineSlicer.slice(project, startUs, endUs)
        } catch (error: IllegalArgumentException) {
            return Result.failure(
                FinalPreviewRenderException(
                    FinalPreviewRenderErrorCode.INVALID_RANGE,
                    "Invalid final-preview range",
                    error,
                )
            )
        }

        val target = try {
            cacheDir.mkdirs()
            File(cacheDir, "localcut-final-preview-${UUID.randomUUID()}.mp4")
        } catch (error: Throwable) {
            return Result.failure(
                FinalPreviewRenderException(
                    FinalPreviewRenderErrorCode.EXPORT_FAILED,
                    "Unable to prepare final-preview cache file",
                    error,
                )
            )
        }

        val terminal = try {
            exportController.export(slicedProject, AtomicFileExportDestination(target)).first {
                it is ExportEvent.Completed || it is ExportEvent.Cancelled || it is ExportEvent.Failed
            }
        } catch (error: Throwable) {
            target.delete()
            return Result.failure(
                FinalPreviewRenderException(
                    FinalPreviewRenderErrorCode.EXPORT_FAILED,
                    "Final-preview export did not complete",
                    error,
                )
            )
        }

        return when (terminal) {
            ExportEvent.Completed -> {
                if (target.isFile && target.length() > 0L) Result.success(target)
                else {
                    target.delete()
                    Result.failure(
                        FinalPreviewRenderException(
                            FinalPreviewRenderErrorCode.EXPORT_FAILED,
                            "Final-preview output is empty",
                        )
                    )
                }
            }
            ExportEvent.Cancelled -> {
                target.delete()
                Result.failure(
                    FinalPreviewRenderException(
                        FinalPreviewRenderErrorCode.CANCELLED,
                        "Final-preview export was cancelled",
                    )
                )
            }
            is ExportEvent.Failed -> {
                target.delete()
                Result.failure(
                    FinalPreviewRenderException(
                        FinalPreviewRenderErrorCode.EXPORT_FAILED,
                        terminal.message,
                        terminal.cause,
                    )
                )
            }
            else -> error("Non-terminal export event escaped terminal filter")
        }
    }
}

private class AtomicFileExportDestination(
    private val target: File,
) : ExportDestination {
    override fun commitFrom(tempFile: File): Result<Unit> = runCatching {
        val parent = target.parentFile ?: error("Final-preview destination has no parent")
        parent.mkdirs()
        val staging = File.createTempFile("${target.name}.", ".stage", parent)
        try {
            tempFile.inputStream().use { source ->
                FileOutputStream(staging).use { sink ->
                    source.copyTo(sink)
                    sink.fd.sync()
                }
            }
            try {
                Files.move(
                    staging.toPath(),
                    target.toPath(),
                    StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING,
                )
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(staging.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        } finally {
            staging.delete()
        }
    }
}
