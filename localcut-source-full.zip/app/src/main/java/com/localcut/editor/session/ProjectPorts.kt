package com.localcut.editor.session

import com.localcut.editor.domain.model.Project

typealias ProjectStore = com.localcut.editor.data.project.ProjectStore

fun interface Cancellable {
    fun cancel()
}

fun interface DelayScheduler {
    fun schedule(delayMs: Long, action: () -> Unit): Cancellable
}

interface ProjectPreviewLoader {
    fun load(project: Project): Result<Unit>
}

enum class PreviewErrorCode { ASSET_UNAVAILABLE, PREVIEW_FAILED }

class PreviewLoadException(
    val code: PreviewErrorCode,
    val assetId: String? = null,
    message: String,
    cause: Throwable? = null
) : Exception(message, cause)
