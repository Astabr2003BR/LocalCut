package com.localcut.editor.data.assets

import android.content.ContentResolver
import android.net.Uri
import com.localcut.editor.domain.model.Asset

enum class AssetResolveErrorCode { ASSET_UNAVAILABLE }

class AssetResolveException(
    val code: AssetResolveErrorCode,
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause)

class AssetUriResolver(private val contentResolver: ContentResolver) {
    fun resolve(asset: Asset): Result<Uri> = runCatching {
        val uri = Uri.parse(asset.uri)
        try {
            contentResolver.openFileDescriptor(uri, "r")?.use { }
                ?: throw AssetResolveException(AssetResolveErrorCode.ASSET_UNAVAILABLE, "Asset is unavailable: ${asset.id}")
        } catch (error: AssetResolveException) {
            throw error
        } catch (error: Exception) {
            throw AssetResolveException(AssetResolveErrorCode.ASSET_UNAVAILABLE, "Asset is unavailable: ${asset.id}", error)
        }
        uri
    }
}
