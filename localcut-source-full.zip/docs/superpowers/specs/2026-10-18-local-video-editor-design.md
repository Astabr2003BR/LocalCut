# Editor Local de Vídeo + Animação — Especificação de Arquitetura

Data: 2026-10-18
Status: aprovada para planejamento (player interno incorporado)
Nome do produto: provisório

## 1. Objetivo

Construir um editor de vídeo local, mobile-first, voltado principalmente a Android, que não dependa de IA, APIs pagas, créditos, assinatura ou servidor externo para as funções centrais.

O produto deve servir tanto para edição comum de vídeo (TikTok, Reels, Shorts, YouTube, vídeos pessoais e comerciais) quanto para animação 2D/2.5D baseada em imagens, quadros, camadas e keyframes. Anime e mangá serão casos de uso/presets, não o núcleo do produto.

A IA poderá existir no futuro como plugin opcional, mas o editor deve permanecer plenamente funcional sem ela.

## 2. Princípios fixos

1. Local-first: importar, editar, salvar e renderizar localmente sempre que tecnicamente possível.
2. Sem créditos: nenhuma função principal será limitada por créditos ou quantidade artificial de exportações.
3. Sem dependência de IA: o editor não pode quebrar ou perder funções se qualquer serviço de IA deixar de existir.
4. Mobile-first: UX pensada para tela pequena, toque, teclado virtual, pouca RAM e interrupções do Android.
5. Não destrutivo: edição deve referenciar a mídia original e guardar transformações no projeto.
6. Recuperável: autosave, undo/redo e reabertura segura do projeto são requisitos centrais.
7. Modular: vídeo, animação, compositor, áudio e render devem ter interfaces separadas.
8. Preservação: versões futuras não podem invalidar projetos antigos sem migração explícita.

## 3. Escopo por fases

### V0 — ciclo mínimo completo

Objetivo: provar ponta a ponta que o editor é utilizável.

- criar projeto;
- escolher resolução, proporção e FPS;
- importar imagem, vídeo e áudio;
- timeline com múltiplas tracks;
- mover clipes;
- cortar início/fim;
- dividir clipe;
- ordenar clipes;
- player interno de preview antes da exportação;
- play/pause, scrubbing e avanço/retorno por frame;
- preview rápido com qualidade adaptativa;
- preview final pré-renderizado de trecho quando necessário;
- transformações básicas de imagem/vídeo: posição, escala, rotação, opacidade;
- duração de imagens;
- volume de áudio;
- salvar projeto;
- fechar e reabrir sem perda;
- undo/redo;
- exportar MP4 localmente.

### V1 — edição de vídeo completa básica

- transições;
- crop;
- velocidade;
- reverse quando suportado pelo pipeline;
- fade de áudio;
- texto;
- overlays;
- filtros básicos;
- ajuste de cor básico;
- snapping da timeline;
- duplicar clipe;
- freeze/hold frame;
- grupos de elementos;

### V2 — animação 2D

- keyframes;
- curvas/easing;
- sequência de imagens/frames;
- duração por desenho;
- hold frame;
- onion skin;
- loops;
- sprites em camadas;
- pivô/anchor point;
- animação de posição, escala, rotação e opacidade;
- boca/olhos/partes do personagem como layers independentes;

### V3 — compositor 2.5D

- eixo Z lógico;
- câmera virtual;
- parallax;
- máscaras;
- matte;
- blur por profundidade;
- partículas simples;
- chuva/fumaça/luz como elementos de composição;
- motion blur quando viável;

### V4 — compositor avançado

- chroma key;
- blending modes;
- tracking manual/semiassistido sem IA obrigatória;
- máscaras animadas;
- texto avançado;
- efeitos e presets;
- composição reutilizável;

### V5 — 3D

Módulo opcional e isolado do editor principal.

- cena 3D;
- câmera;
- luzes;
- modelos GLB/GLTF inicialmente;
- animação por transform e skeleton quando suportado;
- integração da renderização 3D como layer/clipe da timeline;
- composição 2D + 3D.

O V5 não bloqueia V0–V4.

## 4. Não objetivos iniciais

Ficam explicitamente fora da primeira implementação:

- gerador de vídeo por IA;
- texto-para-vídeo;
- image-to-video generativo;
- clone completo de CapCut/NodeVideo/Blender;
- colaboração multiusuário;
- armazenamento obrigatório em nuvem;
- conta/login obrigatório;
- loja de créditos;
- templates online obrigatórios;
- 3D completo na V0;
- efeitos profissionais de alto custo computacional antes do pipeline básico estar estável.

## 5. Arquitetura

### 5.1 Camadas

```text
UI Mobile/Desktop
       |
Editor Application Layer
       |
Project / Timeline Core
       |
+------+---------+---------+----------+
|                |         |          |
Media Engine   2D Engine  Audio    Compositor
|                |         |          |
+----------------+---------+----------+
                 |
            Render/Export
```

### 5.2 Núcleo do projeto

Responsável por:

- schema do projeto;
- assets;
- tracks;
- clips;
- propriedades;
- keyframes;
- histórico undo/redo;
- autosave;
- versionamento/migração de schema;
- serialização determinística.

O Core não deve depender diretamente da UI.

### 5.3 Modelo de dados mínimo

```text
Project
- id
- schemaVersion
- title
- width
- height
- fps
- duration
- assets[]
- tracks[]
- settings

Asset
- id
- type: image | video | audio
- uri/path
- metadata
- fingerprint

Track
- id
- type: video | image | audio | text | animation
- order
- muted/hidden/locked
- clips[]

Clip
- id
- assetId
- startTime
- duration
- sourceIn
- sourceOut
- transform
- opacity
- volume
- effects[]
- keyframes[]
```

Valores temporais devem ser armazenados em unidade determinística (por exemplo, microssegundos inteiros ou ticks), nunca em float impreciso para sincronização.

### 5.4 Renderização

A exportação deve partir do estado serializado do projeto, não da UI.

Pipeline lógico:

```text
Project
  -> resolve timeline
  -> decode assets
  -> composite frame
  -> process audio
  -> encode video/audio
  -> mux MP4
```

A primeira versão prioriza H.264 + AAC em MP4 por compatibilidade Android/social.

Exportações futuras podem adicionar HEVC e outros formatos sem alterar o schema central.

## 6. Estratégia OpenCut

OpenCut será referência/upstream técnico, não dependência conceitual irreversível.

Regras:

1. utilizar somente código/licenças compatíveis;
2. preservar atribuições exigidas;
3. não acoplar o formato de projeto a detalhes de UI do upstream;
4. preferir componentes/módulos reutilizáveis e substituíveis;
5. manter nossa camada de domínio testável independentemente do frontend;
6. não basear o projeto em branch arquivada sem abstração que permita substituição.

## 7. Android/mobile-first

### 7.1 Requisitos de UX

- controles grandes e tocáveis;
- timeline com pinch-to-zoom;
- arraste com snapping;
- scrubbing responsivo;
- seleção clara de layer/clipe;
- painel de propriedades adaptável;
- teclado virtual não deve cobrir controles essenciais;
- orientação portrait e landscape considerada;
- projeto deve sobreviver a app background/foreground;
- nenhum dado deve depender apenas do estado em memória.

### 7.2 Recursos limitados

- cache com limite configurável;
- proxies/previews para mídia pesada quando necessário;
- descarte de frames intermediários quando seguro;
- carregamento preguiçoso;
- exportação em serviço foreground no Android;
- recuperação após interrupção durante render;
- prevenção de OOM por buffers ilimitados.


### 7.3 Player interno de pré-visualização

O editor deve permitir assistir ao projeto antes de exportar o MP4. O player é parte obrigatória da V0 e deve reproduzir o estado atual da timeline, não um arquivo exportado antigo.

Requisitos mínimos:

- play/pause;
- scrubbing pela timeline;
- seek por timestamp;
- avanço e retorno por frame quando o formato permitir precisão determinística;
- áudio sincronizado;
- visualização de posição, escala, rotação e opacidade;
- atualização após edição sem exigir exportação completa;
- modo de loop de um intervalo;
- tela cheia;
- controle de volume;
- fallback de qualidade para evitar travamentos/OOM.

Dois níveis de preview:

1. **Preview rápido:** prioriza responsividade e pode usar resolução/proxy reduzidos.
2. **Preview final:** pré-renderiza um intervalo curto usando o mesmo pipeline lógico da exportação para aproximar o resultado final antes do MP4 completo.

O player nunca deve ser a fonte de verdade do projeto; a fonte de verdade continua sendo o estado serializado da timeline.

## 8. Animação sem IA

O editor deve permitir produzir animação real por técnicas tradicionais:

- pose-a-pose;
- keyframes;
- in-betweens como imagens independentes;
- hold frames;
- animação em 1s/2s/3s;
- partes do personagem em layers;
- câmera e parallax;
- ciclos reutilizáveis;
- lip sync manual por troca de bocas;
- blink/eyes por sprites;
- efeitos ambientais em loops.

Exemplo:

```text
background.png      hold 5s
body.png            hold 5s
eyes_open.png       0.0-1.2s
eyes_closed.png     1.2-1.3s
eyes_open.png       1.3-5.0s
arm_01..arm_08      1.5-2.2s
rain_01..rain_12    loop
camera scale        100% -> 106%
```

Isso deve ser tratável como projeto comum e exportável em MP4.

## 9. Presets — não especializações rígidas

Presets iniciais previstos:

- TikTok 1080x1920;
- Reels 1080x1920;
- Shorts 1080x1920;
- YouTube 1920x1080;
- 4:5 social 1080x1350;
- quadrado 1080x1080;
- anime 24fps;
- animação 12 desenhos/s em timeline 24fps.

Anime/mangá não terá regras que limitem projetos de vídeo normal.

## 10. Segurança e integridade

- nunca apagar mídia original ao remover um clipe;
- confirmação antes de excluir projeto;
- autosave atômico: gravar temporário e substituir somente após sucesso;
- backup de estado anterior quando migrar schema;
- validar caminhos/URIs antes de renderizar;
- não executar conteúdo importado como código;
- tratar arquivos malformados como entrada não confiável;
- limitar memória para thumbnails e frames;
- evitar path traversal em pacotes de projeto;
- nomes de arquivos não podem controlar caminhos arbitrários.

## 11. Formato de projeto

Primeira proposta:

```text
project/
  project.json
  cache/
  thumbnails/
  proxies/
```

A mídia original pode permanecer referenciada externamente para evitar duplicação. Uma futura função "Empacotar projeto" copia mídias para um pacote portátil.

O arquivo `project.json` sempre inclui `schemaVersion`.

## 12. Undo/redo

Modelo recomendado: Command Pattern ou histórico de patches imutáveis.

Requisitos:

- cortar, mover, dividir, redimensionar duração, alterar propriedade e excluir devem ser reversíveis;
- undo não deve modificar mídia original;
- histórico pode ser limitado por memória, mas o estado salvo deve permanecer válido;
- após crash, o projeto deve abrir no último autosave consistente, não depender da pilha de undo.

## 13. Testes de aceitação V0

### T01 — imagem para vídeo

Input:
- JPG/PNG válido;
- projeto 1080x1920, 30fps;
- duração da imagem: 5s.

Ação:
- escala inicial 100%;
- escala final 110%;
- exportar MP4.

Esperado:
- MP4 reproduzível;
- ~5s;
- 1080x1920;
- movimento progressivo;
- sem tela preta inesperada;
- arquivo original intacto.

### T02 — dois vídeos

Input:
- dois MP4 suportados.

Ação:
- importar;
- aparar primeiro;
- dividir segundo;
- ordenar;
- exportar.

Esperado:
- timeline respeitada;
- A/V sincronizado dentro da tolerância definida;
- sem frames corrompidos na junção.

### T03 — sequência de imagens

Input:
- A.png, B.png, C.png;
- áudio opcional.

Ação:
- duração individual;
- transform por keyframe;
- exportar 1080x1920.

Esperado:
- ordem correta;
- duração correta;
- transições temporais estáveis;
- áudio não truncado indevidamente.

### T04 — salvar/reabrir

Ação:
- montar projeto;
- salvar;
- encerrar processo;
- reabrir.

Esperado:
- estado visual e temporal idêntico;
- sem duplicar clipes;
- sem perder caminhos/assets.

### T05 — undo/redo

Ação:
- mover clipe;
- cortar;
- apagar;
- executar undo/redo.

Esperado:
- cada operação retorna ao estado anterior correto;
- nenhuma mídia original é alterada.

### T06 — player de preview

Ação:
- montar projeto de imagem de 5s com transformação;
- reproduzir no player;
- pausar em posição intermediária;
- editar escala/posição;
- retomar reprodução;
- executar preview final de um intervalo curto.

Esperado:
- player reflete a timeline atual;
- seek não duplica nem perde clipes;
- áudio permanece sincronizado quando presente;
- edição aparece sem necessidade de exportação completa;
- preview final e exportação usam a mesma interpretação temporal dentro da tolerância definida.

## 14. Casos de borda obrigatórios

- arquivo inexistente após reabrir projeto;
- arquivo removido pelo Android;
- mídia com duração zero/inválida;
- vídeo sem áudio;
- áudio sem vídeo;
- resolução muito alta;
- orientação/metadata rotacional;
- variável frame rate;
- pouca RAM;
- pouco armazenamento durante exportação;
- app enviado ao background durante exportação;
- processo morto pelo Android;
- projeto com track vazia;
- clip com duração mínima;
- assets duplicados;
- nomes Unicode;
- caminhos com espaços;
- projeto antigo com schema anterior;
- exportação cancelada;
- falha do encoder;
- arquivo de projeto parcialmente escrito.

## 15. Critérios de performance V0

Alvos iniciais, sujeitos a benchmark real:

- UI não bloquear durante import/export;
- scrubbing deve permanecer responsivo em projeto pequeno;
- thumbnails geradas fora da thread principal;
- memória limitada por cache configurado;
- nenhuma operação O(n²) conhecida no redraw normal da timeline;
- preview pode reduzir qualidade antes de comprometer estabilidade;
- export pode ser mais lento que tempo real, mas não pode corromper o projeto.

Nenhum número de FPS será prometido antes de benchmark em aparelho real.

## 16. Telemetria

V0: nenhuma telemetria obrigatória.

Logs locais de diagnóstico podem registrar:

- versão do app;
- versão do schema;
- etapa do render;
- erro técnico;
- duração/resolução/codecs sem conteúdo pessoal.

Qualquer telemetria externa futura será opt-in e separada do funcionamento do editor.

## 17. Estratégia de testes

Pirâmide:

1. unitários: timeline math, cortes, duração, keyframes, schema;
2. property-based quando útil: intervalos temporais e invariantes;
3. integração: decode -> composite -> encode;
4. golden tests: frames esperados em operações determinísticas;
5. instrumentados Android: lifecycle, SAF, background, storage;
6. regressão de arquivos reais.

Não declarar suporte a formato/codec sem arquivo real de teste.

## 18. Definition of Done para V0

V0 só é considerada pronta quando:

- T01–T06 passam em execução real;
- nenhum P0/P1 conhecido permanece aberto;
- salvar/reabrir é confiável;
- exportação local produz MP4 reproduzível;
- mídia original permanece intacta;
- app lida com falhas de arquivo/storage sem perder o projeto;
- pelo menos um teste em aparelho Android real foi executado;
- resultados e limitações foram documentados.

## 19. Decisões adiadas conscientemente

Somente após prova V0:

- engine 3D definitivo;
- formato de plugin;
- marketplace/templates online;
- IA opcional;
- desktop/web públicos;
- colaboração;
- cloud render;
- codec avançado;
- edição multicam;
- tracking sofisticado.

## 20. Próximo passo após aprovação desta especificação

Criar um plano de implementação em tarefas pequenas e verificáveis, com TDD, começando pelo schema/timeline core e terminando no primeiro export real MP4.

Não iniciar features V1+ antes do ciclo V0 passar ponta a ponta.
