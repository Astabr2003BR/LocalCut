package com.localcut.editor.ui.editor.components

import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.ExperimentalApi
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.localcut.editor.media.Media3PreviewController
import com.localcut.editor.media.PreviewState
import java.util.Locale

@UnstableApi
@OptIn(ExperimentalApi::class)
@Composable
fun PreviewPane(
    controller: Media3PreviewController,
    state: PreviewState,
    onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onStepFrames: (Int) -> Unit,
    modifier: Modifier = Modifier,
    viewportHeight: Dp = 190.dp,
) {
    Column(modifier = modifier) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color.Black,
            shape = MaterialTheme.shapes.medium,
        ) {
            Box(
                modifier = Modifier.fillMaxWidth().height(viewportHeight).background(Color.Black),
                contentAlignment = Alignment.Center,
            ) {
                if (state.durationUs > 0L) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { context ->
                            PlayerView(context).also {
                                it.useController = false
                                controller.bindTo(it)
                            }
                        },
                        update = controller::bindTo,
                        onRelease = controller::unbindFrom,
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(20.dp),
                    ) {
                        Text(
                            text = "Nenhuma mídia no projeto",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            text = "Toque em Importar para começar",
                            color = Color(0xFFC9C9D2),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }

                state.errorMessage?.let { message ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp),
                    ) {
                        Text(
                            text = "Prévia: $message",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }

        val duration = state.durationUs.coerceAtLeast(0L)
        val sliderValue = if (duration == 0L) {
            0f
        } else {
            (state.positionUs.toDouble() / duration.toDouble()).coerceIn(0.0, 1.0).toFloat()
        }
        Slider(
            value = sliderValue,
            onValueChange = { fraction -> onSeek((duration * fraction).toLong()) },
            enabled = duration > 0L,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilledTonalButton(onClick = { onStepFrames(-1) }, enabled = duration > 0L) { Text("◀ 1f") }
            FilledTonalButton(onClick = onPlayPause, enabled = duration > 0L) {
                Text(if (state.playing) "Pausar" else "Play")
            }
            FilledTonalButton(onClick = { onStepFrames(1) }, enabled = duration > 0L) { Text("1f ▶") }
            Text(
                text = "${formatUs(state.positionUs)} / ${formatUs(duration)}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 4.dp),
            )
        }
    }
}

private fun formatUs(us: Long): String {
    val totalSeconds = us.coerceAtLeast(0L) / 1_000_000.0
    val minutes = (totalSeconds / 60).toInt()
    val seconds = totalSeconds - minutes * 60
    return String.format(Locale.ROOT, "%02d:%05.2f", minutes, seconds)
}
