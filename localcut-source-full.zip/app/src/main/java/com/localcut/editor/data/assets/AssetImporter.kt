package com.localcut.editor.data.assets

import android.net.Uri
import com.localcut.editor.domain.model.Asset

interface AssetImporter {
    fun import(uri: Uri): Result<Asset>
}
