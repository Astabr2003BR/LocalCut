package com.localcut.editor.media

import java.nio.file.Files
import java.nio.file.Path
import java.util.concurrent.atomic.AtomicBoolean

enum class ExportTransactionErrorCode {
    CANCELLED,
    TEMP_IO_FAILED,
    RENDER_FAILED,
    DESTINATION_WRITE_FAILED,
}

class ExportTransactionException(
    val code: ExportTransactionErrorCode,
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause)

class ExportCancellation {
    private val cancelled = AtomicBoolean(false)
    fun cancel() { cancelled.set(true) }
    fun isCancelled(): Boolean = cancelled.get()
}

fun interface TempExportRenderer {
    fun render(tempFile: Path, cancellation: ExportCancellation): Result<Unit>
}

fun interface ExportDestinationWriter {
    fun commitFrom(tempFile: Path): Result<Unit>
}

class ExportTransaction(
    private val renderer: TempExportRenderer,
    private val tempDir: Path,
    private val cancellation: ExportCancellation = ExportCancellation(),
) {
    fun run(destination: ExportDestinationWriter): Result<Unit> {
        if (cancellation.isCancelled()) return cancelledFailure()

        val tempFile = try {
            Files.createDirectories(tempDir)
            Files.createTempFile(tempDir, "localcut-export-", ".mp4.tmp")
        } catch (t: Throwable) {
            return Result.failure(
                ExportTransactionException(
                    ExportTransactionErrorCode.TEMP_IO_FAILED,
                    "Unable to create export temporary file",
                    t,
                )
            )
        }

        return try {
            if (cancellation.isCancelled()) return cancelledFailure()

            val renderResult = renderer.render(tempFile, cancellation)
            if (renderResult.isFailure) {
                return Result.failure(
                    ExportTransactionException(
                        ExportTransactionErrorCode.RENDER_FAILED,
                        "Renderer failed before destination commit",
                        renderResult.exceptionOrNull(),
                    )
                )
            }

            if (cancellation.isCancelled()) return cancelledFailure()

            val commitResult = destination.commitFrom(tempFile)
            if (commitResult.isFailure) {
                Result.failure(
                    ExportTransactionException(
                        ExportTransactionErrorCode.DESTINATION_WRITE_FAILED,
                        "Rendered file could not be committed to destination",
                        commitResult.exceptionOrNull(),
                    )
                )
            } else {
                Result.success(Unit)
            }
        } finally {
            runCatching { Files.deleteIfExists(tempFile) }
        }
    }

    private fun cancelledFailure(): Result<Unit> = Result.failure(
        ExportTransactionException(
            ExportTransactionErrorCode.CANCELLED,
            "Export cancelled before destination commit",
        )
    )
}
