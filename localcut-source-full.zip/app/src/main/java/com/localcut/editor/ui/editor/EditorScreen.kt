package com.localcut.editor.ui.editor

import android.content.res.Configuration
import androidx.annotation.OptIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberScrollState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.media3.common.util.ExperimentalApi
import androidx.media3.common.util.UnstableApi
import com.localcut.editor.media.Media3PreviewController
import com.localcut.editor.session.EditorAction
import com.localcut.editor.ui.editor.components.InspectorPane
import com.localcut.editor.ui.editor.components.PreviewPane
import com.localcut.editor.ui.editor.components.TimelinePane

data class ExportUiState(
    val running: Boolean = false,
    val progressPercent: Int? = null,
    val message: String? = null,
)

@UnstableApi
@OptIn(ExperimentalApi::class)
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    previewController: Media3PreviewController,
    exportState: ExportUiState,
    onImportRequested: () -> Unit,
    onExportRequested: () -> Unit,
    onCancelExport: () -> Unit,
    onFinalPreviewRequested: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val session by viewModel.sessionState.collectAsState()
    val preview by viewModel.previewState.collectAsState()
    val configuration = LocalConfiguration.current
    var loopEnabled by remember { mutableStateOf(false) }
    val project = session.project
    val aspect = project.width.toFloat() / project.height.coerceAtLeast(1).toFloat()

    Surface(modifier = modifier.fillMaxSize()) {
        if (configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Row(Modifier.fillMaxSize()) {
                Column(Modifier.weight(0.42f).fillMaxHeight()) {
                    EditorToolbar(
                        session.canUndo, session.canRedo, loopEnabled, exportState,
                        onImportRequested, onExportRequested, onCancelExport, onFinalPreviewRequested, viewModel
                    ) {
                        loopEnabled = it
                        viewModel.setLoopRange(0L, if (it && preview.durationUs > 0) preview.durationUs else null)
                    }
                    PreviewPane(
                        controller = previewController,
                        state = preview,
                        aspectRatio = aspect,
                        onPlayPause = { if (preview.playing) viewModel.pause() else viewModel.play() },
                        onSeek = viewModel::seekToUs,
                        onStepFrames = viewModel::stepFrames,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
                    )
                    InspectorForState(session, preview.positionUs, viewModel)
                }
                Column(Modifier.weight(0.58f).fillMaxHeight()) {
                    TimelineForState(session, preview.positionUs, viewModel, Modifier.weight(1f))
                }
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                EditorToolbar(
                    session.canUndo, session.canRedo, loopEnabled, exportState,
                    onImportRequested, onExportRequested, onCancelExport, onFinalPreviewRequested, viewModel
                ) {
                    loopEnabled = it
                    viewModel.setLoopRange(0L, if (it && preview.durationUs > 0) preview.durationUs else null)
                }
                PreviewPane(
                    controller = previewController,
                    state = preview,
                    aspectRatio = aspect,
                    onPlayPause = { if (preview.playing) viewModel.pause() else viewModel.play() },
                    onSeek = viewModel::seekToUs,
                    onStepFrames = viewModel::stepFrames,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp),
                )
                HorizontalDivider()
                TimelineForState(session, preview.positionUs, viewModel, Modifier.weight(1f))
                HorizontalDivider()
                InspectorForState(session, preview.positionUs, viewModel)
            }
        }
    }
}

@Composable
private fun EditorToolbar(
    canUndo: Boolean,
    canRedo: Boolean,
    loopEnabled: Boolean,
    exportState: ExportUiState,
    onImportRequested: () -> Unit,
    onExportRequested: () -> Unit,
    onCancelExport: () -> Unit,
    onFinalPreviewRequested: () -> Unit,
    viewModel: EditorViewModel,
    onLoopChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Button(onClick = onImportRequested, enabled = !exportState.running) { Text("Importar") }
        Button(onClick = onExportRequested, enabled = !exportState.running) { Text("Exportar") }
        Button(onClick = onFinalPreviewRequested, enabled = !exportState.running) { Text("Prévia final") }
        if (exportState.running) {
            Button(onClick = onCancelExport) { Text("Cancelar") }
            Text("${exportState.progressPercent ?: 0}%", modifier = Modifier.padding(top = 12.dp))
        }
        Button(onClick = { viewModel.dispatch(EditorAction.Undo) }, enabled = canUndo && !exportState.running) { Text("Desfazer") }
        Button(onClick = { viewModel.dispatch(EditorAction.Redo) }, enabled = canRedo && !exportState.running) { Text("Refazer") }
        Button(onClick = { onLoopChange(!loopEnabled) }) { Text(if (loopEnabled) "Loop ON" else "Loop OFF") }
        exportState.message?.let { Text(it, modifier = Modifier.padding(top = 12.dp)) }
    }
}

@Composable
private fun TimelineForState(
    session: com.localcut.editor.session.ProjectSessionState,
    playheadUs: Long,
    viewModel: EditorViewModel,
    modifier: Modifier,
) {
    TimelinePane(
        project = session.project,
        selectedClipId = session.selectedClipId,
        playheadUs = playheadUs,
        onSelectClip = { viewModel.dispatch(EditorAction.SelectClip(it)) },
        onSeek = viewModel::seekToUs,
        onMoveClip = { clipId, newStart ->
            viewModel.dispatch(EditorAction.SelectClip(clipId))
            viewModel.dispatch(EditorAction.MoveSelected(newStart))
        },
        onTrimLeft = { clipId, newStart ->
            viewModel.dispatch(EditorAction.SelectClip(clipId))
            viewModel.dispatch(EditorAction.TrimSelectedLeftEdge(newStart))
        },
        onTrimRight = { clipId, newEnd ->
            viewModel.dispatch(EditorAction.SelectClip(clipId))
            viewModel.dispatch(EditorAction.TrimSelectedRightEdge(newEnd))
        },
        modifier = modifier.padding(vertical = 8.dp),
    )
}

@Composable
private fun InspectorForState(
    session: com.localcut.editor.session.ProjectSessionState,
    playheadUs: Long,
    viewModel: EditorViewModel,
) {
    InspectorPane(
        project = session.project,
        selectedClipId = session.selectedClipId,
        playheadUs = playheadUs,
        onDelete = { viewModel.dispatch(EditorAction.DeleteSelected) },
        onSplit = { viewModel.dispatch(EditorAction.SplitSelected(it)) },
        onTransform = { viewModel.dispatch(EditorAction.SetSelectedTransform(it)) },
        onVolume = { viewModel.dispatch(EditorAction.SetSelectedVolume(it)) },
    )
    session.lastError?.let { Text("Erro: $it", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
    session.issues.firstOrNull()?.let { Text("Aviso: ${it.message}", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
}
