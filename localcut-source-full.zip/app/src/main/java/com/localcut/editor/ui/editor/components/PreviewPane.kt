package com.localcut.editor.ui.editor.components

import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.ExperimentalApi
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.localcut.editor.media.Media3PreviewController
import com.localcut.editor.media.PreviewState
import java.util.Locale

@UnstableApi
@OptIn(ExperimentalApi::class)
@Composable
fun PreviewPane(
    controller: Media3PreviewController,
    state: PreviewState,
    onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onStepFrames: (Int) -> Unit,
    modifier: Modifier = Modifier,
    aspectRatio: Float = 9f / 16f,
) {
    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(aspectRatio.coerceAtLeast(0.1f)),
            contentAlignment = Alignment.Center,
        ) {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = { context -> PlayerView(context).also(controller::bindTo) },
                update = controller::bindTo,
                onRelease = controller::unbindFrom,
            )
            if (state.errorMessage != null) {
                Text("Preview: ${state.errorMessage}", modifier = Modifier.padding(12.dp))
            }
        }

        val duration = state.durationUs.coerceAtLeast(0L)
        val sliderValue = if (duration == 0L) 0f else (state.positionUs.toDouble() / duration.toDouble()).coerceIn(0.0, 1.0).toFloat()
        Slider(
            value = sliderValue,
            onValueChange = { fraction -> onSeek((duration * fraction).toLong()) },
            enabled = duration > 0L,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = { onStepFrames(-1) }, enabled = duration > 0L) { Text("◀ 1f") }
            Button(onClick = onPlayPause, enabled = duration > 0L) { Text(if (state.playing) "Pausar" else "Play") }
            Button(onClick = { onStepFrames(1) }, enabled = duration > 0L) { Text("1f ▶") }
            Text("${formatUs(state.positionUs)} / ${formatUs(duration)}")
        }
    }
}

private fun formatUs(us: Long): String {
    val totalSeconds = us.coerceAtLeast(0L) / 1_000_000.0
    val minutes = (totalSeconds / 60).toInt()
    val seconds = totalSeconds - minutes * 60
    return String.format(Locale.ROOT, "%02d:%05.2f", minutes, seconds)
}
